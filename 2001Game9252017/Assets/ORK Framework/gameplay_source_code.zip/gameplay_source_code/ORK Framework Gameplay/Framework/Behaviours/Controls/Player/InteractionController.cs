
using ORKFramework;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	// TODO: options for interaction prioritization > e.g. interact with nearest, focused (angle), etc.
	// maybe list which types to prioritize, e.g. item collector over interactions
	[AddComponentMenu("ORK Framework/Controls/Interaction Controller")]
	public class InteractionController : MonoBehaviour
	{
		public bool interactWithNearest = false;

		public bool nearestIgnoreHeightDistance = false;

		public Vector3 nearestOffset = Vector3.zero;


		// in-game
		private bool interacting = false;

		private List<BaseInteraction> list = new List<BaseInteraction>();

		private List<BaseInteraction> triggerList = new List<BaseInteraction>();

		private InteractionDistanceSorter sorter;

		private Vector3 lastPosition;

		void Start()
		{
			this.sorter = new InteractionDistanceSorter(this);
			this.lastPosition = this.transform.position;
		}


		/*
		============================================================================
		List functions
		============================================================================
		*/
		public void SortInteractions()
		{
			if(this.interactWithNearest &&
				this.list.Count > 1)
			{
				this.lastPosition = this.transform.position;
				this.sorter.UpdatePosition();
				this.list.Sort(this.sorter);
			}
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool InteractionAvailable(InteractionType type, string customType)
		{
			GameObject player = ORK.Game.GetPlayer();
			for(int i = 0; i < this.list.Count; i++)
			{
				// remove dead interactions
				if(this.list[i] == null)
				{
					this.list.RemoveAt(i--);
				}
				// check available interactions
				else if(this.list[i].enabled &&
					this.list[i].CanInteract(EventStartType.Interact, player) &&
					(InteractionType.Any == type ||
						(type == this.list[i].Type &&
						(customType == "" || this.list[i].customType == customType))))
				{
					return true;
				}
			}
			return false;
		}

		public BaseInteraction GetFirstAvailable(InteractionType type, string customType)
		{
			GameObject player = ORK.Game.GetPlayer();
			this.SortInteractions();
			for(int i = 0; i < this.list.Count; i++)
			{
				// remove dead interactions
				if(this.list[i] == null)
				{
					this.list.RemoveAt(i--);
				}
				// check available interactions
				else if(this.list[i].enabled &&
					this.list[i].CanInteract(EventStartType.Interact, player) &&
					(InteractionType.Any == type ||
						(type == this.list[i].Type &&
						(customType == "" || this.list[i].customType == customType))))
				{
					return this.list[i];
				}
			}
			return null;
		}

		public int AvailableCount
		{
			get
			{
				int count = 0;
				GameObject player = ORK.Game.GetPlayer();
				for(int i = 0; i < this.list.Count; i++)
				{
					// remove dead interactions
					if(this.list[i] == null)
					{
						this.list.RemoveAt(i--);
					}
					// check available interactions
					else if(this.list[i].enabled &&
						this.list[i].CanInteract(EventStartType.Interact, player))
					{
						count++;
					}
				}
				return count;
			}
		}


		/*
		============================================================================
		Trigger functions
		============================================================================
		*/
		void OnTriggerEnter(Collider other)
		{
			other.gameObject.GetComponents<BaseInteraction>(this.triggerList);
			for(int i = 0; i < this.triggerList.Count; i++)
			{
				if(this.triggerList[i] != null &&
					EventStartType.Interact == this.triggerList[i].startType &&
					!this.list.Contains(this.triggerList[i]))
				{
					this.list.Add(this.triggerList[i]);
				}
			}
		}

		void OnTriggerExit(Collider other)
		{
			other.gameObject.GetComponents<BaseInteraction>(this.triggerList);
			for(int i = 0; i < this.triggerList.Count; i++)
			{
				if(this.triggerList[i] != null &&
					EventStartType.Interact == this.triggerList[i].startType)
				{
					this.list.Remove(this.triggerList[i]);
				}
			}
		}


		/*
		============================================================================
		Trigger2D functions
		============================================================================
		*/
		void OnTriggerEnter2D(Collider2D other)
		{
			other.gameObject.GetComponents<BaseInteraction>(this.triggerList);
			for(int i = 0; i < this.triggerList.Count; i++)
			{
				if(this.triggerList[i] != null &&
					EventStartType.Interact == this.triggerList[i].startType &&
					!this.list.Contains(this.triggerList[i]))
				{
					this.list.Add(this.triggerList[i]);
				}
			}
		}

		void OnTriggerExit2D(Collider2D other)
		{
			other.gameObject.GetComponents<BaseInteraction>(this.triggerList);
			for(int i = 0; i < this.triggerList.Count; i++)
			{
				if(this.triggerList[i] != null &&
					EventStartType.Interact == this.triggerList[i].startType)
				{
					this.list.Remove(this.triggerList[i]);
				}
			}
		}


		/*
		============================================================================
		Interaction functions
		============================================================================
		*/
		public bool Interact()
		{
			if(!this.interacting && ORK.Control.CanInteract)
			{
				this.SortInteractions();
				for(int i = 0; i < this.list.Count; i++)
				{
					// remove dead interactions
					if(this.list[i] == null)
					{
						this.list.RemoveAt(i--);
					}
					// check available interactions
					else if(this.list[i].enabled)
					{
						StartCoroutine(BlockInteraction());
						if(this.list[i].Interact())
						{
							return true;
						}
					}
				}
			}
			return false;
		}

		public bool Interact(InteractionType type, string customType)
		{
			if(!this.interacting &&
				ORK.Control.CanInteract)
			{
				GameObject player = ORK.Game.GetPlayer();
				this.SortInteractions();
				for(int i = 0; i < this.list.Count; i++)
				{
					// remove dead interactions
					if(this.list[i] == null)
					{
						this.list.RemoveAt(i--);
					}
					// check available interactions
					else if(this.list[i].enabled &&
						this.list[i].CanInteract(EventStartType.Interact, player) &&
						(InteractionType.Any == type ||
							(type == this.list[i].Type &&
							(customType == "" || this.list[i].customType == customType))))
					{
						StartCoroutine(BlockInteraction());
						if(this.list[i].Interact())
						{
							return true;
						}
					}
				}
			}
			return false;
		}

		private IEnumerator BlockInteraction()
		{
			this.interacting = true;
			yield return null;
			this.interacting = false;
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(this.transform.position, "InteractionController.psd");
		}

		void OnDrawGizmosSelected()
		{
			if(this.interactWithNearest)
			{
				Gizmos.color = Color.green;
				Gizmos.DrawWireCube(
					this.transform.TransformPoint(this.nearestOffset),
					new Vector3(0.05f, 0.05f, 0.05f));
			}
		}
	}
}