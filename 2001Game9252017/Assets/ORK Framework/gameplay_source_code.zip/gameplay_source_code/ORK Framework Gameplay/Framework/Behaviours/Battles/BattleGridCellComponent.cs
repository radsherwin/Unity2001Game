﻿
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("")]
	public class BattleGridCellComponent : MonoBehaviour, ISerializationCallbackReceiver
	{
		// grid info
		public BattleGridComponent parentGrid;

		public int row = 0;

		public int column = 0;


		// cell settings
		[ORKEditorInfo(ORKDataType.BattleGridCellType)]
		public int cellTypeID = 0;

		public bool ownDeployment = false;

		public GridDeploymentCell deployment;


		// cell events
		[ORKEditorInfo("Cell Events", "A cell event can perform abilities and game events on combatants that " +
			"move to/over or start/end their turn on cells of this type.", "",
			endFoldout=true)]
		[ORKEditorArray(false, "Add Cell Event", "Adds a cell event (abilities and game events) that can be performed on combatants on cells of this type.", "",
			"Remove", "Removes this cell event.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[]
			{
				"Cell Event", "Define when this cell event will be performed and what abilities and game events will be used.", ""
			})]
		[System.NonSerialized]
		public GridCellEvent[] cellEvent = new GridCellEvent[0];

		[SerializeField]
		private ORKDataFile serialize_cellEvent;


		// in-game
		private BattleGridCellType settings;

		[SerializeField]
		private GameObject prefabInstance;

		private CubeCoord cubeCoord;


		// occupant
		private Combatant combatant;

		private Combatant markedForCombatant;

		private List<Combatant> guestCombatants;


		// highlighting
		private GridHighlightType currentHighlight = GridHighlightType.None;

		private GridHighlightType selectingHighlight = GridHighlightType.None;

		private List<GridHighlightType> highlightStack;

		private Dictionary<GridHighlightType, GameObject> highlight;

		public void Init(BattleGridComponent parentGrid, int row, int column)
		{
			this.parentGrid = parentGrid;
			this.row = row;
			this.column = column;
		}

		public BattleGridCellType Settings
		{
			get
			{
				if(this.settings == null &&
					ORK.Initialized)
				{
					this.settings = ORK.BattleGridCellTypes.Get(this.cellTypeID);
				}
				return this.settings;
			}
			set { this.settings = value; }
		}

		public CubeCoord CubeCoord
		{
			get
			{
				if(this.cubeCoord == null)
				{
					this.cubeCoord = CubeCoord.FromOffset(this.row, this.column);
				}
				return this.cubeCoord;
			}
		}

		public bool IsBlocked
		{
			get { return this.Settings.blocked; }
		}

		public bool IsPassable
		{
			get { return !this.Settings.blocked || this.settings.passable; }
		}


		/*
		============================================================================
		Combatant functions
		============================================================================
		*/
		public bool CanDeploy(Combatant combatant)
		{
			return !this.IsBlocked &&
				this.combatant == null &&
				(this.ownDeployment ?
					this.deployment.CanDeploy(combatant) :
					this.Settings.deployment.CanDeploy(combatant));
		}

		public bool IsEmpty
		{
			get
			{
				return this.combatant == null &&
					this.markedForCombatant == null &&
					!this.HasGuests;
			}
		}

		public Combatant Combatant
		{
			get { return this.combatant; }
			set
			{
				if(this.combatant != value)
				{
					// reset current combatant's grid cell
					if(this.combatant != null &&
						this.combatant.GridCell == this)
					{
						Combatant tmpCombatant = this.combatant;
						this.combatant = null;
						tmpCombatant.GridCell = null;
					}

					this.combatant = value;
					this.markedForCombatant = null;
					if(this.HasGuests)
					{
						this.guestCombatants.Remove(this.combatant);
					}

					// set new combatant's grid cell
					if(this.combatant != null)
					{
						this.combatant.GridCell = this;
					}
					this.parentGrid.FireGridChanged();
				}
			}
		}

		public Combatant MarkedForCombatant
		{
			get { return this.markedForCombatant; }
			set
			{
				if(this.markedForCombatant != value)
				{
					this.markedForCombatant = value;
					this.parentGrid.FireGridChanged();
				}
			}
		}

		public bool HasGuests
		{
			get
			{
				return this.guestCombatants != null &&
					this.guestCombatants.Count > 0;
			}
		}

		public List<Combatant> GetGuests()
		{
			return this.guestCombatants;
		}

		public bool IsGuest(Combatant combatant)
		{
			return this.HasGuests &&
				this.guestCombatants.Contains(combatant);
		}

		public void AddGuest(Combatant combatant)
		{
			if(this.guestCombatants == null)
			{
				this.guestCombatants = new List<Combatant>();
			}
			if(!this.guestCombatants.Contains(combatant))
			{
				this.guestCombatants.Add(combatant);
				combatant.AddGuestCell(this);
				this.parentGrid.FireGridChanged();
			}
		}

		public void RemoveGuest(Combatant combatant)
		{
			if(this.guestCombatants != null &&
				this.guestCombatants.Contains(combatant))
			{
				this.guestCombatants.Remove(combatant);
				combatant.RemoveGuestCell(this);
				this.parentGrid.FireGridChanged();
			}
		}

		public void GetCombatants(ref List<Combatant> list, CombatantCheck check)
		{
			if(this.combatant != null &&
				!list.Contains(this.combatant) &&
				(check == null || check(this.combatant)))
			{
				list.Add(this.combatant);
			}
			if(this.HasGuests)
			{
				for(int i = 0; i < this.guestCombatants.Count; i++)
				{
					if(!list.Contains(this.guestCombatants[i]) &&
						(check == null || check(this.guestCombatants[i])))
					{
						list.Add(this.guestCombatants[i]);
					}
				}
			}
		}

		public bool CheckOccupants(CombatantCheck check)
		{
			if(check != null)
			{
				if(check(this.combatant))
				{
					return true;
				}
				else if(this.HasGuests)
				{
					for(int i = 0; i < this.guestCombatants.Count; i++)
					{
						if(check(this.guestCombatants[i]))
						{
							return true;
						}
					}
				}
			}
			return false;
		}

		public void SwapCombatants(BattleGridCellComponent other, bool placeAtCell)
		{
			if(!this.IsBlocked &&
				other != null &&
				!other.IsBlocked)
			{
				Combatant tmpCombatant = this.combatant;
				this.combatant = null;
				this.Combatant = other.combatant;

				other.combatant = null;
				other.Combatant = tmpCombatant;

				if(placeAtCell)
				{
					if(this.combatant != null)
					{
						this.combatant.GameObject.transform.position = this.transform.position;
					}
					if(other.combatant != null)
					{
						other.combatant.GameObject.transform.position = other.transform.position;
					}
				}
			}
		}


		/*
		============================================================================
		Prefab functions
		============================================================================
		*/
		public GameObject PrefabInstance
		{
			get { return this.prefabInstance; }
		}

		public GameObject HighlightPrefabInstance
		{
			get
			{
				if(this.highlight != null &&
					this.highlight.ContainsKey(this.currentHighlight))
				{
					return this.highlight[this.currentHighlight];
				}
				return null;
			}
			set
			{
				if(this.highlight == null)
				{
					this.highlight = new Dictionary<GridHighlightType, GameObject>();
				}
				if(this.highlight.ContainsKey(this.currentHighlight))
				{
					this.highlight[this.currentHighlight] = value;
				}
				else
				{
					this.highlight.Add(this.currentHighlight, value);
				}
			}
		}

		public void ShowPrefab()
		{
			if(this.prefabInstance == null &&
				this.Settings != null)
			{
				this.prefabInstance = this.Settings.prefab.CreatePrefabInstance(this.transform);
			}
		}

		public void HidePrefab()
		{
			if(this.prefabInstance != null)
			{
				this.prefabInstance.SetActive(false);
			}
			if(this.highlight != null)
			{
				foreach(KeyValuePair<GridHighlightType, GameObject> pair in this.highlight)
				{
					if(pair.Value != null)
					{
						pair.Value.SetActive(false);
					}
				}
			}
		}

		public void DestroyPrefab()
		{
			if(this.prefabInstance != null)
			{
				GameObject.Destroy(this.prefabInstance);
			}
			if(this.highlight != null)
			{
				foreach(KeyValuePair<GridHighlightType, GameObject> pair in this.highlight)
				{
					if(pair.Value != null)
					{
						GameObject.Destroy(pair.Value);
					}
				}
			}
		}


		/*
		============================================================================
		Highlight functions
		============================================================================
		*/
		public void HideHighlights(bool hide)
		{
			if((hide && GridHighlightType.None != this.currentHighlight) ||
				(!hide && this.highlightStack != null && this.highlightStack.Count > 0))
			{
				if(!hide ||
					ORK.BattleSystem.gridHighlights.IsHidden(this.currentHighlight))
				{
					this.DoStopHighlight(this.currentHighlight);
					this.currentHighlight = this.GetLastHighlightType();
					if(GridHighlightType.None != this.currentHighlight)
					{
						this.DoHighlight(this.currentHighlight);
					}
				}
			}
		}

		public void Highlight(GridHighlightType highlightType)
		{
			if(this.currentHighlight != highlightType)
			{
				if(this.highlightStack == null)
				{
					this.highlightStack = new List<GridHighlightType>();
				}
				if(GridHighlightType.None != this.currentHighlight)
				{
					this.DoStopHighlight(this.currentHighlight);
				}

				// set current selecting combatant highlight
				if(GridHighlightType.SelectingPlayer == highlightType ||
					GridHighlightType.SelectingAlly == highlightType ||
					GridHighlightType.SelectingEnemy == highlightType)
				{
					this.selectingHighlight = highlightType;
				}

				this.highlightStack.Add(highlightType);
				this.PriorityHighlight();
				this.currentHighlight = this.GetLastHighlightType();
				this.DoHighlight(this.currentHighlight);
			}
		}

		public void StopHighlight(GridHighlightType highlightType)
		{
			// remove current selecting combatant highlight
			if(this.selectingHighlight == highlightType)
			{
				this.selectingHighlight = GridHighlightType.None;
			}

			if(this.currentHighlight == highlightType)
			{
				this.DoStopHighlight(this.currentHighlight);

				if(this.highlightStack != null &&
					this.highlightStack.Count > 0)
				{
					this.RemoveHighlightType(highlightType);
					this.currentHighlight = this.GetLastHighlightType();
					this.DoHighlight(this.currentHighlight);
				}
				else
				{
					this.currentHighlight = GridHighlightType.None;
				}
			}
			else
			{
				this.RemoveHighlightType(highlightType);
			}
		}

		private GridHighlightType GetLastHighlightType()
		{
			if(this.highlightStack != null &&
				this.highlightStack.Count > 0)
			{
				if(this.parentGrid.HighlightsHidden)
				{
					for(int i = this.highlightStack.Count - 1; i >= 0; i--)
					{
						if(!ORK.BattleSystem.gridHighlights.IsHidden(this.highlightStack[i]))
						{
							return this.highlightStack[i];
						}
					}
				}
				else
				{
					return this.highlightStack[this.highlightStack.Count - 1];
				}
			}
			return GridHighlightType.None;
		}

		private void PriorityHighlight()
		{
			if(ORK.BattleSystem.gridHighlights.selectingPriority &&
				this.highlightStack != null &&
				this.highlightStack.Count > 0 &&
				GridHighlightType.None != this.selectingHighlight)
			{
				this.RemoveHighlightType(this.selectingHighlight);
				this.highlightStack.Add(this.selectingHighlight);
			}
		}

		private void RemoveHighlightType(GridHighlightType highlightType)
		{
			if(this.highlightStack != null &&
				this.highlightStack.Contains(highlightType))
			{
				for(int i = this.highlightStack.Count - 1; i >= 0; i--)
				{
					if(this.highlightStack[i] == highlightType)
					{
						this.highlightStack.RemoveAt(i);
					}
				}
			}
		}

		public void StopAllHighlights()
		{
			if(GridHighlightType.None != this.currentHighlight)
			{
				this.DoStopHighlight(this.currentHighlight);

				if(this.highlightStack != null &&
					this.highlightStack.Count > 0)
				{
					this.highlightStack.Clear();
				}
				this.currentHighlight = GridHighlightType.None;
			}
		}

		private void DoHighlight(GridHighlightType highlightType)
		{
			// combatant selection override
			if(GridHighlightType.PlacementSelectionPlayer == highlightType ||
				GridHighlightType.MoveSelectionPlayer == highlightType ||
				GridHighlightType.OrientationSelectionPlayer == highlightType ||
				GridHighlightType.TargetCellSelectionPlayer == highlightType ||
				GridHighlightType.ExamineSelectionPlayer == highlightType)
			{
				ORK.BattleSystem.gridHighlights.combatantSelectionPlayer.Highlight(this);
			}
			else if(GridHighlightType.PlacementSelectionAlly == highlightType ||
				GridHighlightType.MoveSelectionAlly == highlightType ||
				GridHighlightType.OrientationSelectionAlly == highlightType ||
				GridHighlightType.TargetCellSelectionAlly == highlightType ||
				GridHighlightType.ExamineSelectionAlly == highlightType)
			{
				ORK.BattleSystem.gridHighlights.combatantSelectionAlly.Highlight(this);
			}
			else if(GridHighlightType.PlacementSelectionEnemy == highlightType ||
				GridHighlightType.MoveSelectionEnemy == highlightType ||
				GridHighlightType.OrientationSelectionEnemy == highlightType ||
				GridHighlightType.TargetCellSelectionEnemy == highlightType ||
				GridHighlightType.ExamineSelectionEnemy == highlightType)
			{
				ORK.BattleSystem.gridHighlights.combatantSelectionEnemy.Highlight(this);
			}
			// placement
			else if(GridHighlightType.Placement == highlightType)
			{
				ORK.BattleSystem.gridHighlights.placementHighlight.Highlight(this);
			}
			else if(GridHighlightType.PlacementSelection == highlightType)
			{
				ORK.BattleSystem.gridHighlights.placementSelectionHighlight.Highlight(this);
			}
			else if(GridHighlightType.NoPlacementSelection == highlightType)
			{
				ORK.BattleSystem.gridHighlights.noPlacementSelectionHighlight.Highlight(this);
			}
			// move
			else if(GridHighlightType.MoveRange == highlightType)
			{
				ORK.BattleSystem.gridHighlights.moveRangeHighlight.Highlight(this);
			}
			else if(GridHighlightType.MoveSelection == highlightType)
			{
				ORK.BattleSystem.gridHighlights.moveSelectionHighlight.Highlight(this);
			}
			else if(GridHighlightType.NoMoveSelection == highlightType)
			{
				ORK.BattleSystem.gridHighlights.noMoveSelectionHighlight.Highlight(this);
			}
			else if(GridHighlightType.MovePath == highlightType)
			{
				ORK.BattleSystem.gridHighlights.movePathHighlight.Highlight(this);
			}
			// orientation
			else if(GridHighlightType.OrientationSelection == highlightType)
			{
				ORK.BattleSystem.gridHighlights.orientationSelectionHighlight.Highlight(this);
			}
			// use/affect range
			else if(GridHighlightType.UseRange == highlightType)
			{
				ORK.BattleSystem.gridHighlights.useRangeHighlight.Highlight(this);
			}
			else if(GridHighlightType.AffectRange == highlightType)
			{
				ORK.BattleSystem.gridHighlights.affectRangeHighlight.Highlight(this);
			}
			// available target
			else if(GridHighlightType.AvailableTargetPlayer == highlightType)
			{
				ORK.BattleSystem.gridHighlights.availableTargetPlayerHighlight.Highlight(this);
			}
			else if(GridHighlightType.AvailableTargetAlly == highlightType)
			{
				ORK.BattleSystem.gridHighlights.availableTargetAllyHighlight.Highlight(this);
			}
			else if(GridHighlightType.AvailableTargetEnemy == highlightType)
			{
				ORK.BattleSystem.gridHighlights.availableTargetEnemyHighlight.Highlight(this);
			}
			// target cell
			else if(GridHighlightType.TargetCellSelection == highlightType)
			{
				ORK.BattleSystem.gridHighlights.targetCellSelectionHighlight.Highlight(this);
			}
			else if(GridHighlightType.NoTargetCellSelection == highlightType)
			{
				ORK.BattleSystem.gridHighlights.noTargetCellSelectionHighlight.Highlight(this);
			}
			// examine
			else if(GridHighlightType.ExamineSelection == highlightType)
			{
				ORK.BattleSystem.gridHighlights.examineHighlight.Highlight(this);
			}
			else if(GridHighlightType.ExamineSelectionBlocked == highlightType)
			{
				ORK.BattleSystem.gridHighlights.examineBlockedHighlight.Highlight(this);
			}
			else if(GridHighlightType.ExamineMoveRange == highlightType)
			{
				ORK.BattleSystem.gridHighlights.moveRangeHighlight.Highlight(this);
			}
			else if(GridHighlightType.ExamineUseRange == highlightType)
			{
				ORK.BattleSystem.gridHighlights.useRangeHighlight.Highlight(this);
			}
			// selecting combatant
			else if(GridHighlightType.SelectingPlayer == highlightType)
			{
				ORK.BattleSystem.gridHighlights.selectingPlayerHighlight.Highlight(this);
			}
			else if(GridHighlightType.SelectingAlly == highlightType)
			{
				ORK.BattleSystem.gridHighlights.selectingAllyHighlight.Highlight(this);
			}
			else if(GridHighlightType.SelectingEnemy == highlightType)
			{
				ORK.BattleSystem.gridHighlights.selectingEnemyHighlight.Highlight(this);
			}
		}

		private void DoStopHighlight(GridHighlightType highlightType)
		{
			// combatant selection override
			if(GridHighlightType.PlacementSelectionPlayer == highlightType ||
				GridHighlightType.MoveSelectionPlayer == highlightType ||
				GridHighlightType.OrientationSelectionPlayer == highlightType ||
				GridHighlightType.TargetCellSelectionPlayer == highlightType ||
				GridHighlightType.ExamineSelectionPlayer == highlightType)
			{
				ORK.BattleSystem.gridHighlights.combatantSelectionPlayer.StopHighlight(this);
			}
			else if(GridHighlightType.PlacementSelectionAlly == highlightType ||
				GridHighlightType.MoveSelectionAlly == highlightType ||
				GridHighlightType.OrientationSelectionAlly == highlightType ||
				GridHighlightType.TargetCellSelectionAlly == highlightType ||
				GridHighlightType.ExamineSelectionAlly == highlightType)
			{
				ORK.BattleSystem.gridHighlights.combatantSelectionAlly.StopHighlight(this);
			}
			else if(GridHighlightType.PlacementSelectionEnemy == highlightType ||
				GridHighlightType.MoveSelectionEnemy == highlightType ||
				GridHighlightType.OrientationSelectionEnemy == highlightType ||
				GridHighlightType.TargetCellSelectionEnemy == highlightType ||
				GridHighlightType.ExamineSelectionEnemy == highlightType)
			{
				ORK.BattleSystem.gridHighlights.combatantSelectionEnemy.StopHighlight(this);
			}
			// placement
			else if(GridHighlightType.Placement == highlightType)
			{
				ORK.BattleSystem.gridHighlights.placementHighlight.StopHighlight(this);
			}
			else if(GridHighlightType.PlacementSelection == highlightType)
			{
				ORK.BattleSystem.gridHighlights.placementSelectionHighlight.StopHighlight(this);
			}
			else if(GridHighlightType.NoPlacementSelection == highlightType)
			{
				ORK.BattleSystem.gridHighlights.noPlacementSelectionHighlight.StopHighlight(this);
			}
			// move
			else if(GridHighlightType.MoveRange == highlightType)
			{
				ORK.BattleSystem.gridHighlights.moveRangeHighlight.StopHighlight(this);
			}
			else if(GridHighlightType.MoveSelection == highlightType)
			{
				ORK.BattleSystem.gridHighlights.moveSelectionHighlight.StopHighlight(this);
			}
			else if(GridHighlightType.NoMoveSelection == highlightType)
			{
				ORK.BattleSystem.gridHighlights.noMoveSelectionHighlight.StopHighlight(this);
			}
			else if(GridHighlightType.MovePath == highlightType)
			{
				ORK.BattleSystem.gridHighlights.movePathHighlight.StopHighlight(this);
			}
			// orientation
			else if(GridHighlightType.OrientationSelection == highlightType)
			{
				ORK.BattleSystem.gridHighlights.orientationSelectionHighlight.StopHighlight(this);
			}
			// use/affect range
			else if(GridHighlightType.UseRange == highlightType)
			{
				ORK.BattleSystem.gridHighlights.useRangeHighlight.StopHighlight(this);
			}
			else if(GridHighlightType.AffectRange == highlightType)
			{
				ORK.BattleSystem.gridHighlights.affectRangeHighlight.StopHighlight(this);
			}
			// available target
			else if(GridHighlightType.AvailableTargetPlayer == highlightType)
			{
				ORK.BattleSystem.gridHighlights.availableTargetPlayerHighlight.StopHighlight(this);
			}
			else if(GridHighlightType.AvailableTargetAlly == highlightType)
			{
				ORK.BattleSystem.gridHighlights.availableTargetAllyHighlight.StopHighlight(this);
			}
			else if(GridHighlightType.AvailableTargetEnemy == highlightType)
			{
				ORK.BattleSystem.gridHighlights.availableTargetEnemyHighlight.StopHighlight(this);
			}
			// target cell
			else if(GridHighlightType.TargetCellSelection == highlightType)
			{
				ORK.BattleSystem.gridHighlights.targetCellSelectionHighlight.StopHighlight(this);
			}
			else if(GridHighlightType.NoTargetCellSelection == highlightType)
			{
				ORK.BattleSystem.gridHighlights.noTargetCellSelectionHighlight.StopHighlight(this);
			}
			// examine
			else if(GridHighlightType.ExamineSelection == highlightType)
			{
				ORK.BattleSystem.gridHighlights.examineHighlight.StopHighlight(this);
			}
			else if(GridHighlightType.ExamineSelectionBlocked == highlightType)
			{
				ORK.BattleSystem.gridHighlights.examineBlockedHighlight.StopHighlight(this);
			}
			else if(GridHighlightType.ExamineMoveRange == highlightType)
			{
				ORK.BattleSystem.gridHighlights.moveRangeHighlight.StopHighlight(this);
			}
			else if(GridHighlightType.ExamineUseRange == highlightType)
			{
				ORK.BattleSystem.gridHighlights.useRangeHighlight.StopHighlight(this);
			}
			// selecting combatant
			else if(GridHighlightType.SelectingPlayer == highlightType)
			{
				ORK.BattleSystem.gridHighlights.selectingPlayerHighlight.StopHighlight(this);
			}
			else if(GridHighlightType.SelectingAlly == highlightType)
			{
				ORK.BattleSystem.gridHighlights.selectingAllyHighlight.StopHighlight(this);
			}
			else if(GridHighlightType.SelectingEnemy == highlightType)
			{
				ORK.BattleSystem.gridHighlights.selectingEnemyHighlight.StopHighlight(this);
			}
		}


		/*
		============================================================================
		Cell event functions
		============================================================================
		*/
		public void GetCellEvents(ref List<GridCellEventCall> cellEvents, GridCellEventStartType startType)
		{
			// cell type events
			if(this.Settings != null)
			{
				for(int i = 0; i < this.Settings.cellEvent.Length; i++)
				{
					if(this.Settings.cellEvent[i].startType == startType ||
						this.Settings.cellEvent[i].startType == GridCellEventStartType.Any ||
						GridCellEventStartType.Any == startType)
					{
						cellEvents.Add(new GridCellEventCall(this, this.Settings.cellEvent[i]));
					}
				}
			}
			// cell events
			for(int i = 0; i < this.cellEvent.Length; i++)
			{
				if(this.cellEvent[i].startType == startType ||
					this.cellEvent[i].startType == GridCellEventStartType.Any ||
					GridCellEventStartType.Any == startType)
				{
					cellEvents.Add(new GridCellEventCall(this, this.cellEvent[i]));
				}
			}
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public void OnBeforeSerialize()
		{
			DataObject data = new DataObject();
			DataObject[] events = new DataObject[this.cellEvent.Length];
			for(int i = 0; i < this.cellEvent.Length; i++)
			{
				events[i] = this.cellEvent[i].GetData();
			}
			data.Set("cellEvents", events);
			this.serialize_cellEvent = data.GetDataFile("cellEvents", false);
		}

		public void OnAfterDeserialize()
		{
			this.cellEvent = new GridCellEvent[0];
			if(this.serialize_cellEvent != null)
			{
				DataObject data = this.serialize_cellEvent.ToDataObject();
				DataObject[] events = data.GetFileArray("cellEvents");
				if(events != null)
				{
					this.cellEvent = new GridCellEvent[events.Length];
					for(int i = 0; i < this.cellEvent.Length; i++)
					{
						this.cellEvent[i] = new GridCellEvent();
						this.cellEvent[i].SetData(events[i]);
					}
				}
			}
			this.serialize_cellEvent = null;
		}
	}
}
