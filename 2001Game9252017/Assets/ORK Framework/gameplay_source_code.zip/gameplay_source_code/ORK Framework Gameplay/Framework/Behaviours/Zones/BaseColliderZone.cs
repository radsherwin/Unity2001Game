
using UnityEngine;
using System.Collections;

namespace ORKFramework.Behaviours
{
	public abstract class BaseColliderZone : MonoBehaviour
	{
		public bool IsWithin(Vector3 point)
		{
			Collider collider = this.GetComponent<Collider>();
			if(collider != null)
			{
				point.y = collider.bounds.center.y;
				if(collider.bounds.Contains(point))
				{
					point.y = collider.bounds.max.y + 1;
					RaycastHit hit;
					if(collider.Raycast(new Ray(point, -Vector3.up), out hit, collider.bounds.size.y))
					{
						return true;
					}
				}
			}
			else
			{
				Collider2D collider2D = this.GetComponent<Collider2D>();
				if(collider2D != null)
				{
					return collider2D.OverlapPoint(point);
				}
			}
			return false;
		}

		public void ClosestPoint(ref Vector3 point)
		{
			Collider collider = this.GetComponent<Collider>();
			if(collider != null)
			{
				point = collider.bounds.ClosestPoint(point);
				RaycastHit hit;
				if(collider.Raycast(new Ray(point,
					VectorHelper.GetDirection(point, collider.bounds.center)),
					out hit, Vector3.Distance(point, collider.bounds.center)))
				{
					point = hit.point;
				}
			}
			else
			{
				Collider2D collider2D = this.GetComponent<Collider2D>();
				if(collider2D != null)
				{
					point = collider2D.bounds.ClosestPoint(point);
					RaycastHit2D[] hit = Physics2D.RaycastAll(point,
						VectorHelper.GetDirection(point, collider2D.bounds.center),
						Vector3.Distance(point, collider2D.bounds.center));
					if(hit != null)
					{
						for(int i = 0; i < hit.Length; i++)
						{
							if(hit[i].collider == collider2D)
							{
								point = hit[i].point;
								break;
							}
						}
					}
				}
			}
		}
	}
}
