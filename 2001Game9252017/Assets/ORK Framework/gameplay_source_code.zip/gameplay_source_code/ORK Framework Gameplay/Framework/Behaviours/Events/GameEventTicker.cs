
using UnityEngine;
using ORKFramework;
using ORKFramework.Events;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	public class GameEventTicker : MonoBehaviour, IEventStarter
	{
		private GameEvent gameEvent;

		private IEventStarter starter;

		private bool inPause = false;

		private Notify finishedCallback;

		public void StartEvent(ORKGameEvent eventAsset, IEventStarter starter, object startingObject, bool inPause)
		{
			if(eventAsset != null)
			{
				this.starter = starter;
				this.inPause = inPause;

				this.gameEvent = new GameEvent();
				this.gameEvent.SetData(eventAsset.GetData().ToDataObject());
				this.gameEvent.StartEvent(this, startingObject);
			}
			else if(ComponentHelper.IsAlive(starter))
			{
				starter.EventEnded();
				GameObject.Destroy(this);
			}
		}

		public void StartEvent(ORKGameEvent eventAsset, object startingObject, bool inPause, Notify finishedCallback)
		{
			if(eventAsset != null)
			{
				this.finishedCallback = finishedCallback;
				this.inPause = inPause;

				this.gameEvent = new GameEvent();
				this.gameEvent.SetData(eventAsset.GetData().ToDataObject());
				this.gameEvent.StartEvent(this, startingObject);
			}
			else if(finishedCallback != null)
			{
				finishedCallback();
				GameObject.Destroy(this);
			}
		}

		void Update()
		{
			if((this.inPause || !ORK.Game.Paused) &&
				this.gameEvent != null && this.gameEvent.Executing)
			{
				this.gameEvent.Tick(ORK.Game.DeltaTime);
			}
		}

		public void EventEnded()
		{
			if(ComponentHelper.IsAlive(this.starter))
			{
				this.starter.EventEnded();
			}
			else if(this.finishedCallback != null)
			{
				this.finishedCallback();
			}
			GameObject.Destroy(this);
		}

		public void DontDestroy()
		{
			if(ComponentHelper.IsAlive(this.starter))
			{
				this.starter.DontDestroy();
			}
		}

		public void OnSceneLoaded()
		{
			if(ComponentHelper.IsAlive(this.starter))
			{
				this.starter.OnSceneLoaded();
			}
		}

		public GameObject GameObject
		{
			get
			{
				if(ComponentHelper.IsAlive(this.starter))
				{
					return this.starter.GameObject;
				}
				else
				{
					return this.gameObject;
				}
			}
		}
	}
}
