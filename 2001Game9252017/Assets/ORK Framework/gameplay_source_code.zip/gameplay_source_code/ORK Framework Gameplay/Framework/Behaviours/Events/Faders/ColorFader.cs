
using ORKFramework;
using System.Collections.Generic;
using System.Collections;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	public delegate void GetColorFade(ref float time, ref bool reverting);

	[AddComponentMenu("")]
	public class ColorFader : MonoBehaviour
	{
		protected FadeColorSettings settings;

		protected bool inPause = false;

		protected Renderer rendererComponent;


		// time
		protected GetColorFade linkedTime;

		protected float time;

		protected float time2;


		// fade
		protected bool fadeChildren;


		// colors
		protected Color color;

		protected Color start;


		// options
		protected bool fading = false;

		protected bool flash = false;

		protected bool blink = false;

		protected bool reverting = false;


		// current
		protected bool useCurrent = false;

		protected int currentIndex = 0;

		protected List<Color> currentColors;


		// material
		protected bool useShared = false;

		protected string materialProperty = "_Color";

		protected bool isFloat = false;


		// display texts
		protected DisplayText displayText;

		protected Color displayTextStart;

		public void Clear()
		{
			this.rendererComponent = this.GetComponent<Renderer>();
			this.fading = false;
			this.flash = false;
			this.blink = false;
			this.reverting = false;

			this.useCurrent = false;
			this.useShared = false;
			this.isFloat = false;
			this.materialProperty = "_Color";

			this.displayText = this.transform.root.GetComponentInChildren<DisplayText>();
			if(this.displayText)
			{
				this.displayTextStart = this.displayText.Color;
			}
		}

		public GetColorFade LinkedTime
		{
			get { return this.linkedTime; }
			set { this.linkedTime = value; }
		}


		/*
		============================================================================
		Fade functions
		============================================================================
		*/
		public void Fade(FadeColorSettings fcs, bool fc, bool shared, string matProp, bool iflo)
		{
			this.Clear();

			this.settings = fcs;
			this.start = new Color(1, 1, 1, 1);
			this.settings.GetStart(ref this.start);

			this.fadeChildren = fc;
			this.time = 0;
			this.time2 = this.settings.time;
			this.useShared = shared;
			this.materialProperty = matProp;
			this.isFloat = iflo;

			if(this.settings.fromCurrent)
			{
				this.currentColors = null;
				this.StoreCurrentColors();
				this.useCurrent = true;
			}
			else if(this.displayText)
			{
				this.displayTextStart = this.start;
			}

			this.fading = true;
		}


		/*
		============================================================================
		Flash functions
		============================================================================
		*/
		public void Flash(FadeColorSettings fcs, bool fc, bool shared, string matProp, bool iflo)
		{
			this.Clear();

			this.settings = fcs;
			this.start = new Color(1, 1, 1, 1);
			this.settings.GetStart(ref this.start);

			this.fadeChildren = fc;
			this.time = 0;
			this.time2 = this.settings.time / 2;
			this.useShared = shared;
			this.materialProperty = matProp;
			this.isFloat = iflo;

			if(this.settings.fromCurrent)
			{
				this.currentColors = null;
				this.StoreCurrentColors();
				this.useCurrent = true;
			}
			else if(this.displayText)
			{
				this.displayTextStart = this.start;
			}

			this.fading = true;
			this.flash = true;
		}


		/*
		============================================================================
		Blink functions
		============================================================================
		*/
		public void Blink(FadeColorSettings fcs, bool fc)
		{
			this.Clear();

			this.settings = fcs;
			this.start = new Color(1, 1, 1, 1);
			this.settings.GetStart(ref this.start);

			this.fadeChildren = fc;
			this.time = 0;
			this.time2 = this.settings.time;

			if(this.settings.fromCurrent)
			{
				this.currentColors = null;
				this.StoreCurrentColors();
				this.useCurrent = true;
			}
			else if(this.displayText)
			{
				this.displayTextStart = this.start;
			}

			this.fading = true;
			this.flash = true;
			this.blink = true;
		}

		public void StopBlink()
		{
			if(this.blink)
			{
				if(this.useCurrent)
				{
					this.time = this.time2;
					this.reverting = true;
					this.currentIndex = 0;
					if(this.rendererComponent != null)
					{
						this.DoFadeCurrent(this.rendererComponent);
					}
					if(this.fadeChildren)
					{
						this.FadeChildrenCurrent(this.transform);
					}
				}
				else
				{
					this.color = this.start;

					if(this.rendererComponent != null)
					{
						this.DoFade(this.rendererComponent);
					}
					if(this.fadeChildren)
					{
						this.FadeChildren(this.transform);
					}
				}
				this.Clear();
			}
		}


		/*
		============================================================================
		Change functions
		============================================================================
		*/
		void Update()
		{
			if(this.fading && !ORK.Game.Paused)
			{
				if(this.linkedTime != null)
				{
					this.linkedTime(ref this.time, ref this.reverting);
				}
				else
				{
					this.time += this.inPause ? ORK.Core.GUITimeDelta : ORK.Game.DeltaTime;
				}

				if(this.useCurrent)
				{
					this.currentIndex = 0;

					if(this.displayText)
					{
						if(this.reverting)
						{
							Color c = this.displayText.Color;
							this.settings.RevertFade(ref c, this.displayTextStart, this.time, this.time2);
							this.displayText.Color = c;
						}
						else
						{
							Color c = this.displayText.Color;
							this.settings.Fade(ref c, this.displayTextStart, this.time, this.time2);
							this.displayText.Color = c;
						}
					}
					if(this.rendererComponent != null)
					{
						this.DoFadeCurrent(this.rendererComponent);
					}
					if(this.fadeChildren)
					{
						this.FadeChildrenCurrent(this.transform);
					}
				}
				else
				{
					if(this.reverting)
					{
						this.settings.RevertFade(ref this.color, this.start, this.time, this.time2);
					}
					else
					{
						this.settings.Fade(ref this.color, this.start, this.time, this.time2);
					}

					if(this.displayText)
					{
						Color c = this.displayText.Color;
						if(this.settings.alpha)
						{
							c.a = this.color.a;
						}
						if(this.settings.red)
						{
							c.r = this.color.r;
						}
						if(this.settings.green)
						{
							c.g = this.color.g;
						}
						if(this.settings.blue)
						{
							c.b = this.color.b;
						}
						this.displayText.Color = c;
					}
					if(this.rendererComponent != null)
					{
						this.DoFade(this.rendererComponent);
					}
					if(this.fadeChildren)
					{
						this.FadeChildren(this.transform);
					}
				}

				if(this.time >= this.time2)
				{
					if(this.flash)
					{
						this.reverting = true;
						this.time = 0;
						this.flash = false;
					}
					else if(this.blink)
					{
						this.reverting = false;
						this.time = 0;
						this.flash = true;
					}
					else
					{
						this.fading = false;
						this.currentColors = null;
					}
				}
			}
		}


		/*
		============================================================================
		Child functions
		============================================================================
		*/
		protected void FadeChildren(Transform p)
		{
			foreach(Transform child in p)
			{
				Renderer renderer = child.GetComponent<Renderer>();
				if(renderer)
				{
					this.DoFade(renderer);
				}
				this.FadeChildren(child);
			}
		}

		protected void FadeChildrenCurrent(Transform p)
		{
			foreach(Transform child in p)
			{
				Renderer renderer = child.GetComponent<Renderer>();
				if(renderer)
				{
					this.DoFadeCurrent(renderer);
				}
				this.FadeChildrenCurrent(child);
			}
		}


		/*
		============================================================================
		Fading functions
		============================================================================
		*/
		protected void DoFade(Renderer rend)
		{
			if(rend is SpriteRenderer && !this.isFloat &&
				this.materialProperty == "_Color")
			{
				Color c = ((SpriteRenderer)rend).color;
				if(this.settings.alpha)
				{
					c.a = this.color.a;
				}
				if(this.settings.red)
				{
					c.r = this.color.r;
				}
				if(this.settings.green)
				{
					c.g = this.color.g;
				}
				if(this.settings.blue)
				{
					c.b = this.color.b;
				}
				((SpriteRenderer)rend).color = c;
			}
			else
			{
				Material[] materials;
				if(this.useShared)
				{
					materials = rend.sharedMaterials;
				}
				else
				{
					materials = rend.materials;
				}

				for(int i = 0; i < materials.Length; i++)
				{
					if(materials[i].HasProperty(this.materialProperty))
					{
						if(this.isFloat)
						{
							materials[i].SetFloat(this.materialProperty, this.color.a);
						}
						else
						{
							Color c = materials[i].GetColor(this.materialProperty);
							if(this.settings.alpha)
							{
								c.a = this.color.a;
							}
							if(this.settings.red)
							{
								c.r = this.color.r;
							}
							if(this.settings.green)
							{
								c.g = this.color.g;
							}
							if(this.settings.blue)
							{
								c.b = this.color.b;
							}
							materials[i].SetColor(this.materialProperty, c);
						}
					}
				}
			}
		}

		protected void DoFadeCurrent(Renderer rend)
		{
			if(rend is SpriteRenderer && !this.isFloat &&
				this.materialProperty == "_Color")
			{
				Color c = ((SpriteRenderer)rend).color;
				if(this.reverting)
				{
					this.settings.RevertFade(ref c, this.currentColors[this.currentIndex], this.time, this.time2);
				}
				else
				{
					this.settings.Fade(ref c, this.currentColors[this.currentIndex], this.time, this.time2);
				}
				((SpriteRenderer)rend).color = c;
			}
			else
			{
				Material[] materials;
				if(this.useShared)
				{
					materials = rend.sharedMaterials;
				}
				else
				{
					materials = rend.materials;
				}

				for(int i = 0; i < materials.Length; i++)
				{
					if(materials[i].HasProperty(this.materialProperty) &&
					this.currentIndex < this.currentColors.Count)
					{
						if(this.isFloat)
						{
							Color c = new Color(0, 0, 0, materials[i].GetFloat(this.materialProperty));
							if(this.reverting)
							{
								this.settings.RevertFade(ref c, this.currentColors[this.currentIndex], this.time, this.time2);
							}
							else
							{
								this.settings.Fade(ref c, this.currentColors[this.currentIndex], this.time, this.time2);
							}
							materials[i].SetFloat(this.materialProperty, c.a);
						}
						else
						{
							Color c = materials[i].GetColor(this.materialProperty);
							if(this.reverting)
							{
								this.settings.RevertFade(ref c, this.currentColors[this.currentIndex], this.time, this.time2);
							}
							else
							{
								this.settings.Fade(ref c, this.currentColors[this.currentIndex], this.time, this.time2);
							}
							materials[i].SetColor(this.materialProperty, c);
						}
						this.currentIndex++;
					}
				}
			}
		}


		/*
		============================================================================
		Store functions
		============================================================================
		*/
		public void StoreCurrentColors()
		{
			if(this.currentColors == null)
			{
				this.currentColors = new List<Color>();

				if(this.rendererComponent)
				{
					this.StoreRenderer(this.rendererComponent);
				}
				if(this.fadeChildren)
				{
					this.StoreChild(this.transform);
				}
			}
		}

		protected void StoreChild(Transform p)
		{
			foreach(Transform child in p)
			{
				Renderer renderer = child.GetComponent<Renderer>();
				if(renderer)
				{
					this.StoreRenderer(renderer);
				}
				this.StoreChild(child);
			}
		}

		protected void StoreRenderer(Renderer rend)
		{
			if(rend is SpriteRenderer && !this.isFloat &&
				this.materialProperty == "_Color")
			{
				this.currentColors.Add(((SpriteRenderer)rend).color);
			}
			else
			{
				Material[] materials;
				if(this.useShared)
				{
					materials = rend.sharedMaterials;
				}
				else
				{
					materials = rend.materials;
				}

				for(int i = 0; i < materials.Length; i++)
				{
					if(materials[i].HasProperty(this.materialProperty))
					{
						if(this.isFloat)
						{
							this.currentColors.Add(new Color(0, 0, 0, materials[i].GetFloat(this.materialProperty)));
						}
						else
						{
							this.currentColors.Add(materials[i].GetColor(this.materialProperty));
						}
					}
				}
			}
		}


		/*
		============================================================================
		Store functions
		============================================================================
		*/
		public void RestoreCurrentColors()
		{
			if(this.currentColors != null)
			{
				int index = 0;
				if(this.rendererComponent)
				{
					this.RestoreRenderer(this.rendererComponent, ref index);
				}
				if(this.fadeChildren)
				{
					this.RestoreChild(this.transform, ref index);
				}
			}
		}

		protected void RestoreChild(Transform parent, ref int index)
		{
			foreach(Transform child in parent)
			{
				Renderer renderer = child.GetComponent<Renderer>();
				if(renderer)
				{
					this.RestoreRenderer(renderer, ref index);
				}
				this.RestoreChild(child, ref index);
			}
		}

		protected void RestoreRenderer(Renderer rend, ref int index)
		{
			if(index < this.currentColors.Count)
			{
				if(rend is SpriteRenderer && !this.isFloat &&
					this.materialProperty == "_Color")
				{
					((SpriteRenderer)rend).color = this.currentColors[index++];
				}
				else
				{
					Material[] materials;
					if(this.useShared)
					{
						materials = rend.sharedMaterials;
					}
					else
					{
						materials = rend.materials;
					}

					for(int i = 0; i < materials.Length; i++)
					{
						if(materials[i].HasProperty(this.materialProperty))
						{
							if(this.isFloat)
							{
								materials[i].SetFloat(this.materialProperty, this.currentColors[index++].a);
							}
							else
							{
								materials[i].SetColor(this.materialProperty, this.currentColors[index++]);
							}
						}
					}
				}
			}
		}
	}
}
