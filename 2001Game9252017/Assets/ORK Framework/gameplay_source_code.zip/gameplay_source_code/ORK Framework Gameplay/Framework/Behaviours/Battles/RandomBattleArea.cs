
using UnityEngine;
using ORKFramework;
using ORKFramework.Events;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Battles/Random Battle Area")]
	public class RandomBattleArea : BaseConditionComponent, IEventStarter
	{
		// battle arena
		public GameObject battleComponentObject;

		public bool setBCPos = false;

		public bool setBCRot = false;

		public bool useNearestArena = false;

		public float arenaRange = 20;

		public BattleSystemType battleType = BattleSystemType.TurnBased;


		// random battle interval
		public float battleChance = 10.0f;

		public float checkInterval = 0.5f;

		// distance settings
		[UnityEngine.Serialization.FormerlySerializedAs("ignoreYDistance")]
		public bool ignoreHeightDistance = true;

		public float minMoveCheckDistance = 0.1f;

		public float minBattleDistance = 5.0f;

		public float maxBattleDistance = 15.0f;


		// combatant settings
		public BattleCombatant[] combatant = new BattleCombatant[] {new BattleCombatant()};

		public float[] chance = new float[] {100};


		// ingame
		private bool isInTrigger = false;


		// battle positions
		private Vector3 lastPosition = Vector3.zero;

		private Vector3 lastBattlePosition = Vector3.zero;

		private float timeout = 0;


		// battle component
		private BattleComponent battleComponent;

		private bool destroyComponent = false;


		/*
		============================================================================
		Trigger functions
		============================================================================
		*/
		void OnTriggerEnter(Collider other)
		{
			if(other.gameObject == ORK.Game.GetPlayer() &&
				this.CheckVariables())
			{
				this.isInTrigger = true;
				this.InitInterval(other.transform.position);
			}
		}

		void OnTriggerStay(Collider other)
		{
			if(this.isInTrigger && !ORK.Control.InBattle &&
				other.gameObject == ORK.Game.GetPlayer())
			{
				this.CheckInterval(other.transform.position, other.transform.eulerAngles);
			}
		}

		void OnTriggerExit(Collider other)
		{
			if(this.isInTrigger &&
				other.gameObject == ORK.Game.GetPlayer())
			{
				this.isInTrigger = false;
				this.SetVariables();
			}
		}


		/*
		============================================================================
		Trigger2D functions
		============================================================================
		*/
		void OnTriggerEnter2D(Collider2D other)
		{
			if(other.gameObject == ORK.Game.GetPlayer() &&
				this.CheckVariables())
			{
				this.isInTrigger = true;
				this.InitInterval(other.transform.position);
			}
		}

		void OnTriggerStay2D(Collider2D other)
		{
			if(this.isInTrigger && !ORK.Control.InBattle &&
				other.gameObject == ORK.Game.GetPlayer())
			{
				this.CheckInterval(other.transform.position, other.transform.eulerAngles);
			}
		}

		void OnTriggerExit2D(Collider2D other)
		{
			if(this.isInTrigger &&
				other.gameObject == ORK.Game.GetPlayer())
			{
				this.isInTrigger = false;
				this.SetVariables();
			}
		}


		/*
		============================================================================
		Interval functions
		============================================================================
		*/
		private void InitInterval(Vector3 position)
		{
			this.timeout = 0;
			this.lastPosition = position;
			this.lastBattlePosition = position;
		}

		private void CheckInterval(Vector3 position, Vector3 rotation)
		{
			this.timeout += ORK.Game.DeltaMovementTime;

			if(VectorHelper.Distance(this.lastPosition, position, this.ignoreHeightDistance) >= this.minMoveCheckDistance &&
				this.timeout >= this.checkInterval)
			{
				this.timeout -= this.checkInterval;
				this.lastPosition = position;

				float distance = VectorHelper.Distance(this.lastBattlePosition, position, this.ignoreHeightDistance);

				float rnd = (this.battleChance * ORK.Game.RandomBattleFactor) * ORK.Game.RandomBattleChance / 100.0f;
				if(rnd > 0 && (distance >= this.maxBattleDistance ||
					(distance >= this.minBattleDistance && ORK.GameSettings.CheckRandom(rnd))))
				{
					this.lastBattlePosition = position;

					int index = -1;
					float random = ORK.GameSettings.GetRandom();
					float tmpChance = 0;

					for(int i = 0; i < this.chance.Length; i++)
					{
						if(random >= tmpChance && random <= tmpChance + this.chance[i])
						{
							index = i;
							break;
						}
						else
						{
							tmpChance += this.chance[i];
						}
					}

					if(index >= 0 && index < this.combatant.Length)
					{
						this.StartBattle(index, position, rotation);
					}
				}
			}
		}


		/*
		============================================================================
		Battle functions
		============================================================================
		*/
		public void StartBattle(int index, Vector3 position, Vector3 rotation)
		{
			this.battleComponent = null;
			if(this.battleComponentObject != null)
			{
				this.battleComponent = this.battleComponentObject.GetComponent<BattleComponent>();
				if(this.battleComponent != null)
				{
					if(this.setBCPos && this.setBCRot)
					{
						this.battleComponent.transform.SetPositionAndRotation(position, Quaternion.Euler(rotation));
					}
					else
					{
						if(this.setBCPos)
						{
							this.battleComponent.transform.position = position;
						}
						if(this.setBCRot)
						{
							this.battleComponent.transform.eulerAngles = rotation;
						}
					}
				}
			}
			if(this.battleComponent == null && this.useNearestArena)
			{
				this.battleComponent = ComponentHelper.GetNearest<BattleComponent>(position);
			}
			if(this.battleComponent == null)
			{
				this.battleComponent = new GameObject("_RandomBattle").AddComponent<BattleComponent>();
				this.battleComponent.transform.SetPositionAndRotation(position, Quaternion.Euler(rotation));
				this.destroyComponent = true;
			}

			this.battleComponent.useSceneID = false;
			this.battleComponent.battleType = this.battleType;
			this.battleComponent.startType = EventStartType.None;
			this.battleComponent.StartGroup(this.combatant[index].GetGroup(null, -1, false), this);
		}

		public void EventEnded()
		{
			if(this.destroyComponent)
			{
				GameObject.Destroy(this.battleComponent.gameObject);
				this.battleComponent = null;
				this.destroyComponent = false;
			}
		}

		public void DontDestroy()
		{

		}

		public void OnSceneLoaded()
		{

		}

		public GameObject GameObject
		{
			get { return this.gameObject; }
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "RandomBattleArea.psd");
		}
	}
}
