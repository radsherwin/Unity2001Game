﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BattleSystemCheck : BaseData
	{
		[ORKEditorHelp("Turn Based", "Available in 'Turn Based' battles.", "")]
		public bool turnBased = true;

		[ORKEditorHelp("Active Time", "Available in 'Active Time' battles.", "")]
		public bool activeTime = true;

		[ORKEditorHelp("Real Time", "Available in 'Real Time' battles.", "")]
		public bool realTime = true;

		[ORKEditorHelp("Phase", "Available in 'Phase' battles.", "")]
		public bool phase = true;

		[ORKEditorHelp("Grid Battles", "Available in battles using a battle grid:\n" +
			"- Yes: A battle grid must be used.\n" +
			"- No: A battle grid must not be used.\n" +
			"- Ignore: Using a battle grid is ignored (i.e. available in both with and without a grid).", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		public Consider gridBattles = Consider.Ignore;

		public BattleSystemCheck()
		{

		}

		public bool Check()
		{
			return ((this.turnBased && ORK.Battle.IsTurnBased()) ||
				(this.activeTime && ORK.Battle.IsActiveTime()) ||
				(this.realTime && ORK.Battle.IsRealTime()) ||
				(this.phase && ORK.Battle.IsPhase())) &&
				(Consider.Ignore == this.gridBattles ||
					(Consider.Yes == this.gridBattles && ORK.Battle.Grid != null) ||
					(Consider.No == this.gridBattles && ORK.Battle.Grid == null));
		}
	}
}
