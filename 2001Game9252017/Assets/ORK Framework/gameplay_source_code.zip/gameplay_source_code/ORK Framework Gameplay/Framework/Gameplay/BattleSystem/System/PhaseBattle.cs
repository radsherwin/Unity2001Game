
using UnityEngine;
using ORKFramework.Events;
using System.Collections.Generic;
using System.Collections;

namespace ORKFramework
{
	public class PhaseBattle : BaseBattle, IEventStarter
	{
		// battle mode
		[ORKEditorHelp("Use Active Command", "Battle actions are executed right after selecting them, resulting in " +
			"each combatant selecting his action after the previous combatant finished it's action.\n" +
			"If disabled, the battle actions are selected at the beginning of each phase and executed " +
			"after all faction members chose their actions.", "")]
		[ORKEditorInfo("Phase Settings", "Settings for the phase battle system.\n" +
			"Each participating faction will perform their actions in a phase.\n" +
			"The order of the faction's combatants is free.\n" +
			"Phase battles don't support auto attacks.", "",
			labelText="Battle Mode")]
		public bool activeCommand = false;

		[ORKEditorHelp("Use Dynamic Combat", "Multiple actions are allowed at the same time.\n" +
			"Combatants will attack as soon as they can, the strict battle order isn't followed.\n" +
			"In any case, the next faction's phase will begin after all actions of the current phase have ended.\n" +
			"Please note that only camera changes from the latest battle action (battle animations) will be performed.", "")]
		public bool dynamicCombat = false;

		[ORKEditorHelp("Time Between Actions (s)", "The minimum time in seconds between two battle actions.", "")]
		[ORKEditorLayout("dynamicCombat", true, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float minTimeBetween = 0;


		// phase calculation
		[ORKEditorHelp("Calculate Phase Order", "The order in which factions will " +
			"get their phase will be calculated by a formula.\n" +
			"If disabled, the order is based on sorting the factions.", "")]
		[ORKEditorInfo(separator=true, labelText="Phase Calculation")]
		public bool calculatePhase = false;

		[ORKEditorHelp("Phase Calculation", "Select the formula used to calculate " +
			"a value for every participating faction.\n" +
			"The formula is calculated for every member of a faction that isn't dead." +
			"The faction with the highest value performs the first phase, " +
			"followed by the faction with the next (lower) value.", "")]
		[ORKEditorInfo(ORKDataType.Formula)]
		[ORKEditorLayout("calculatePhase", true)]
		public int phaseFormulaID = 0;

		[ORKEditorHelp("Initial Value (Phase)", "The initial value passed to the phase formula.\n" +
			"The formula will use the initial value as it's base and start the calculation with that value.", "")]
		public float initialValuePhase = 0;

		[ORKEditorHelp("Sum Values", "The value of a faction is the sum of all faction member's formula results.\n" +
			"If disabled, the value of a faction is the highest formula result of all faction members.", "")]
		public bool sumValues = false;

		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public TypeSorter sorter = new TypeSorter();


		// combatant order
		[ORKEditorHelp("Calculate Order", "The order in which combatants of a factions will " +
			"get their turns will be calculated by a formula.\n" +
			"If disabled, the order is based on sorting the combatants.", "")]
		[ORKEditorInfo(separator=true, labelText="Combatant Order")]
		public bool calculateCombatantOrder = false;

		[ORKEditorHelp("Order Calculation", "Select the formula used to calculate " +
			"a value for each combatant of a faction.\n" +
			"The combatant with the highest value will be the first, " +
			"followed by the combatant with the next (lower) value.", "")]
		[ORKEditorInfo(ORKDataType.Formula)]
		[ORKEditorLayout("calculateCombatantOrder", true)]
		public int combatantOrderFormulaID = 0;

		[ORKEditorHelp("Initial Value (Order)", "The initial value passed to the combatant order formula.\n" +
			"The formula will use the initial value as it's base and start the calculation with that value.", "")]
		public float initialValueCombatantOrder = 0;

		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public TypeSorter combatantSorter = new TypeSorter(TypeSorting.None);


		// battle menu settings
		[ORKEditorHelp("Auto Call Menu", "Automatically call the battle menu when a player controlled combatant's turn starts.\n" +
			"If disabled, the battle menu can be called through an input key during the combatant's turn, " +
			"or rely on other methods to select battle actions (e.g. control maps or shortcut HUDs).", "")]
		[ORKEditorInfo(separator=true, labelText="Battle Menu Settings")]
		public bool autoCallBattleMenu = true;

		[ORKEditorHelp("Battle Menu Key", "Key to call the battle menu.\n" +
			"The key is only used in 'Real Time' type battles.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("autoCallBattleMenu", false)]
		public int battleMenuKey = 0;

		[ORKEditorHelp("2nd Press Closes", "A second press on the battle menu key closes the battle menu.", "")]
		public bool battleMenuKeyCloses = false;

		[ORKEditorHelp("Close Back to Selection", "Closing the battle menu with the 2nd key press will return to the combatant selection.", "")]
		[ORKEditorLayout("battleMenuKeyCloses", true, endCheckGroup=true, endGroups=2)]
		public bool battleMenuKeyBack = false;


		// options
		[ORKEditorHelp("Can Counter", "Combatants can counter attack in 'Phase' battles.\n" +
			"If disabled, combatants can't counter attack.", "")]
		[ORKEditorInfo(separator=true, labelText="Options")]
		public bool canCounter = true;

		[ORKEditorHelp("Defeat on Player Death", "The player is defeated if the player combatant is dead.\n" +
			"If disabled, the whole player battle group has to be dead.", "")]
		public bool defeatPlayerDead = false;

		[ORKEditorHelp("Death Immediately", "A combatant's death action will be performed immediately when dying.\n" +
			"If disabled, the death action will be performed after the current action ends.", "")]
		public bool deathImmediately = false;

		[ORKEditorHelp("End Immediately", "The battle will end immediately, stopping the actions that are still performing.\n" +
			"If disabled, the battle will wait for all active actions to end.", "")]
		public bool endImmediately = false;

		[ORKEditorHelp("Defend First", "The defend command will perform before other actions.\n" +
			"Doesn't take already performing actions into account.", "")]
		public bool defendFirst = false;

		[ORKEditorHelp("Selecting Control Map", "The control map of the currently selecting player group member is used (and only while selecting).\n" +
			"If disabled, the control map of the player is used at all times.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool selectingControlMap = false;


		// actions settings
		// actions per turn
		[ORKEditorInfo("Actions Settings", "Define how many actions a combatant can perform each turn " +
			"and the default action costs.", "",
			"Actions Per Turn", "The number of actions a combatant can perform each turn.\n" +
			"This is used as a float value, i.e. you can also use 0.5 actions for an action.\n" +
			"As long as a combatant has more than 0 actions per turn left, he will be able to perform actions", "")]
		public FloatValue actionsPerTurn = new FloatValue(1);

		[ORKEditorHelp("Add Count", "The actions per turn will be added to the combatant's previous actions per turn, " +
			"i.e. unused actions per turn can be saved for the next turn.\n" +
			"If disabled, the actions per turn will be set each turn, i.e. unused actions per turn will be lost.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool addActionsPerTurn = false;

		// default action cost
		[ORKEditorInfo("Default Action Cost", "The default cost of an action (e.g. using an ability/item, defend, etc.).\n" +
			"This can be overridden by the individual actions.", "", endFoldout=true)]
		public ActionCost defaultActionCostSetting = new ActionCost();

		// default ability cost
		[ORKEditorHelp("Own Ability Cost", "Abilities use their own action cost, overriding the default action cost.\n" +
			"Individual abilities can also override the default/ability action cost.", "")]
		[ORKEditorInfo("Default Ability Cost", "The default cost for using an ability.\n" +
			"This can be overridden by the individual abilities.", "")]
		public bool ownAbilityCost = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownAbilityCost", true, endCheckGroup=true, autoInit=true)]
		public ActionCost defaultAbilityCostSetting;

		// default item cost
		[ORKEditorHelp("Own Item Cost", "Items use their own action cost, overriding the default action cost.\n" +
			"Individual items can also override the default/item action cost.", "")]
		[ORKEditorInfo("Default Item Cost", "The default cost for using an item.\n" +
			"This can be overridden by the individual items.", "")]
		public bool ownItemCost = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownItemCost", true, endCheckGroup=true, autoInit=true)]
		public ActionCost defaultItemCostSetting;

		// defend cost
		[ORKEditorHelp("Own Defend Cost", "The defend command uses its own action cost, overriding the default action cost.", "")]
		[ORKEditorInfo("Defend Cost", "The action cost for using the defend command.", "")]
		public bool ownDefendCost = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownDefendCost", true, endCheckGroup=true, autoInit=true)]
		public ActionCost defendCostSetting;

		// escape cost
		[ORKEditorHelp("Own Escape Cost", "The escape command uses its own action cost, overriding the default action cost.", "")]
		[ORKEditorInfo("Escape Cost", "The action cost for using the escape command.", "")]
		public bool ownEscapeCost = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownEscapeCost", true, endCheckGroup=true, autoInit=true)]
		public ActionCost escapeCostSetting;

		// escape cost
		[ORKEditorHelp("Own None Cost", "A 'None' action (end turn) uses its own action cost, overriding the default action cost.\n" +
			"Please note that a 'None' actions ends the turn of the combatant in any case.", "")]
		[ORKEditorInfo("None Cost", "The action cost for using a 'None' action.", "")]
		public bool ownNoneCost = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownNoneCost", true, endCheckGroup=true, autoInit=true)]
		public ActionCost noneCostSetting;

		// change member cost
		[ORKEditorHelp("Own Change Cost", "Changing a battle member uses its own action cost, overriding the default action cost.", "")]
		[ORKEditorInfo("Change Member Cost", "The action cost for changing a battle member.", "")]
		public bool ownChangeMemberCost = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownChangeMemberCost", true, endCheckGroup=true, autoInit=true)]
		public ActionCost changeMemberCostSetting;

		// grid move cost
		[ORKEditorHelp("Own Grid Move Cost", "A 'Grid Move' action uses its own action cost, overriding the default action cost.", "")]
		[ORKEditorInfo("Grid Move Cost", "The action cost for using a 'Grid Move' action.", "")]
		public bool ownGridMoveCost = false;

		[ORKEditorInfo(endFoldout=true, endFolds=2)]
		[ORKEditorLayout("ownGridMoveCost", true, endCheckGroup=true, autoInit=true)]
		public ActionCost gridMoveCostSetting;


		// player combatant choice
		[ORKEditorInfo("Player Combatant Selection", "Define how the player can choose the " +
			"next combatant to perform an action.", "", endFoldout=true)]
		public PhaseCombatantChoice combatantChoice = new PhaseCombatantChoice();


		// ingame
		protected List<KeyValuePair<int, List<Combatant>>> phaseOrder;

		protected List<Combatant> currentFaction;

		private List<Combatant> performedOrder = new List<Combatant>();

		protected bool performingActions = false;


		// phase events
		protected PhaseChangeEvent phaseEvent;

		protected int phaseEventFlag = 0;


		// player controlled list > for click feedback
		protected List<Combatant> playerControlled;

		protected Combatant selectingCombatant;


		// advantage
		protected int firstPhaseRounds = 1;

		public PhaseBattle()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<DataObject>("defaultActionCost"))
			{
				this.defaultActionCostSetting.cost.SetData(data.GetFile("defaultActionCost"));
				if(this.ownAbilityCost)
				{
					this.defaultAbilityCostSetting = new ActionCost();
					this.defaultAbilityCostSetting.cost.SetData(data.GetFile("defaultAbilityCost"));
				}
				if(this.ownItemCost)
				{
					this.defaultItemCostSetting = new ActionCost();
					this.defaultItemCostSetting.cost.SetData(data.GetFile("defaultItemCost"));
				}
				if(this.ownDefendCost)
				{
					this.defendCostSetting = new ActionCost();
					this.defendCostSetting.cost.SetData(data.GetFile("defendCost"));
				}
				if(this.ownEscapeCost)
				{
					this.escapeCostSetting = new ActionCost();
					this.escapeCostSetting.cost.SetData(data.GetFile("escapeCost"));
				}
				if(this.ownNoneCost)
				{
					this.noneCostSetting = new ActionCost();
					this.noneCostSetting.cost.SetData(data.GetFile("noneCost"));
				}
				if(this.ownChangeMemberCost)
				{
					this.changeMemberCostSetting = new ActionCost();
					this.changeMemberCostSetting.cost.SetData(data.GetFile("changeMemberCost"));
				}
				if(this.ownGridMoveCost)
				{
					this.gridMoveCostSetting = new ActionCost();
					this.gridMoveCostSetting.cost.SetData(data.GetFile("gridMoveCost"));
				}
			}
		}

		public override bool CanCounter
		{
			get { return this.canCounter; }
		}

		public override bool DeathImmediately
		{
			get { return this.deathImmediately; }
		}

		public override bool EndImmediately
		{
			get { return this.endImmediately; }
		}

		public override bool DefeatOnPlayerDeath
		{
			get { return this.defeatPlayerDead; }
		}

		public override bool DefendFirst
		{
			get { return this.defendFirst; }
		}

		public override Combatant SelectingCombatant
		{
			get { return this.selectingCombatant; }
		}

		public override void Tick()
		{
			// battle menu key
			if(!this.autoCallBattleMenu &&
				this.selectingCombatant != null)
			{
				if(ORK.InputKeys.Get(this.battleMenuKey).GetButton() &&
					!this.selectingCombatant.Dead &&
					this.selectingCombatant.Actions.IsChoosing &&
					this.selectingCombatant.IsPlayerControlled() &&
					!this.selectingCombatant.IsAIControlled())
				{
					if(!this.selectingCombatant.BattleMenu.IsOpen)
					{
						this.selectingCombatant.Actions.Choose(false, true);
					}
					else if(this.battleMenuKeyCloses)
					{
						this.selectingCombatant.EndBattleMenu(this.battleMenuKeyBack);
					}
				}
			}

			if(this.phaseEvent != null && this.phaseEvent.Executing)
			{
				this.phaseEvent.Tick(ORK.Game.DeltaTime);
			}
		}


		/*
		============================================================================
		Battle menu functions
		============================================================================
		*/
		public override bool IsMenuBackAllowed
		{
			get
			{
				return this.combatantChoice != null &&
					this.combatantChoice.useCombatantChoice;
			}
		}

		public override void BattleMenuCanceled(Combatant user)
		{
			// canceled battle menu > add to the list of possible combatants again
			if(this.currentFaction != null)
			{
				this.currentFaction.Add(user);
			}
			if(this.selectingCombatant == user)
			{
				this.selectingCombatant = null;
				ORK.Battle.FireLatestTurn(null);
				if(this.performedOrder.Contains(this.selectingCombatant))
				{
					this.performedOrder.Remove(this.selectingCombatant);
				}
			}
			this.GetNextAction();
		}

		public override bool CombatantClicked(Combatant combatant)
		{
			if(this.playerControlled != null &&
				this.playerControlled.Contains(combatant))
			{
				this.CombatantSelected(combatant);
				return true;
			}
			return false;
		}

		public override bool UseControlMap()
		{
			if(this.selectingControlMap)
			{
				if(this.selectingCombatant != null &&
					this.selectingCombatant.IsPlayerControlled() &&
					!this.selectingCombatant.IsAIControlled())
				{
					this.selectingCombatant.ControlMapTick();
				}
				return true;
			}
			return false;
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool IsDynamicCombat()
		{
			return this.dynamicCombat;
		}


		/*
		============================================================================
		Action cost functions
		============================================================================
		*/
		public override float GetDefendActionCost(Combatant user)
		{
			if(this.ownDefendCost)
			{
				return this.defendCostSetting.GetCost(user);
			}
			else
			{
				return this.defaultActionCostSetting.GetCost(user);
			}
		}

		public override float GetEscapeActionCost(Combatant user)
		{
			if(this.ownEscapeCost)
			{
				return this.escapeCostSetting.GetCost(user);
			}
			else
			{
				return this.defaultActionCostSetting.GetCost(user);
			}
		}

		public override float GetNoneActionCost(Combatant user)
		{
			if(this.ownNoneCost)
			{
				return this.noneCostSetting.GetCost(user);
			}
			else
			{
				return this.defaultActionCostSetting.GetCost(user);
			}
		}

		public override float GetChangeMemberActionCost(Combatant user)
		{
			if(this.ownChangeMemberCost)
			{
				return this.changeMemberCostSetting.GetCost(user);
			}
			else
			{
				return this.defaultActionCostSetting.GetCost(user);
			}
		}

		public override float GetGridMoveActionCost(Combatant user)
		{
			if(this.ownGridMoveCost)
			{
				return this.gridMoveCostSetting.GetCost(user);
			}
			else
			{
				return this.defaultActionCostSetting.GetCost(user);
			}
		}


		/*
		============================================================================
		Start functions
		============================================================================
		*/
		public override void StartBattle(bool changed)
		{
			base.StartBattle(changed);
			this.selectingCombatant = null;

			if(!changed)
			{
				this.firstPhaseRounds = 0;
				if(GroupAdvantageType.Player == ORK.Battle.Advantage)
				{
					if(ORK.BattleSettings.playerAdvantage.playerGroupCondition.firstPhase)
					{
						this.firstPhaseRounds = ORK.BattleSettings.playerAdvantage.playerGroupCondition.firstPhaseRounds;
					}
					else if(ORK.BattleSettings.playerAdvantage.enemyGroupCondition.firstPhase)
					{
						this.firstPhaseRounds = ORK.BattleSettings.playerAdvantage.enemyGroupCondition.firstPhaseRounds;
					}
				}
				else if(GroupAdvantageType.Enemy == ORK.Battle.Advantage)
				{
					if(ORK.BattleSettings.enemyAdvantage.playerGroupCondition.firstPhase)
					{
						this.firstPhaseRounds = ORK.BattleSettings.enemyAdvantage.playerGroupCondition.firstPhaseRounds;
					}
					else if(ORK.BattleSettings.enemyAdvantage.enemyGroupCondition.firstPhase)
					{
						this.firstPhaseRounds = ORK.BattleSettings.enemyAdvantage.enemyGroupCondition.firstPhaseRounds;
					}
				}
			}

			this.StartTurn();
		}

		protected void StartTurn()
		{
			ORK.Battle.CheckBattleEnd();
			if(!ORK.Battle.BattleEnd && !ORK.Battle.WaitForLastAction)
			{
				this.phaseOrder = null;
				this.currentFaction = null;
				this.performingActions = false;

				if(!this.dynamicCombat)
				{
					ORK.Battle.Actions.ClearStack();
				}

				// get participating factions and their members
				Dictionary<int, List<Combatant>> factions = ORK.Game.Combatants.GetByFaction(
					ORK.Game.ActiveGroup.Leader, true, Range.Infinity, Consider.No, Consider.Yes);

				// get the faction order
				List<int> factionIDs = new List<int>();

				if(this.calculatePhase)
				{
					List<KeyValuePair<int, float>> factionValues = new List<KeyValuePair<int, float>>();
					foreach(KeyValuePair<int, List<Combatant>> pair in factions)
					{
						factionValues.Add(new KeyValuePair<int, float>(pair.Key, this.GetFactionValue(pair.Value)));
					}
					factionValues.Sort(new PhaseSorter());

					for(int i = 0; i < factionValues.Count; i++)
					{
						factionIDs.Add(factionValues[i].Key);
					}
				}
				else
				{
					factionIDs.AddRange(factions.Keys);
					this.sorter.Sort(ref factionIDs, ORKDataType.Faction);
				}

				// create phase order
				this.phaseOrder = new List<KeyValuePair<int, List<Combatant>>>();
				for(int i = 0; i < factionIDs.Count; i++)
				{
					// unset phase performed
					for(int j = 0; j < factions[factionIDs[i]].Count; j++)
					{
						if(factions[factionIDs[i]][j] != null)
						{
							factions[factionIDs[i]][j].Battle.TurnPerformed = false;
							factions[factionIDs[i]][j].Battle.TurnHasEnded = false;
							if(factions[factionIDs[i]][j].Battle.ReceiveActionsPerTurn)
							{
								if(this.addActionsPerTurn)
								{
									factions[factionIDs[i]][j].Battle.ActionBar += this.actionsPerTurn.GetValue(
										factions[factionIDs[i]][j], factions[factionIDs[i]][j]);
								}
								else
								{
									factions[factionIDs[i]][j].Battle.ActionBar = this.actionsPerTurn.GetValue(
										factions[factionIDs[i]][j], factions[factionIDs[i]][j]);
								}
								factions[factionIDs[i]][j].Battle.UsedActionBar = 0;
								factions[factionIDs[i]][j].Battle.ReceiveActionsPerTurn = false;
							}
						}
					}
					KeyValuePair<int, List<Combatant>> tmp = new KeyValuePair<int, List<Combatant>>(factionIDs[i], factions[factionIDs[i]]);

					// player advantage first phase
					if(GroupAdvantageType.Player == ORK.Battle.Advantage &&
						this.firstPhaseRounds > 0 &&
						ORK.Game.ActiveGroup.FactionID == tmp.Key)
					{
						this.phaseOrder.Insert(0, tmp);
					}
					// enemy advantage first phase
					else if(GroupAdvantageType.Enemy == ORK.Battle.Advantage &&
						this.firstPhaseRounds > 0 &&
						ORK.Game.ActiveGroup.IsEnemy(tmp.Key))
					{
						this.phaseOrder.Insert(0, tmp);
					}
					// no first phase
					else
					{
						this.phaseOrder.Add(tmp);
					}
				}

				if(this.firstPhaseRounds > 0)
				{
					this.firstPhaseRounds--;
				}

				// start first phase
				this.NextPhase();
			}
		}

		protected float GetFactionValue(List<Combatant> list)
		{
			float value = 0;
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null && !list[i].Dead)
				{
					float newValue = ORK.Formulas.Get(this.phaseFormulaID).Calculate(
						new FormulaCall(this.initialValuePhase, list[i], list[i]));
					if(this.sumValues)
					{
						value += newValue;
					}
					else if(value < newValue)
					{
						value = newValue;
					}
				}
			}
			return value;
		}


		/*
		============================================================================
		Phase handling functions
		============================================================================
		*/
		protected IEnumerator NextPhaseWait()
		{
			yield return null;
			this.NextPhase();
		}

		protected void NextPhase()
		{
			if(!ORK.Battle.BattleEnd)
			{
				// still actions left?
				if(ORK.Battle.Actions.Has())
				{
					this.PerformNextAction();
				}
				// start next phase
				else if(this.selectingCombatant == null &&
					!ORK.Battle.Actions.HasCasting() &&
					!ORK.Battle.Actions.HasActive())
				{
					this.performingActions = false;

					// set phase end flag
					this.phaseEventFlag = 2;

					// not first phase in this turn
					if(this.currentFaction != null)
					{
						if(!this.activeCommand)
						{
							this.TurnEnd();
						}
						// perform phase end event of current faction
						else
						{
							this.PhaseEndEvent();
						}

					}
					// first phase > play only start event
					else
					{
						this.EventEnded();
					}
				}
				// continue checking next phase until all actions finished
				else
				{
					ORK.StartCoroutine(this.NextPhaseWait());
				}
			}
		}

		private void TurnEnd()
		{
			if(this.performedOrder.Count > 0)
			{
				Combatant combatant = this.performedOrder[0];
				this.performedOrder.RemoveAt(0);
				if(combatant.Battle.CanEndTurn)
				{
					combatant.Battle.EndTurn(this.TurnEnd);
				}
				else
				{
					this.TurnEnd();
				}
			}
			else
			{
				this.PhaseEndEvent();
			}
		}

		private void PhaseEndEvent()
		{
			FactionSetting faction = ORK.Factions.Get(this.phaseOrder[0].Key);
			if(faction.phaseEndAsset != null)
			{
				this.phaseEvent = new PhaseChangeEvent();
				this.phaseEvent.SetData(faction.phaseEndAsset.GetData().ToDataObject());
				this.phaseEvent.SetMembers(this.phaseOrder[0].Value);
				this.phaseOrder.RemoveAt(0);
				this.phaseEvent.StartEvent(this, null);
			}
			else
			{
				this.phaseOrder.RemoveAt(0);
				this.EventEnded();
			}
		}

		protected void CheckPhaseCombatants()
		{
			for(int i = 0; i < this.currentFaction.Count; i++)
			{
				if(this.currentFaction[i] == null ||
					this.currentFaction[i].Dead)
				{
					this.currentFaction.RemoveAt(i--);
				}
			}

			if(this.calculateCombatantOrder)
			{
				for(int i = 0; i < this.currentFaction.Count; i++)
				{
					this.currentFaction[i].Battle.TurnValue = ORK.Formulas.Get(this.combatantOrderFormulaID).Calculate(
						new FormulaCall(this.initialValueCombatantOrder, this.currentFaction[i], this.currentFaction[i]));
				}
				this.currentFaction.Sort(new TurnSorter());
			}
			else
			{
				this.combatantSorter.Sort(ref this.currentFaction);
			}
		}

		public void CombatantSelected(Combatant combatant)
		{
			this.ClearPlayerChoice();

			// null combatant selected > next phase
			if(combatant == null)
			{
				this.selectingCombatant = null;
				this.NextPhase();
			}
			// check for combatant and get it's action
			else
			{
				if(this.currentFaction.Contains(combatant))
				{
					this.selectingCombatant = combatant;
					this.currentFaction.Remove(combatant);
					this.SelectAction(combatant);
				}
				else
				{
					ORK.Battle.Actions.Add(null);
				}
			}
		}

		protected void SelectAction(Combatant combatant)
		{
			if(combatant != null && combatant.Actions.CanChoose)
			{
				if(!this.performedOrder.Contains(combatant))
				{
					this.performedOrder.Add(combatant);
				}
				if(this.IsGroupAuto(combatant))
				{
					combatant.Actions.ChooseAuto(!combatant.Battle.TurnPerformed);
				}
				else
				{
					combatant.Actions.Choose(!combatant.Battle.TurnPerformed, this.autoCallBattleMenu);
				}
			}
			else
			{
				ORK.Battle.Actions.Add(null);
			}
		}

		public void ClearPlayerChoice()
		{
			this.playerControlled = null;
			this.combatantChoice.Close();
		}

		public void ClearCurrentFaction()
		{
			if(this.currentFaction != null)
			{
				this.currentFaction.Clear();
			}
		}

		public override void CombatantChanged(Combatant oldCombatant, Combatant newCombatant)
		{
			if(this.selectingCombatant == oldCombatant)
			{
				this.selectingCombatant = newCombatant;
				if(this.performedOrder.Contains(oldCombatant))
				{
					this.performedOrder[this.performedOrder.IndexOf(oldCombatant)] = newCombatant;
				}
			}
			if(this.playerControlled != null &&
				this.playerControlled.Contains(oldCombatant))
			{
				if(newCombatant.IsPlayerControlled())
				{
					this.playerControlled[this.playerControlled.IndexOf(oldCombatant)] = newCombatant;
				}
				else
				{
					this.playerControlled.Remove(oldCombatant);
				}
			}
			if(this.currentFaction != null &&
				this.currentFaction.Contains(oldCombatant))
			{
				this.currentFaction[this.currentFaction.IndexOf(oldCombatant)] = newCombatant;
			}
			if(this.phaseOrder != null)
			{
				foreach(KeyValuePair<int, List<Combatant>> pair in this.phaseOrder)
				{
					if(pair.Value != null &&
						pair.Value.Contains(oldCombatant))
					{
						pair.Value[pair.Value.IndexOf(oldCombatant)] = newCombatant;
					}
				}
			}
		}


		/*
		============================================================================
		Action handling functions
		============================================================================
		*/
		protected void GetNextAction()
		{
			ORK.StartCoroutine(this.GetNextAction2());
		}

		protected IEnumerator GetNextAction2()
		{
			this.ClearPlayerChoice();
			yield return null;

			if(!ORK.Battle.BattleEnd && !ORK.Battle.WaitForLastAction)
			{
				this.CheckPhaseCombatants();

				// select next combatant/action to perform
				if(this.phaseOrder.Count > 0)
				{
					// still has actions per turn
					if(this.selectingCombatant != null &&
						this.selectingCombatant.Actions.CanChoose)
					{
						this.SelectAction(this.selectingCombatant);
					}
					// still someone left?
					else if(this.currentFaction.Count > 0)
					{
						this.selectingCombatant = null;
						int canChoose = 0;
						this.playerControlled = new List<Combatant>();
						for(int i = 0; i < this.currentFaction.Count; i++)
						{
							if(this.currentFaction[i].Actions.CanChoose)
							{
								canChoose++;
							}
							if(this.currentFaction[i].IsPlayerControlled())
							{
								this.playerControlled.Add(this.currentFaction[i]);
							}
						}

						if(canChoose > 0)
						{
							// player controlled combatants > wait for player to select next combatant
							if(this.playerControlled.Count > 0 &&
								(this.groupAuto == null || this.groupAuto.Count == 0) &&
								this.combatantChoice != null &&
								this.combatantChoice.useCombatantChoice)
							{
								this.combatantChoice.Show(this.playerControlled);
							}
							else
							{
								this.selectingCombatant = this.currentFaction[0];
								this.currentFaction.RemoveAt(0);
								this.SelectAction(this.selectingCombatant);
							}
						}
						else
						{
							this.NextPhase();
						}
					}
					// phase finished > next phase
					else
					{
						this.selectingCombatant = null;
						this.NextPhase();
					}
				}
				else
				{
					this.StartTurn();
				}
			}
		}

		public override void ActionAdded(BaseAction action)
		{
			if(action != null)
			{
				if(this.currentFaction != null &&
					this.currentFaction.Contains(action.User))
				{
					this.currentFaction.Remove(action.User);
				}
			}

			if(this.activeCommand ||
				(!this.performingActions &&
					// all combatants chose their actions in the current phase?
					this.currentFaction != null && this.currentFaction.Count == 0 &&
					(this.selectingCombatant == null ||
						(!this.selectingCombatant.Actions.IsChoosing &&
						!this.selectingCombatant.Actions.CanChoose))))
			{
				this.performingActions = true;
				this.PerformNextAction();
			}
			else
			{
				this.GetNextAction();
			}
		}

		protected override void PerformNextAction3()
		{
			if(!ORK.Battle.BattleEnd)
			{
				if(ORK.Battle.Actions.Has())
				{
					BaseAction action = ORK.Battle.Actions.NextPerformable();
					if(action != null && !action.IsCastingAbility())
					{
						this.PerformAction(action);
					}
					else if(this.dynamicCombat)
					{
						this.PerformingAction(action);
					}
				}
				else if(this.activeCommand)
				{
					this.GetNextAction();
				}
			}
		}

		public override void PerformingAction(BaseAction action)
		{
			if(this.dynamicCombat &&
				(action == null || !action.isPerforming))
			{
				if(action != null)
				{
					action.isPerforming = true;
				}
				if(this.minTimeBetween > 0)
				{
					ORK.StartCoroutine(this.ActionFinished2(action));
				}
				else
				{
					this.ActionFinished(action);
				}
			}
		}

		public IEnumerator ActionFinished2(BaseAction action)
		{
			yield return new WaitForSeconds(this.minTimeBetween);
			this.ActionFinished(action);
		}

		public override void ActionFinished(BaseAction action)
		{
			if(!ORK.Battle.BattleEnd)
			{
				if(action == null || !action.notifiedFinished ||
					ORK.Battle.WaitForLastAction)
				{
					if(ORK.Battle.Actions.Has())
					{
						if(action != null)
						{
							action.notifiedFinished = true;
						}
						this.PerformNextAction();
					}
					else if(this.activeCommand ||
						this.phaseOrder.Count > 0)
					{
						if(action != null)
						{
							action.notifiedFinished = true;
						}

						if(this.activeCommand &&
							this.selectingCombatant != null &&
							this.selectingCombatant.Battle.CanEndTurn)
						{
							this.selectingCombatant.Battle.EndTurn(this.GetNextAction);
						}
						else
						{
							this.GetNextAction();
						}
					}
					else if(!this.dynamicCombat ||
						(!ORK.Battle.Actions.HasCasting() &&
							!ORK.Battle.Actions.HasActive()))
					{
						if(action != null)
						{
							action.notifiedFinished = true;
						}
						if(this.selectingCombatant != null &&
							this.selectingCombatant.Battle.CanEndTurn)
						{
							this.selectingCombatant.Battle.EndTurn(this.StartTurn);
						}
						else
						{
							this.StartTurn();
						}
					}
				}
				else if(this.activeCommand && this.dynamicCombat &&
					ORK.Battle.Actions.Has())
				{
					if(action != null)
					{
						action.notifiedFinished = true;
					}
					// perform next action without notify
					action = ORK.Battle.Actions.NextPerformable();
					action.notifiedFinished = true;
					if(action != null && !action.IsCastingAbility())
					{
						this.PerformAction(action);
					}
					else if(this.dynamicCombat)
					{
						this.PerformingAction(action);
					}
				}
			}
		}


		/*
		============================================================================
		Battle end functions
		============================================================================
		*/
		public override void EndBattle()
		{
			if(this.combatantChoice != null)
			{
				this.combatantChoice.Close();
			}
		}


		/*
		============================================================================
		Phase event functions
		============================================================================
		*/
		public void EventEnded()
		{
			this.phaseEvent = null;

			// phase start ended
			if(this.phaseEventFlag == 1)
			{
				this.phaseEventFlag = 0;

				this.GetNextAction();
			}
			// phase end ended
			if(this.phaseEventFlag == 2)
			{
				this.performedOrder.Clear();

				// still phases left
				if(this.phaseOrder.Count > 0)
				{
					this.phaseEventFlag = 1;

					this.currentFaction = new List<Combatant>(this.phaseOrder[0].Value);

					this.CheckPhaseCombatants();

					// perform phase start event of current faction
					FactionSetting faction = ORK.Factions.Get(this.phaseOrder[0].Key);
					if(faction.phaseStartAsset != null)
					{
						this.phaseEvent = new PhaseChangeEvent();
						this.phaseEvent.SetData(faction.phaseStartAsset.GetData().ToDataObject());
						this.phaseEvent.SetMembers(this.phaseOrder[0].Value);
						this.phaseEvent.StartEvent(this, null);
					}
					else
					{
						this.EventEnded();
					}
				}
				// new turn
				else
				{
					this.phaseEventFlag = 0;

					this.StartTurn();
				}
			}
		}

		public void DontDestroy()
		{
			if(ORK.Battle.BattleArena != null)
			{
				ORK.Battle.BattleArena.DontDestroy();
			}
		}

		public void OnSceneLoaded()
		{
			if(ORK.Battle.BattleArena != null)
			{
				ORK.Battle.BattleArena.OnSceneLoaded();
			}
		}

		public GameObject GameObject
		{
			get
			{
				if(ORK.Battle.BattleArena != null)
				{
					return ORK.Battle.BattleArena.GameObject;
				}
				return null;
			}
		}
	}
}
