
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.UI
{
	public class ActiveBattleMenu : IChoice, IDragOrigin
	{
		private bool isOpen = false;

		private int menuID = 0;

		private BattleMenu settings;

		private Combatant owner;

		private Combatant commandedBy;


		// list items
		private List<BMItem> items;

		private ChoiceContent[] choices;

		private int[] choiceActions;

		private BattleMenuMode mode = BattleMenuMode.None;

		private Dictionary<BattleMenuMode, int> rememberedSelection = new Dictionary<BattleMenuMode, int>();

		// type selections
		private int currentParentType = -1;

		private Dictionary<int, int> abilityTypeSelection = new Dictionary<int, int>();

		private Dictionary<int, int> itemTypeSelection = new Dictionary<int, int>();


		// special selections
		private BaseAction rayAction;


		// box/content
		private GUIBox box;

		private DialogueContent content;

		private string title = "";

		private float lastUpdate = 0;


		// description
		private GUIBox descBox;


		// selection
		private int currentSelection = 0;

		private TargetHighlight targetHighlight;

		private GameObject userCursorInstance;

		public GameObject raycastUserCursorInstance;

		public GameObject raycastCursorInstance;

		public GUIBox targetOriginBox;


		// breadcrumbs
		private Stack<List<BMItem>> lastItems = new Stack<List<BMItem>>();

		private Stack<int> lastSelections = new Stack<int>();

		private Stack<int> lastParentTypes = new Stack<int>();

		private Stack<BattleMenuMode> lastModes = new Stack<BattleMenuMode>();

		public ActiveBattleMenu(Combatant owner, int menuID)
		{
			this.owner = owner;
			this.menuID = menuID;
			this.settings = ORK.BattleMenus.Get(this.menuID);
			this.targetHighlight = new TargetHighlight(this.owner);
		}

		public string GetTitle()
		{
			if(this.settings.showTitle)
			{
				return this.owner.Faction.ReplaceFactionTexts(
					this.settings.title[ORK.Game.Language].
						Replace("%n", this.owner.GetName()).
						Replace("%d", this.owner.GetDescription()).
						Replace("%i", this.owner.GetIconTextCode()));
			}
			return "";
		}

		public ChoiceContent GetCombatantChoice(Combatant combatant)
		{
			if(this.settings.ownCombatantChoice)
			{
				return this.settings.combatantChoice.GetChoiceContent(combatant);
			}
			else
			{
				return ORK.TextDisplaySettings.combatantChoice.GetChoiceContent(combatant);
			}
		}

		public BattleMenu Settings
		{
			get { return this.settings; }
		}

		public TargetHighlight TargetHighlight
		{
			get { return this.targetHighlight; }
		}

		public int MenuID
		{
			get { return this.menuID; }
		}

		public bool IsOpen
		{
			get { return this.isOpen; }
			set
			{
				if(this.isOpen != value)
				{
					this.isOpen = value;

					if(this.isOpen)
					{
						this.settings.userHighlight.Highlight(this.owner.GameObject, ref this.userCursorInstance);
						this.owner.Actions.IsChoosing = true;

						ORK.Battle.DoBattleMenuBlock(1);
						if(ORK.Battle.IsRealTime())
						{
							if(ORK.BattleSystem.realTime.menuPause)
							{
								if(ORK.BattleSystem.realTime.freezeAction)
								{
									ORK.Game.FreezeTime(true);
								}
							}
							else if(ORK.BattleSystem.realTime.setMenuTimeScale)
							{
								ORK.Game.UnityTimeScale = ORK.BattleSystem.realTime.menuTimeScale;
							}
						}
						ORK.Battle.AddMenuUser(this.owner);

						// play opening audio
						if(this.settings.openClip != null)
						{
							ORK.Audio.PlayOneShot(this.settings.openClip,
								this.settings.openVolume * ORK.Game.SoundVolume);
						}
					}
					else
					{
						this.settings.userHighlight.StopHighlight(this.owner.GameObject, ref this.userCursorInstance);

						ORK.Battle.DoBattleMenuBlock(-1);
						if(ORK.Battle.IsRealTime())
						{
							if(ORK.BattleSystem.realTime.menuPause)
							{
								if(ORK.BattleSystem.realTime.freezeAction)
								{
									ORK.Game.FreezeTime(false);
								}
							}
							else if(ORK.BattleSystem.realTime.setMenuTimeScale)
							{
								ORK.Game.ResetUnityTimeScale();
							}
						}
						ORK.Battle.RemoveMenuUser(this.owner);

						// play closing audio
						if(this.settings.closeClip != null)
						{
							ORK.Audio.PlayOneShot(this.settings.closeClip,
								this.settings.closeVolume * ORK.Game.SoundVolume);
						}
						this.Clear();
					}
				}
			}
		}

		public bool RememberSelection
		{
			get { return this.settings.rememberSelection; }
		}

		public int CurrentParentType
		{
			get { return this.currentParentType; }
			set { this.currentParentType = value; }
		}

		public void Clear()
		{
			this.SetMode(BattleMenuMode.None);
			this.targetHighlight.Clear();
			this.currentSelection = -2;
			this.items = null;

			this.lastSelections.Clear();
			this.lastParentTypes.Clear();
			this.lastItems.Clear();
			this.lastModes.Clear();

			this.title = this.GetTitle();
			this.choices = null;
			this.choiceActions = null;
			this.targetOriginBox = null;

			ORK.BattleSystem.gridSettings.CloseSelections(this.owner);
		}

		public void Close()
		{
			if(this.box != null)
			{
				this.Clear();
				this.box.InitOut();
				this.CloseDescription();
			}
			else
			{
				if(this.IsOpen)
				{
					this.IsOpen = false;
				}
				else
				{
					this.Clear();
				}
				if(this.commandedBy != null)
				{
					this.commandedBy.BattleMenu.Show(true);
					this.commandedBy = null;
				}
			}
		}

		public void CloseSilent()
		{
			if(GUIBox.IsActive(this.box))
			{
				if(this.box.Content != null)
				{
					this.box.Content.controlInterface = null;
				}
				this.box.InitOut();
				this.box = null;
				this.CloseDescription();
			}
		}

		public void Reset(bool call)
		{
			if(call)
			{
				this.targetHighlight.Clear();
				this.Show();
			}
			else
			{
				if(this.box != null)
				{
					if(this.box.Content != null)
					{
						this.box.Content.controlInterface = null;
					}
					this.box.InitOut();
					this.box = null;
					this.CloseDescription();
				}
				this.Clear();
			}
		}

		public bool Controlable
		{
			get { return this.box != null && this.box.Controlable; }
		}

		public GUIBox Box
		{
			get { return this.box; }
		}

		public Combatant CommandedBy
		{
			get { return this.commandedBy; }
			set { this.commandedBy = value; }
		}

		public BattleMenuMode Mode
		{
			get { return this.mode; }
		}

		private void SetMode(BattleMenuMode mode)
		{
			if(this.mode != mode)
			{
				if(BattleMenuMode.Target == this.mode)
				{
					ORK.Battle.IsTargetSelectionActive = false;
				}
				this.mode = mode;
				if(BattleMenuMode.Target == this.mode)
				{
					ORK.Battle.IsTargetSelectionActive = true;
				}
			}
		}


		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		public bool ShowOKButton(GUIBox origin)
		{
			return false;
		}

		public bool ShowCancelButton(GUIBox origin)
		{
			return false;
		}

		public bool IsOKButtonActive(GUIBox origin)
		{
			return false;
		}

		public bool IsCancelButtonActive(GUIBox origin)
		{
			return false;
		}


		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public void Show()
		{
			this.Show(false);
		}

		public void Show(bool reset)
		{
			if(this.box == null || reset)
			{
				this.Clear();
				this.Show(this.settings.GetMenu(this.owner), 0, BattleMenuMode.List);
			}
		}

		public void Show(List<BMItem> list, int selection, BattleMenuMode mode)
		{
			if(ORK.Battle.Grid != null)
			{
				ORK.BattleSystem.gridSettings.CloseSelections(this.owner);
				if(BattleMenuMode.Target == mode)
				{
					ORK.BattleSystem.gridSettings.CloseAlwaysActiveExamineTarget();
				}
			}

			if(!this.isOpen)
			{
				this.IsOpen = true;
			}
			if(this.box != null)
			{
				this.StoreCurrent();
				if(this.box.Content != null)
				{
					this.box.Content.controlInterface = null;
				}
				this.box.InitOut();
				this.box = null;
				this.CloseDescription();
			}

			this.SetMode(mode);
			if(BattleMenuMode.ItemType != this.mode &&
				BattleMenuMode.AbilityType != this.mode)
			{
				this.currentParentType = -1;
			}

			this.items = list;
			this.currentSelection = selection;
			this.CheckList();
			this.lastUpdate = Time.time;

			this.box = ORK.GUIBoxes.Create(this.settings.GetGUIBoxID(this.mode));

			if(this.settings.resetSelection)
			{
				this.currentSelection = 0;
			}

			if(BattleMenuMode.Target == this.mode)
			{
				if(this.settings.selectSelf)
				{
					for(int i = 0; i < this.items.Count; i++)
					{
						if(this.items[i] is TargetBMItem &&
							this.items[i].Contains(this.owner, this.owner))
						{
							this.currentSelection = i;
							break;
						}
					}
				}
				if(this.settings.selectLastTarget)
				{
					for(int i = 0; i < this.items.Count; i++)
					{
						if(this.items[i] is TargetBMItem &&
							this.items[i].ContainsAny(this.owner, this.owner.Battle.LastTargets))
						{
							this.currentSelection = i;
							break;
						}
					}
				}
				this.box.hidden = !ORK.BattleSettings.useTargetMenu;
			}
			// restore selection
			else if(this.RememberSelection &&
				this.rememberedSelection.ContainsKey(this.mode))
			{
				if(BattleMenuMode.AbilityType == this.mode &&
					this.abilityTypeSelection.ContainsKey(this.currentParentType))
				{
					this.currentSelection = this.abilityTypeSelection[this.currentParentType];
				}
				else if(BattleMenuMode.ItemType == this.mode &&
					this.itemTypeSelection.ContainsKey(this.currentParentType))
				{
					this.currentSelection = this.itemTypeSelection[this.currentParentType];
				}
				else
				{
					this.currentSelection = this.rememberedSelection[this.mode];
				}
			}

			this.CreateChoices();

			if(this.currentSelection < 0)
			{
				this.currentSelection = 0;
			}
			else if(this.currentSelection >= this.choices.Length)
			{
				this.currentSelection = this.choices.Length - 1;
			}

			this.content = new DialogueContent("", this.title, this.choices, this, this.currentSelection,
				this.settings.showPortrait ? this.owner.GetPortrait(this.settings.portraitTypeID) : null);
			this.content.header = this.settings.GetHeaderContent(this.mode);

			if(this.settings.showPortrait && this.settings.ownPortraitPosition)
			{
				this.content.setPortraitPosition = this.settings.portraitPosition;
			}

			this.box.inPause = ORK.Battle.IsRealTime() &&
				ORK.BattleSystem.realTime.menuPause &&
				ORK.BattleSystem.realTime.freezeAction;

			this.box.Content = this.content;
			this.box.InitIn();
			this.SelectionChanged(this.currentSelection, this.box);
		}

		private void ShowDescription(string desc)
		{
			// hide description box
			if(this.descBox != null && desc == "" && !this.settings.descAlways)
			{
				this.descBox.InitOut();
				this.descBox = null;
			}
			// show/change description box
			else if(this.settings.useDesc && (desc != "" || this.settings.descAlways))
			{
				if(this.descBox == null)
				{
					this.descBox = ORK.GUIBoxes.Create(this.settings.descBoxID);
					this.descBox.controlable = false;
					this.descBox.InitIn();
				}
				this.descBox.Content = new DialogueContent(desc, this.settings.GetDescriptionTitle(), null, null);
			}
		}

		public void FocusGained(GUIBox origin)
		{

		}

		public void FocusLost(GUIBox origin)
		{

		}

		public void OutOfBoxClick(GUIBox origin)
		{

		}

		private void CloseDescription()
		{
			if(this.descBox != null)
			{
				this.descBox.InitOut();
				this.descBox = null;
			}
		}

		public void Closed(GUIBox origin)
		{
			this.box = null;
			this.content = null;

			if(this.currentSelection == -2)
			{
				this.IsOpen = false;
				if(this.commandedBy != null)
				{
					this.commandedBy.BattleMenu.Show(true);
					this.commandedBy = null;
				}
			}
			else if(this.currentSelection == -1)
			{
				this.Back();
			}
			else if(this.currentSelection >= 0 &&
				this.currentSelection < this.items.Count)
			{
				if(!(this.items[this.currentSelection] is BackBMItem))
				{
					this.StoreCurrent();
				}
				this.items[this.currentSelection].Accepted(this.owner);
			}
		}

		public void Back()
		{
			this.owner.Shortcuts.Active = null;
			this.targetOriginBox = null;

			if(this.lastSelections.Count > 0)
			{
				BattleMenuMode tmpMode = this.lastModes.Pop();
				// back to grid move selection
				if(BattleMenuMode.GridMove == tmpMode)
				{
					this.currentParentType = this.lastParentTypes.Pop();
					this.lastItems.Pop();
					this.lastSelections.Pop();
					this.StartGridMoveSelection(null, this.lastSelections.Count > 0);
				}
				// back to grid orientation selection
				else if(BattleMenuMode.GridOrientation == tmpMode)
				{
					this.currentParentType = this.lastParentTypes.Pop();
					this.lastItems.Pop();
					this.lastSelections.Pop();
					this.StartGridOrientationSelection(null, this.lastSelections.Count > 0);
				}
				// back to grid examine selection
				else if(BattleMenuMode.GridExamine == tmpMode)
				{
					this.currentParentType = this.lastParentTypes.Pop();
					this.lastItems.Pop();
					this.lastSelections.Pop();
					this.StartGridExamine(
						ORK.BattleSystem.gridSettings.SelectedCell,
						this.lastSelections.Count > 0);
				}
				// back to previous menu
				else
				{
					this.currentParentType = this.lastParentTypes.Pop();
					this.Show(this.lastItems.Pop(), this.lastSelections.Pop(), tmpMode);
				}
			}
			else if(ORK.Battle.IsMenuBackAllowed || this.commandedBy != null)
			{
				this.owner.EndBattleMenu(true);
			}
			// target selection from shortcut/control map use
			else if(BattleMenuMode.Target == this.mode)
			{
				this.IsOpen = false;
			}
			else
			{
				this.Show();
			}
		}

		public bool ExternalStoreCurrent(BattleMenuMode nextMode)
		{
			if(this.IsOpen &&
				this.mode != nextMode &&
				(this.lastSelections.Count > 0 ||
					BattleMenuMode.List == this.mode ||
					BattleMenuMode.GridMove == this.mode ||
					BattleMenuMode.GridOrientation == this.mode ||
					BattleMenuMode.GridExamine == this.mode) &&
				BattleMenuMode.Target != this.mode)
			{
				this.StoreCurrent();
				return true;
			}
			return false;
		}

		private void StoreCurrent()
		{
			if(this.items != null ||
				BattleMenuMode.GridMove == this.mode ||
				BattleMenuMode.GridExamine == this.mode ||
				BattleMenuMode.GridOrientation == this.mode)
			{
				this.lastSelections.Push(this.currentSelection);
				this.lastParentTypes.Push(this.currentParentType);
				this.lastItems.Push(this.items);
				this.lastModes.Push(this.mode);
			}
		}

		private void RemoveLastStored()
		{
			if(this.lastSelections.Count > 0)
			{
				this.lastSelections.Pop();
				this.lastParentTypes.Pop();
				this.lastItems.Pop();
				this.lastModes.Pop();
			}
		}


		/*
		============================================================================
		Choice handling functions
		============================================================================
		*/
		public void CreateChoices()
		{
			List<ChoiceContent> cc = new List<ChoiceContent>();
			List<int> ca = new List<int>();
			for(int i = 0; i < this.items.Count; i++)
			{
				this.items[i].CreateDrag(this.owner);
				this.items[i].content.buttonRectTransform = null;
				this.items[i].content.titleRectTransform = null;
				cc.Add(this.items[i].content);
				ca.Add(i);
			}
			this.choices = cc.ToArray();
			this.choiceActions = ca.ToArray();
		}

		public void ChoiceSelected(int index, GUIBox origin)
		{
			if(index >= 0 && index < this.choiceActions.Length)
			{
				this.currentSelection = this.choiceActions[index];

				// remember selection
				this.StoreSelection();

				this.box.InitOut();
				this.CloseDescription();
			}
		}

		public void SelectionChanged(int index, GUIBox origin)
		{
			if(index >= 0 &&
				index < this.choiceActions.Length &&
				this.items != null)
			{
				this.ShowDescription(this.choices[index].description);
				this.currentSelection = this.choiceActions[index];

				// remember selection
				this.StoreSelection();

				// start blinking new target
				if(this.currentSelection >= 0 &&
					this.currentSelection < this.items.Count)
				{
					this.items[this.currentSelection].Selected(this.owner);
				}
			}
		}

		public void Canceled(GUIBox origin)
		{
			if(this.lastSelections.Count > 0)
			{
				this.owner.Shortcuts.Active = null;
				this.targetOriginBox = null;
				this.targetHighlight.Clear();
				this.box.Audio.PlayCancel();
				this.currentSelection = -1;
				this.box.InitOut();
				this.CloseDescription();
			}
			else if(ORK.Battle.IsMenuBackAllowed ||
				this.commandedBy != null)
			{
				this.owner.Shortcuts.Active = null;
				this.targetOriginBox = null;
				this.targetHighlight.Clear();
				this.box.Audio.PlayCancel();
				this.owner.EndBattleMenu(true);
			}
			// target selection from shortcut/control map use
			else if(BattleMenuMode.Target == this.mode)
			{
				this.owner.Shortcuts.Active = null;
				this.targetOriginBox = null;
				this.targetHighlight.Clear();
				this.box.Audio.PlayCancel();
				this.currentSelection = -2;
				this.box.InitOut();
				this.CloseDescription();
			}
		}

		public bool CombatantClicked(Combatant combatant)
		{
			if(this.items != null)
			{
				for(int i = 0; i < this.items.Count; i++)
				{
					if(this.items[i].Contains(this.owner, combatant))
					{
						this.targetHighlight.Clear();
						this.currentSelection = i;
						if(this.box != null)
						{
							this.box.InitOut();
						}
						this.CloseDescription();
						return true;
					}
				}
			}
			return false;
		}

		public bool CombatantCursorOver(Combatant combatant)
		{
			// cursor
			if(BattleMenuMode.Target == this.mode &&
				this.targetHighlight.Shortcut != null)
			{
				if(combatant == null)
				{
					if(!ORK.Control.Cursor.ShowTargetOverBox(
						this.owner, this.targetHighlight.Shortcut))
					{
						ORK.Control.Cursor.ShowTargetNone(
							TargetSettings.Get(this.targetHighlight.Shortcut));
					}
				}
				else if(this.targetHighlight.AvailableTargets.Contains(combatant))
				{
					ORK.Control.Cursor.ShowTargetValid(
						TargetSettings.Get(this.targetHighlight.Shortcut));
				}
				else
				{
					ORK.Control.Cursor.ShowTargetInvalid(
						TargetSettings.Get(this.targetHighlight.Shortcut));
				}
			}
			// select combatant
			if(ORK.BattleSettings.targetCursorOverSelection &&
				(!ORK.BattleSettings.targetCursorOverMouseMoveOnly || ORK.Control.MouseMoved) &&
				combatant != null &&
				this.items != null)
			{
				for(int i = 0; i < this.items.Count; i++)
				{
					if(this.items[i] != null &&
						this.items[i].Contains(this.owner, combatant))
					{
						if(ORK.BattleSettings.rotateToTargetCursorOver)
						{
							this.targetHighlight.RotateToTarget();
						}

						if(this.currentSelection != i &&
							this.box != null &&
							this.box.Content != null)
						{
							this.box.Content.Selection = i;
							return true;
						}
					}
				}
			}
			return false;
		}

		private void StoreSelection()
		{
			if(BattleMenuMode.Target != this.mode &&
				this.RememberSelection)
			{
				if(this.rememberedSelection.ContainsKey(this.mode))
				{
					this.rememberedSelection[this.mode] = this.currentSelection;
				}
				else
				{
					this.rememberedSelection.Add(this.mode, this.currentSelection);
				}
				// parent types
				if(BattleMenuMode.AbilityType == this.mode)
				{
					if(this.abilityTypeSelection.ContainsKey(this.currentParentType))
					{
						this.abilityTypeSelection[this.currentParentType] = this.currentSelection;
					}
					else
					{
						this.abilityTypeSelection.Add(this.currentParentType, this.currentSelection);
					}
				}
				else if(BattleMenuMode.ItemType == this.mode)
				{
					if(this.itemTypeSelection.ContainsKey(this.currentParentType))
					{
						this.itemTypeSelection[this.currentParentType] = this.currentSelection;
					}
					else
					{
						this.itemTypeSelection.Add(this.currentParentType, this.currentSelection);
					}
				}
			}
		}


		/*
		============================================================================
		Update functions
		============================================================================
		*/
		public bool IsSpecialTick
		{
			get
			{
				return this.rayAction != null;
			}
		}

		public bool Tick(GUIBox origin)
		{
			if(this.rayAction != null)
			{
				if(ORK.InputKeys.Get(this.box != null ?
						this.box.Controls.cancelKeyID :
						ORK.GameControls.menuControls.cancelKeyID).GetButton())
				{
					if(this.box != null)
					{
						this.box.Audio.PlayCancel();
					}
					else
					{
						ORK.MenuSettings.audio.PlayCancel();
					}
					this.rayAction.targetRaycast.Stop(this.owner);
					this.rayAction = null;
					this.Back();
				}
				else
				{
					this.rayAction.targetRaycast.Tick(this.owner);
				}
			}
			else if((Time.time - this.lastUpdate) > this.settings.updateInterval)
			{
				this.CheckList();
				this.lastUpdate = Time.time;
			}
			if(BattleMenuMode.Target == this.mode &&
				GUIBox.IsActive(this.box) &&
				this.box.Content != null &&
				this.items != null)
			{
				if(ORK.InputKeys.Get(ORK.BattleSettings.targetNextKey).GetButton())
				{
					this.box.Audio.PlayCursorMove();
					int selection = this.currentSelection + 1;
					if(selection >= this.items.Count)
					{
						selection = 0;
					}
					if(selection < this.items.Count &&
						this.items[selection] is BackBMItem)
					{
						selection++;
						if(selection >= this.items.Count)
						{
							selection = 0;
						}
					}
					this.box.Content.Selection = selection;
					return true;
				}
				else if(ORK.InputKeys.Get(ORK.BattleSettings.targetPreviousKey).GetButton())
				{
					this.box.Audio.PlayCursorMove();
					int selection = this.currentSelection - 1;
					if(selection < 0)
					{
						selection = this.items.Count - 1;
					}
					if(selection < this.items.Count &&
						this.items[selection] is BackBMItem)
					{
						selection--;
						if(selection < 0)
						{
							selection = this.items.Count - 1;
						}
					}
					this.box.Content.Selection = selection;
					return true;
				}
				else if(ORK.InputKeys.Get(ORK.BattleSettings.targetNearestKey).GetButton())
				{
					Combatant nearest = TargetHelper.GetNearestTarget(this.owner,
						this.targetHighlight.AvailableTargets, Consider.Ignore);
					for(int i = 0; i < this.items.Count; i++)
					{
						if(this.currentSelection != i &&
							this.items[i].Contains(this.owner, nearest))
						{
							this.box.Audio.PlayCursorMove();
							this.box.Content.Selection = i;
							return true;
						}
					}
				}
			}
			return false;
		}

		public bool UnfocusedTick(GUIBox origin)
		{
			return false;
		}

		public bool NotControlableTick(GUIBox origin)
		{
			return false;
		}

		private bool CheckList()
		{
			bool changed = false;
			if(this.items != null)
			{
				for(int i = 0; i < this.items.Count; i++)
				{
					if(this.items[i].ActiveCheck(this.owner))
					{
						changed = true;
					}
				}
			}
			return changed;
		}

		public void ChangeAbilityLevel(int change)
		{
			if(this.currentSelection >= 0 &&
				this.currentSelection < this.items.Count)
			{
				if(this.items[this.currentSelection].ChangeUseLevel(change, this.owner))
				{
					this.CreateChoices();
					if(this.content != null)
					{
						this.content.choice = this.choices;
						this.content.newContent = true;
					}
				}
			}
		}


		/*
		============================================================================
		Raycast functions
		============================================================================
		*/
		public BaseAction RayAction
		{
			get { return this.rayAction; }
			set
			{
				this.rayAction = value;
				if(this.rayAction != null)
				{
					this.SetMode(BattleMenuMode.Target);
					if(!this.isOpen)
					{
						this.IsOpen = true;
					}
					if(ORK.Battle.Grid != null)
					{
						ORK.BattleSystem.gridSettings.CloseAlwaysActiveExamineTarget();
					}
					this.owner.Shortcuts.Active = this.rayAction.Shortcut;
					this.rayAction.targetRaycast.Start(this.owner);
				}
			}
		}

		public void SetRayPoint(Vector3 point)
		{
			if(this.rayAction != null)
			{
				this.rayAction.targetRaycast.Stop(this.owner);
				this.rayAction.rayTargetSet = true;
				this.rayAction.rayPoint = point;
				this.AddAction(this.rayAction);
				this.rayAction = null;
			}
		}


		/*
		============================================================================
		Action functions
		============================================================================
		*/
		public bool StartTargetSelection(IShortcut shortcut)
		{
			bool used = false;
			bool stored = this.ExternalStoreCurrent(BattleMenuMode.Target);
			List<BMItem> tmpItems = this.items;
			this.items = null;

			BaseAction tmpRayAction = this.rayAction;
			if(this.rayAction != null)
			{
				this.rayAction.targetRaycast.Stop(this.owner);
				this.rayAction = null;
			}

			if(shortcut is AbilityShortcut)
			{
				used = new AbilityBMItem((AbilityShortcut)shortcut, null).Accepted(this.owner);
			}
			else if(shortcut is ItemShortcut)
			{
				used = new ItemBMItem((ItemShortcut)shortcut, null).Accepted(this.owner);
			}

			if(!used)
			{
				if(stored)
				{
					this.RemoveLastStored();
				}
				this.items = tmpItems;

				if(this.items != null &&
					this.currentSelection >= 0 &&
					this.currentSelection < this.items.Count)
				{
					this.items[this.currentSelection].Selected(this.owner);
				}

				if(BattleMenuMode.GridMove == this.mode)
				{
					ORK.BattleSystem.gridSettings.moveCommand.Restart(this.owner);
				}
				else if(BattleMenuMode.GridOrientation == this.mode)
				{
					ORK.BattleSystem.gridSettings.orientationSelection.Restart(this.owner);
				}
				else if(BattleMenuMode.GridExamine == this.mode)
				{
					ORK.BattleSystem.gridSettings.examine.Restart(this.owner);
				}
				else if(tmpRayAction != null)
				{
					this.RayAction = tmpRayAction;
				}
			}
			return used;
		}

		public void StopTargetSelection()
		{
			if(BattleMenuMode.Target == this.mode)
			{
				if(this.lastSelections.Count > 0)
				{
					this.targetHighlight.Clear();
					this.currentSelection = -1;
					if(this.box != null)
					{
						this.box.InitOut();
					}
					this.CloseDescription();
				}
				else if(ORK.Battle.IsMenuBackAllowed ||
					this.commandedBy != null)
				{
					this.targetHighlight.Clear();
					this.owner.EndBattleMenu(true);
				}
				// target selection from shortcut/control map use
				else if(BattleMenuMode.Target == this.mode)
				{
					this.targetHighlight.Clear();
					this.currentSelection = -2;
					if(this.box != null)
					{
						this.box.InitOut();
					}
					this.CloseDescription();
				}
			}
			else if(BattleMenuMode.GridMove == this.mode)
			{
				ORK.BattleSystem.gridSettings.moveCommand.Close(false);
			}
			else if(BattleMenuMode.GridOrientation == this.mode)
			{
				ORK.BattleSystem.gridSettings.orientationSelection.Close(false);
			}
			else if(BattleMenuMode.GridExamine == this.mode)
			{
				ORK.BattleSystem.gridSettings.examine.Close();
			}
		}


		/*
		============================================================================
		Grid functions
		============================================================================
		*/
		public void StartGridMoveSelection(GridMoveShortcut gridMoveShortcut, bool backToMenu)
		{
			this.SetMode(BattleMenuMode.GridMove);
			this.targetHighlight.Clear();
			this.items = null;
			this.IsOpen = true;

			if(backToMenu)
			{
				ORK.BattleSystem.gridSettings.moveCommand.Start(
					this.owner, gridMoveShortcut, this.EndGridMoveSelection);
			}
			else
			{
				ORK.BattleSystem.gridSettings.moveCommand.Start(
					this.owner, gridMoveShortcut, null);
			}
		}

		public void EndGridMoveSelection(bool accepted)
		{
			if(!accepted)
			{
				this.Back();
			}
		}

		public void EndGridMoveSelectionClose(bool accepted)
		{
			if(!accepted)
			{
				this.IsOpen = false;
			}
		}

		public void StartGridOrientationSelection(GridOrientationShortcut gridOrientationShortcut, bool backToMenu)
		{
			this.SetMode(BattleMenuMode.GridOrientation);
			this.targetHighlight.Clear();
			this.items = null;
			this.IsOpen = true;

			if(backToMenu)
			{
				ORK.BattleSystem.gridSettings.orientationSelection.Start(
					this.owner, gridOrientationShortcut, this.EndGridOrientationSelection, true);
			}
			else
			{
				ORK.BattleSystem.gridSettings.orientationSelection.Start(
					this.owner, gridOrientationShortcut, null, true);
			}
		}

		public void EndGridOrientationSelection(bool accepted)
		{
			this.Back();
		}

		public void EndGridOrientationSelectionClose(bool accepted)
		{
			this.IsOpen = false;
		}

		public void StartGridExamine(BattleGridCellComponent selectedCell, bool backToMenu)
		{
			this.SetMode(BattleMenuMode.GridExamine);
			this.targetHighlight.Clear();
			this.items = null;
			this.IsOpen = true;

			if(backToMenu)
			{
				ORK.BattleSystem.gridSettings.examine.Start(
					this.owner, selectedCell, this.Back);
			}
			else
			{
				ORK.BattleSystem.gridSettings.examine.Start(
					this.owner, selectedCell, null);
			}
		}

		public void EndGridExamineClose()
		{
			this.IsOpen = false;
		}

		public void StartGridTargetCellSelection(IShortcut shortcut)
		{
			this.SetMode(BattleMenuMode.Target);
			this.targetHighlight.Clear();
			this.IsOpen = true;

			ORK.BattleSystem.gridSettings.targetCellSelection.Start(
				this.owner, shortcut, this.EndGridTargetCellSelection);
		}

		public void EndGridTargetCellSelection(bool accepted)
		{
			if(!accepted)
			{
				this.targetHighlight.Clear();
				this.Back();
			}
		}


		/*
		============================================================================
		Drag and drop functions
		============================================================================
		*/
		public void Dropped(DragInfo drag)
		{

		}

		public bool DroppedOnCombatant(Combatant c, DragInfo drag)
		{
			if(drag != null)
			{
				if(this.commandedBy != null)
				{
					BaseAction action = drag.GetAction();
					if(action != null)
					{
						action.SetTarget(c);
						this.AddAction(action);
						return true;
					}
				}
				else
				{
					return drag.UseOn(c, true);
				}
			}
			return false;
		}

		public bool DroppedToWorld(Vector3 position, DragInfo drag)
		{
			return false;
		}


		/*
		============================================================================
		Action functions
		============================================================================
		*/
		public void AddAction(BaseAction action)
		{
			this.targetHighlight.Clear();

			if(ORK.BattleSettings.showTargetConfirmation &&
				(action is AbilityAction || action is ItemAction) &&
				ORK.BattleSettings.targetConfirmation.battleSystemCheck.Check())
			{
				ORK.BattleSettings.targetConfirmation.Show(action,
					delegate (bool accepted)
					{
						if(accepted)
						{
							this.DoAddAction(action);
						}
						else
						{
							this.Back();
						}
					});
			}
			else
			{
				this.DoAddAction(action);
			}
		}

		private void DoAddAction(BaseAction action)
		{
			this.owner.Shortcuts.Active = null;
			this.targetOriginBox = null;

			if(this.commandedBy != null)
			{
				this.owner.Actions.AddNextAction(action, NextBattleActionChange.Set);
				this.owner.EndBattleMenu(true);
			}
			else
			{
				this.owner.Actions.Add(action, false);
			}
		}
	}
}
