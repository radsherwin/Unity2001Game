﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GridCellEventCall
	{
		private BattleGridCellComponent cell;

		private GridCellEvent settings;

		public GridCellEventCall(BattleGridCellComponent cell, GridCellEvent settings)
		{
			this.cell = cell;
			this.settings = settings;
		}

		public void Start(List<Combatant> targets, Notify finishedCallback)
		{
			this.settings.StartEvent(this.cell, targets, finishedCallback);
		}
	}
}
