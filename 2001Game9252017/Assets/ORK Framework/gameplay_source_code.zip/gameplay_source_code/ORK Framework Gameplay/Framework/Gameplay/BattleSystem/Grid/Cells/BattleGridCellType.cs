﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BattleGridCellType : BaseLanguageData, IContentSimple
	{
		[ORKEditorInfo("Base Settings", "Set the name and base settings of this grid cell type.", "",
			endFoldout=true)]
		public GridCellPrefab prefab = new GridCellPrefab();


		// cell settings
		[ORKEditorHelp("Blocked", "This is a blocked cell, i.e. combatants can't move on it.", "")]
		[ORKEditorInfo("Cell Settings", "Define settings that affect cells using this grid cell type.", "")]
		public bool blocked = false;

		[ORKEditorHelp("Passable", "The blocked cell can still be moved over by combatants.\n" +
			"I.e. combatant's can't stop on the cell, but can move over it on their path.", "")]
		[ORKEditorLayout("blocked", true, endCheckGroup=true)]
		public bool passable = false;

		[ORKEditorLayout("blocked", false, endCheckGroup=true)]
		public GridDeploymentCell deployment = new GridDeploymentCell();

		[ORKEditorInfo("Move Cost", "Defines how much moving on/over this cell will reduce a combatant's move points.", "",
			endFoldout=true, endFolds=2)]
		[ORKEditorLayout(new string[] { "blocked", "passable" },
			new System.Object[] { false, true },
			needed=Needed.One, endCheckGroup=true)]
		public FloatValue moveCost = new FloatValue(1);


		// cell events
		[ORKEditorInfo("Cell Events", "A cell event can perform abilities and game events on combatants that " +
			"move to/over or start/end their turn on cells of this type.", "",
			endFoldout=true)]
		[ORKEditorArray(false, "Add Cell Event", "Adds a cell event (abilities and game events) that can be performed on combatants on cells of this type.", "",
			"Remove", "Removes this cell event.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[]
			{
				"Cell Event", "Define when this cell event will be performed and what abilities and game events will be used.", ""
			})]
		public GridCellEvent[] cellEvent = new GridCellEvent[0];

		public BattleGridCellType()
		{

		}

		public BattleGridCellType(string name) : base(name)
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<string>("name"))
			{
				string name = "";
				data.Get("name", ref name);
				this.languageInfo = new LanguageInfo[ORK.Languages.Count];
				for(int i = 0; i < this.languageInfo.Length; i++)
				{
					this.languageInfo[i] = new LanguageInfo(name);
				}
			}
		}


		/*
		============================================================================
		Move cost functions
		============================================================================
		*/
		public string ReplaceMoveCosts(string text, Combatant user)
		{
			float cost = this.moveCost.GetValue(user, user);
			return text.
				Replace("%2", cost.ToString("0.00")).
				Replace("%1", cost.ToString("0.0")).
				Replace("%", cost.ToString("0"));
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public int ID
		{
			get { return this.realID; }
		}

		public string GetName()
		{
			return this.ReplaceMoveCosts(
				this.languageInfo[ORK.Game.Language].GetName(),
				ORK.Game.ActiveGroup.Leader);
		}

		public string GetName(Combatant user)
		{
			return this.ReplaceMoveCosts(
				this.languageInfo[ORK.Game.Language].GetName(), user);
		}

		public string GetDescription()
		{
			return this.ReplaceMoveCosts(
				this.languageInfo[ORK.Game.Language].GetDescription(),
				ORK.Game.ActiveGroup.Leader);
		}

		public string GetDescription(Combatant user)
		{
			return this.ReplaceMoveCosts(
				this.languageInfo[ORK.Game.Language].GetDescription(), user);
		}

		public string GetIconTextCode()
		{
			return TextCode.BattleGridCellIcon + this.realID + "#";
		}

		public Texture GetIcon()
		{
			return this.languageInfo[ORK.Game.Language].GetIcon();
		}

		public GUIContent GetContent()
		{
			GUIContent content = this.languageInfo[ORK.Game.Language].GetContent();
			content.text = this.ReplaceMoveCosts(content.text, ORK.Game.ActiveGroup.Leader);
			return content;
		}

		public GUIContent GetContent(Combatant user)
		{
			GUIContent content = this.languageInfo[ORK.Game.Language].GetContent();
			content.text = this.ReplaceMoveCosts(content.text, user);
			return content;
		}
	}
}
