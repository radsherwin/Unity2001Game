﻿
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class AIRuleAction : BaseData
	{
		public ActionSelection actionSettings = new ActionSelection();

		// TODO: target settings, e.g. use requirements?

		public AIRuleAction()
		{

		}
	}
}
