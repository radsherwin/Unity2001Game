﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GridHighlight : BaseData
	{
		[ORKEditorHelp("Use Highlight", "Use this cell highlight.", "")]
		public bool enable = false;


		// highlight settings
		[ORKEditorHelp("Own Highlight Settings", "This grid highlight defines its own highlight settings.\n" +
			"If disabled, a selected base highlight will be used.", "")]
		[ORKEditorLayout("enable", true)]
		public bool ownHighlight = false;

		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("ownHighlight", true, autoInit=true)]
		public BaseGridHighlight highlight;

		[ORKEditorHelp("Base Highlight", "Select which base highlight will be used:\n" +
			"- Area: The area highlight.\n" +
			"- Selection: The selection highlight.\n" +
			"- No Selection: The no selection highlight.", "")]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public BaseGridHighlightType baseType = BaseGridHighlightType.Area;

		public GridHighlight()
		{

		}

		public GridHighlight(BaseGridHighlightType baseType)
		{
			this.baseType = baseType;
		}


		/*
		============================================================================
		Highlight functions
		============================================================================
		*/
		public void Tick(float t)
		{
			if(this.enable && this.ownHighlight)
			{
				this.highlight.Tick(t);
			}
		}

		public void GetColorFade(ref float time, ref bool reverting)
		{
			if(this.ownHighlight)
			{
				this.highlight.GetColorFade(ref time, ref reverting);
			}
			else if(BaseGridHighlightType.Area == this.baseType)
			{
				ORK.BattleSystem.gridHighlights.areaHighlight.GetColorFade(ref time, ref reverting);
			}
			else if(BaseGridHighlightType.Selection == this.baseType)
			{
				ORK.BattleSystem.gridHighlights.selectionHighlight.GetColorFade(ref time, ref reverting);
			}
			else if(BaseGridHighlightType.NoSelection == this.baseType)
			{
				ORK.BattleSystem.gridHighlights.noSelectionHighlight.GetColorFade(ref time, ref reverting);
			}
		}


		public void Highlight(BattleGridCellComponent cell)
		{
			if(this.enable && cell != null)
			{
				if(this.ownHighlight)
				{
					this.highlight.Highlight(cell);
				}
				else if(BaseGridHighlightType.Area == this.baseType)
				{
					ORK.BattleSystem.gridHighlights.areaHighlight.Highlight(cell);
				}
				else if(BaseGridHighlightType.Selection == this.baseType)
				{
					ORK.BattleSystem.gridHighlights.selectionHighlight.Highlight(cell);
				}
				else if(BaseGridHighlightType.NoSelection == this.baseType)
				{
					ORK.BattleSystem.gridHighlights.noSelectionHighlight.Highlight(cell);
				}
			}
		}

		public void StopHighlight(BattleGridCellComponent cell)
		{
			if(this.enable && cell != null)
			{
				if(this.ownHighlight)
				{
					this.highlight.StopHighlight(cell);
				}
				else if(BaseGridHighlightType.Area == this.baseType)
				{
					ORK.BattleSystem.gridHighlights.areaHighlight.StopHighlight(cell);
				}
				else if(BaseGridHighlightType.Selection == this.baseType)
				{
					ORK.BattleSystem.gridHighlights.selectionHighlight.StopHighlight(cell);
				}
				else if(BaseGridHighlightType.NoSelection == this.baseType)
				{
					ORK.BattleSystem.gridHighlights.noSelectionHighlight.StopHighlight(cell);
				}
			}
		}
	}
}
