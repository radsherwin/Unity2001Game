﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GroupMemberSelection : BaseData
	{
		[ORKEditorHelp("Member", "Select how the group member will be selected:\n" +
			"- Combatant: A defined combatant.\n" +
			"- Leader: The leader of the group.\n" +
			"- Index: The combatant at a defined index of the group.\n" +
			"- Offset: The combatant at a defined offset to the used combatant.", "")]
		public GroupMemberSelectionType type = GroupMemberSelectionType.Combatant;


		// combatant
		[ORKEditorHelp("Combatant", "Select the combatant that will be used.\n" +
			"If the combatant isn't a member of the group, no combatant is used.", "")]
		[ORKEditorInfo(ORKDataType.Combatant)]
		[ORKEditorLayout("type", GroupMemberSelectionType.Combatant, endCheckGroup=true)]
		public int combatantID = 0;


		// index
		[ORKEditorHelp("Member Index", "The index of the group member that will be used.\n" +
			"Uses the leader if the index is outside of the available range.", "")]
		[ORKEditorLayout("type", GroupMemberSelectionType.Index, endCheckGroup=true)]
		public int index = 0;


		// offset
		[ORKEditorHelp("Member Offset", "The index of the group member that will be used.", "")]
		[ORKEditorLayout("type", GroupMemberSelectionType.Offset, endCheckGroup=true)]
		public int offset = 0;


		public GroupMemberSelection()
		{

		}

		public Combatant GetBattleGroupMember(Combatant combatant)
		{
			if(GroupMemberSelectionType.Combatant == this.type)
			{
				return combatant.Group.GetBattle(this.combatantID);
			}
			else if(GroupMemberSelectionType.Leader == this.type)
			{
				return combatant.Group.BattleLeader;
			}
			else if(GroupMemberSelectionType.Index == this.type)
			{
				return combatant.Group.BattleMemberAt(this.index);
			}
			else if(GroupMemberSelectionType.Offset == this.type)
			{
				return combatant.Group.GetOffset(combatant, this.offset, true);
			}
			return null;
		}

		public Combatant GetGroupMember(Combatant combatant)
		{
			if(GroupMemberSelectionType.Combatant == this.type)
			{
				return combatant.Group.Get(this.combatantID);
			}
			else if(GroupMemberSelectionType.Leader == this.type)
			{
				return combatant.Group.Leader;
			}
			else if(GroupMemberSelectionType.Index == this.type)
			{
				return combatant.Group.MemberAt(this.index);
			}
			else if(GroupMemberSelectionType.Offset == this.type)
			{
				return combatant.Group.GetOffset(combatant, this.offset, false);
			}
			return null;
		}
	}
}
