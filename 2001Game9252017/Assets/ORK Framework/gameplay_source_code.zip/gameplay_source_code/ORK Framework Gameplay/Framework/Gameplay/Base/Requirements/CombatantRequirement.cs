
using System;

namespace ORKFramework
{
	public class CombatantRequirement : BaseData
	{
		[ORKEditorHelp("Combatant", "The selected combatant is required.", "")]
		[ORKEditorInfo(ORKDataType.Combatant)]
		public int id = 0;
		
		[ORKEditorHelp("Needed", "Either all or only one requirement must be met.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75, labelText="Status Requirements")]
		public Needed needed = Needed.All;
		
		[ORKEditorArray(false, "Add Status Requirement", "Adds a status requirement.", "", 
			"Remove", "Removes the status requirement", "", isCopy=true, isMove=true, 
			foldout=true, foldoutText=new string[] {
				"Status Requirement", "Define the status requirement that must be valid for this combatant.", ""
		})]
		public StatusRequirement[] req = new StatusRequirement[0];
		
		public CombatantRequirement()
		{
			
		}
		
		public bool Check()
		{
			Combatant c = ORK.Game.ActiveGroup.GetMember(this.id);
			if(c != null && 
				StatusRequirement.Check(c, this.req, this.needed))
			{
				return true;
			}
			return false;
		}
	}
}

