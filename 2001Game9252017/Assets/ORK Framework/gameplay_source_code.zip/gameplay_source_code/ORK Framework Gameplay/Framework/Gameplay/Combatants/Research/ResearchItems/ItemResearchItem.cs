﻿
using UnityEngine;
using ORKFramework.AI;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ItemResearchItem : BaseData, IContent
	{
		[ORKEditorHelp("Item Type", "Select the type, either an item, weapon, armor, currency (money), " +
			"AI behaviour, AI ruleset or crafting recipe.", "")]
		public ItemDropType type = ItemDropType.Item;

		[ORKEditorHelp("Selection", "Select the item based on the selected type.", "")]
		[ORKEditorInfo(isPopup=true, itemFieldName="type")]
		public int id = 0;

		[ORKEditorHelp("Level", "Select the level of the equipment.\n" +
			"If the level exceeds the maximum level of the equipment, the maximum level is used.", "")]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout(new string[] {"type", "type"},
			new System.Object[] {ItemDropType.Weapon, ItemDropType.Armor}, needed=Needed.One,
			endCheckGroup=true)]
		public int level = 1;

		[ORKEditorInfo(labelText="Quantity", label=new string[] {
			"The quantity that will be added."
		})]
		public FloatValue quantityValue = new FloatValue(1);

		[ORKEditorInfo(labelText="Chance (%)", label=new string[] {
			"The chance the item will be added."
		})]
		public FloatValue chanceValue = new FloatValue(100);


		// notifications
		[ORKEditorHelp("Show Notification", "Adding the item will display a notification.", "")]
		[ORKEditorInfo(separator=true)]
		public bool showNotification = true;

		[ORKEditorHelp("Show Console", "Adding the item will be displayed in the console.", "")]
		public bool showConsole = true;

		public ItemResearchItem()
		{

		}

		public Portrait GetPortrait()
		{
			if(this.IsItem())
			{
				Item item = ORK.Items.Get(this.id);
				if(item.usePortrait)
				{
					return item.portrait;
				}
			}
			else if(this.IsWeapon())
			{
				Weapon weapon = ORK.Weapons.Get(this.id);
				if(weapon.usePortrait)
				{
					return weapon.portrait;
				}
			}
			else if(this.IsArmor())
			{
				Armor armor = ORK.Armors.Get(this.id);
				if(armor.usePortrait)
				{
					return armor.portrait;
				}
			}
			else if(this.IsCurrency())
			{
				Currency currency = ORK.Currencies.Get(this.id);
				if(currency.usePortrait)
				{
					return currency.portrait;
				}
			}
			else if(this.IsAIBehaviour())
			{
				AIBehaviour behaviour = ORK.AIBehaviours.Get(this.id);
				if(behaviour.usePortrait)
				{
					return behaviour.portrait;
				}
			}
			else if(this.IsAIRuleset())
			{
				AIRuleset ruleset = ORK.AIRulesets.Get(this.id);
				if(ruleset.usePortrait)
				{
					return ruleset.portrait;
				}
			}
			else if(this.IsCraftingRecipe())
			{
				CraftingRecipe recipe = ORK.CraftingRecipes.Get(this.id);
				if(recipe.usePortrait)
				{
					return recipe.portrait;
				}
			}
			return null;
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public int ID
		{
			get { return this.id; }
		}

		public int TypeID
		{
			get
			{
				if(this.IsItem())
				{
					return ORK.Items.Get(this.id).itemType;
				}
				else if(this.IsWeapon())
				{
					return ORK.Weapons.Get(this.id).itemType;
				}
				else if(this.IsArmor())
				{
					return ORK.Armors.Get(this.id).itemType;
				}
				else if(this.IsCurrency())
				{
					return ORK.Currencies.Get(this.id).typeID;
				}
				else if(this.IsAIBehaviour())
				{
					return ORK.AIBehaviours.Get(this.id).typeID;
				}
				else if(this.IsAIRuleset())
				{
					return ORK.AIRulesets.Get(this.id).typeID;
				}
				else if(this.IsCraftingRecipe())
				{
					return ORK.CraftingRecipes.Get(this.id).typeID;
				}
				return -1;
			}
		}

		public string GetName()
		{
			return this.CreateShortcut(1).GetName();
		}

		public string GetDescription()
		{
			return this.CreateShortcut(1).GetDescription();
		}

		public string GetIconTextCode()
		{
			return this.CreateShortcut(1).GetIconTextCode();
		}

		public Texture GetIcon()
		{
			return this.CreateShortcut(1).GetIcon();
		}

		public GUIContent GetContent()
		{
			return this.CreateShortcut(1).GetContent();
		}

		public IContentSimple GetTypeContent()
		{
			if(this.IsItem())
			{
				return ORK.ItemTypes.Get(ORK.Items.Get(this.id).itemType);
			}
			else if(this.IsWeapon())
			{
				return ORK.ItemTypes.Get(ORK.Weapons.Get(this.id).itemType);
			}
			else if(this.IsArmor())
			{
				return ORK.ItemTypes.Get(ORK.Armors.Get(this.id).itemType);
			}
			else if(this.IsCurrency())
			{
				return ORK.ItemTypes.Get(ORK.Currencies.Get(this.id).typeID);
			}
			else if(this.IsAIBehaviour())
			{
				return ORK.AITypes.Get(ORK.AIBehaviours.Get(this.id).typeID);
			}
			else if(this.IsAIRuleset())
			{
				return ORK.AITypes.Get(ORK.AIRulesets.Get(this.id).typeID);
			}
			else if(this.IsCraftingRecipe())
			{
				return ORK.CraftingTypes.Get(ORK.CraftingRecipes.Get(this.id).typeID);
			}
			return null;
		}

		public string GetInfo(Combatant c)
		{
			return "";
		}


		/*
		============================================================================
		Shortcut functions
		============================================================================
		*/
		public IShortcut CreateShortcut(Combatant user, Combatant target)
		{
			return this.CreateShortcut((int)this.quantityValue.GetValue(user, target));
		}

		public IShortcut CreateShortcut(int quantity)
		{
			if(this.IsItem())
			{
				return new ItemShortcut(this.id, quantity);
			}
			else if(this.IsWeapon())
			{
				return new EquipShortcut(EquipSet.Weapon, this.id, this.level, quantity);
			}
			else if(this.IsArmor())
			{
				return new EquipShortcut(EquipSet.Armor, this.id, this.level, quantity);
			}
			else if(this.IsCurrency())
			{
				return new MoneyShortcut(this.id, quantity);
			}
			else if(this.IsAIBehaviour())
			{
				return new AIBehaviourShortcut(this.id, quantity);
			}
			else if(this.IsAIRuleset())
			{
				return new AIRulesetShortcut(this.id, quantity);
			}
			else if(this.IsCraftingRecipe())
			{
				return new CraftingRecipeShortcut(this.id, quantity);
			}
			return null;
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool IsItem()
		{
			return ItemDropType.Item == this.type;
		}

		public bool IsWeapon()
		{
			return ItemDropType.Weapon == this.type;
		}

		public bool IsArmor()
		{
			return ItemDropType.Armor == this.type;
		}

		public bool IsCurrency()
		{
			return ItemDropType.Currency == this.type;
		}

		public bool IsAIBehaviour()
		{
			return ItemDropType.AIBehaviour == this.type;
		}

		public bool IsAIRuleset()
		{
			return ItemDropType.AIRuleset == this.type;
		}

		public bool IsCraftingRecipe()
		{
			return ItemDropType.CraftingRecipe == this.type;
		}

		public bool CheckChance(Combatant user, Combatant target)
		{
			return ORK.GameSettings.CheckRandom(this.chanceValue.GetValue(user, target));
		}


		/*
		============================================================================
		Learning functions
		============================================================================
		*/
		public void ResearchFinished(Combatant combatant)
		{
			combatant.Inventory.Add(
				this.CreateShortcut((int)this.quantityValue.GetValue(combatant, combatant)),
				this.showNotification, this.showConsole);
		}
	}
}
