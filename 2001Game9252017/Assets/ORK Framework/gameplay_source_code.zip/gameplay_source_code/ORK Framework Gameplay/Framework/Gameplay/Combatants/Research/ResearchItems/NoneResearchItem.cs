﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class NoneResearchItem : BaseData, IContentSimple
	{
		[ORKEditorInfo("Content Information", "Set the name, description and icon.", "", endFoldout=true)]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		public LanguageInfo[] languageInfo = ArrayHelper.CreateArray<LanguageInfo>(ORK.Languages.Count);

		public NoneResearchItem()
		{

		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public int ID
		{
			get { return -1; }
		}

		public string GetName()
		{
			return this.languageInfo[ORK.Game.Language].GetName();
		}

		public string GetDescription()
		{
			return this.languageInfo[ORK.Game.Language].GetDescription();
		}

		public string GetIconTextCode()
		{
			return "";
		}

		public Texture GetIcon()
		{
			return this.languageInfo[ORK.Game.Language].GetIcon();
		}

		public GUIContent GetContent()
		{
			return this.languageInfo[ORK.Game.Language].GetContent();
		}
	}
}
