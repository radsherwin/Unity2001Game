
using System.Collections.Generic;
using UnityEngine;

namespace ORKFramework.UI
{
	public class TargetBMItem : BMItem
	{
		private List<Combatant> targets;

		private IShortcut shortcut;

		public TargetBMItem(ChoiceContent content, IShortcut shortcut, List<Combatant> targets)
		{
			this.content = content;
			this.shortcut = shortcut;
			this.targets = targets;
		}

		public override void CreateDrag(Combatant owner)
		{
			// portrait
			if(this.content.portrait == null && this.targets != null &&
				owner.BattleMenu.Settings.showTargetPortraits)
			{
				for(int i = 0; i < this.targets.Count; i++)
				{
					if(this.targets[i] != null)
					{
						this.content.portrait = this.targets[i].GetPortrait(
							owner.BattleMenu.Settings.targetPortraitTypeID);
						if(this.content.portrait != null)
						{
							return;
						}
					}
				}
			}
		}

		public override bool ActiveCheck(Combatant owner)
		{
			bool tmp = this.content.Active;
			this.content.Active = false;

			if(this.shortcut is AbilityShortcut &&
				this.shortcut.CanUse(owner,
					AbilityActionType.CounterAttack != ((AbilityShortcut)this.shortcut).Type,
					true))
			{
				for(int i = 0; i < this.targets.Count; i++)
				{
					if(((AbilityShortcut)this.shortcut).InRange(owner, this.targets[i]) &&
						((AbilityShortcut)this.shortcut).CanTarget(owner, this.targets[i]))
					{
						this.content.Active = true;
						break;
					}
				}
			}
			else if(this.shortcut is ItemShortcut &&
				this.shortcut.CanUse(owner, true, true) &&
				owner.Inventory.HasItem(this.shortcut.ID, 1))
			{
				for(int i = 0; i < this.targets.Count; i++)
				{
					if(((ItemShortcut)this.shortcut).Setting.InRange(owner, this.targets[i]) &&
						((ItemShortcut)this.shortcut).CanTarget(owner, this.targets[i]))
					{
						this.content.Active = true;
						break;
					}
				}
			}
			return tmp != this.content.Active;
		}

		public override void Selected(Combatant owner)
		{
			owner.BattleMenu.TargetHighlight.AcceptAction(this.shortcut);
			owner.BattleMenu.TargetHighlight.AcceptHighlights();
			owner.BattleMenu.TargetHighlight.SelectTargets(this.targets, this.shortcut);
		}

		public override bool Accepted(Combatant owner)
		{
			BaseAction action = null;
			if(this.shortcut is AbilityShortcut)
			{
				action = new AbilityAction(owner, this.shortcut as AbilityShortcut);
			}
			else if(this.shortcut is ItemShortcut)
			{
				action = new ItemAction(owner, this.shortcut as ItemShortcut);
			}
			action.SetTargets(this.targets);
			owner.BattleMenu.AddAction(action);
			return true;
		}

		public override bool Contains(Combatant owner, Combatant target)
		{
			return this.targets.Contains(target) &&
				this.shortcut.CanTarget(owner, target);
		}

		public override bool ContainsAny(Combatant owner, List<Combatant> list)
		{
			if(list != null)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(this.targets.Contains(list[i]) &&
						this.shortcut.CanTarget(owner, list[i]))
					{
						return true;
					}
				}
			}
			return false;
		}
	}
}
