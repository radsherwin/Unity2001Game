
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class FormulaStatusOrigin : BaseData
	{
		[ORKEditorHelp("Status Origin", "Select combatant that will be the origin of the status:" +
			"- User: The user of the formula (i.e. the combatant who uses an ability, item, hit chances, etc.).\n" +
			"- Target: The target of the formula (i.e. the combatant who is targeted by the ability, item, hit chance, etc.).\n" +
			"- Player: The player combatant. If there is no player, the user will be used.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75, separator=true)]
		public StatusOrigin origin = StatusOrigin.User;

		[ORKEditorHelp("Group Leader", "The group leader of the selected combatant will be used.\n" +
			"If disabled, the combatant will be used.", "")]
		[ORKEditorLayout("origin", StatusOrigin.Player, elseCheckGroup=true, endCheckGroup=true)]
		public bool groupLeader = false;

		public FormulaStatusOrigin()
		{

		}

		public Combatant GetCombatant(FormulaCall call)
		{
			if(StatusOrigin.User == this.origin)
			{
				return this.groupLeader ? call.user.Group.Leader : call.user;
			}
			else if(StatusOrigin.Target == this.origin)
			{
				return this.groupLeader ? call.target.Group.Leader : call.target;
			}
			else if(StatusOrigin.Player == this.origin)
			{
				if(ORK.Game.ActiveGroup.Leader != null)
				{
					return ORK.Game.ActiveGroup.Leader;
				}
			}
			return call.user;
		}

		public string GetInfoText()
		{
			return this.origin.ToString() +
				(this.groupLeader ? " (Leader)" : "");
		}
	}
}
