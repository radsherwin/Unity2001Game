
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.UI
{
	public class AbilityBMItem : BMItem
	{
		private AbilityShortcut ability;

		public AbilityBMItem(AbilityShortcut ability, ChoiceContent content)
		{
			this.ability = ability;
			this.content = content;
		}

		public override void CreateDrag(Combatant owner)
		{
			if(this.content.data == null)
			{
				// drag+drop
				this.content.isDragable = ORK.BattleSettings.bmDrag;
				this.content.clickCount = ORK.BattleSettings.bmClick ? ORK.BattleSettings.bmClickCount : 0;
				this.content.isTooltip = ORK.BattleSettings.bmTooltip;
				if(this.content.isDragable || this.content.clickCount > 0 || this.content.isTooltip)
				{
					this.content.data = this.ability.GetDrag(owner.BattleMenu, owner);
				}
			}

			// portrait
			if(this.content.portrait == null &&
				owner.BattleMenu.Settings.showAbilityPortraits &&
				this.ability.HasPortrait())
			{
				this.content.portrait = this.ability.GetPortrait();
			}
		}

		public override bool ActiveCheck(Combatant owner)
		{
			bool tmp = this.content.Active;
			this.content.Active = this.ability.CanUse(owner,
				AbilityActionType.CounterAttack != this.ability.Type, true) &&
				(this.ability.NoneTarget() || this.ability.HasPossibleTargets(owner, null));
			return tmp != this.content.Active;
		}

		public override void Selected(Combatant owner)
		{
			owner.BattleMenu.TargetHighlight.SelectAction(this.ability);
		}

		public override bool Accepted(Combatant owner)
		{
			if(owner.BattleMenu != null)
			{
				if(this.ability.TargetSelf())
				{
					BaseAction action = new AbilityAction(owner, this.ability);
					action.SetTarget(owner);
					owner.BattleMenu.AddAction(action);
					return true;
				}
				else if(this.ability.NoneTarget())
				{
					if(ORK.Battle.Grid != null &&
						this.ability.GetActiveLevel().targetSettings.noneSelectGridCell)
					{
						owner.BattleMenu.StartGridTargetCellSelection(this.ability);
						owner.BattleMenu.CloseSilent();
					}
					else
					{
						BaseAction action = new AbilityAction(owner, this.ability);
						if(action.targetRaycast.NeedInteraction())
						{
							owner.BattleMenu.RayAction = action;
							owner.BattleMenu.CloseSilent();
						}
						else
						{
							if(action.targetRaycast.active)
							{
								action.targetRaycast.GetAutoPoint(owner.GameObject, VectorHelper.GetScreenCenter(), action);
							}
							owner.BattleMenu.AddAction(action);
						}
					}
					return true;
				}
				else
				{
					// use on group target
					if(owner.BattleMenu.Settings.useGroupTarget)
					{
						Combatant target = owner.Group.SelectedTargets.GetAbilityTarget(owner, this.ability);
						if(target != null)
						{
							BaseAction action = new AbilityAction(owner, this.ability);
							action.SetTarget(target);
							owner.BattleMenu.AddAction(action);
							return true;
						}
					}
					// use on individual target
					if(owner.BattleMenu.Settings.useIndividualTarget)
					{
						Combatant target = owner.SelectedTargets.GetAbilityTarget(owner, this.ability);
						if(target != null)
						{
							BaseAction action = new AbilityAction(owner, this.ability);
							action.SetTarget(target);
							owner.BattleMenu.AddAction(action);
							return true;
						}
					}

					// display target menu
					owner.BattleMenu.TargetHighlight.AcceptAction(this.ability);
					ActiveAbility activeLevel = this.ability.GetActiveLevel();
					List<BMItem> list = new List<BMItem>();

					int selection = -1;
					if(this.ability.SingleTarget())
					{
						for(int i = 0; i < owner.BattleMenu.TargetHighlight.AvailableTargets.Count; i++)
						{
							List<Combatant> tmp = new List<Combatant>();
							tmp.Add(owner.BattleMenu.TargetHighlight.AvailableTargets[i]);
							list.Add(new TargetBMItem(
								owner.BattleMenu.GetCombatantChoice(owner.BattleMenu.TargetHighlight.AvailableTargets[i]),
								this.ability, tmp));

							if(selection < 0 && activeLevel.targetSettings.useAutoTarget &&
								activeLevel.targetSettings.autoTarget.Check(owner.BattleMenu.TargetHighlight.AvailableTargets[i]))
							{
								selection = i;
							}
						}
					}
					else if(this.ability.GroupTarget())
					{
						list.Add(new TargetBMItem(
							ORK.BattleTexts.GetAllCombatantsContent(
								activeLevel.targetSettings.targetType,
								owner.BattleMenu.Settings.contentLayout),
							this.ability, owner.BattleMenu.TargetHighlight.AvailableTargets));
					}

					if(list.Count > 0)
					{
						if(ORK.BattleSettings.useTargetMenu)
						{
							owner.BattleMenu.Settings.AddBack(list);
						}

						owner.BattleMenu.TargetHighlight.AcceptHighlights();
						owner.BattleMenu.Show(list, selection < 0 ? 0 : selection, BattleMenuMode.Target);
						return true;
					}
				}
			}
			return false;
		}

		public override bool ChangeUseLevel(int change, Combatant owner)
		{
			if(this.ability.ChangeUseLevel(change, ORK.GameControls.loopAbilityLevels))
			{
				if(owner.BattleMenu != null)
				{
					if(owner.BattleMenu.Box != null)
					{
						owner.BattleMenu.Box.Audio.PlayAbilityLevel();
					}
					this.content = owner.BattleMenu.Settings.contentLayout.GetChoiceContent(this.ability, owner);
				}
				return true;
			}
			return false;
		}
	}
}
