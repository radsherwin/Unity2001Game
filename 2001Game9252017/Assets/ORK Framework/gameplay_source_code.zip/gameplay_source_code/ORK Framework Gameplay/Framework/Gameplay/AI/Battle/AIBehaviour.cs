﻿
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class AIBehaviour : BaseLanguageData, IContent
	{
		// base settings
		[ORKEditorHelp("AI Type", "Select the AI type of this AI behaviour.", "")]
		[ORKEditorInfo("Base Settings", "Define the base settings of this AI behaviour.", "",
			ORKDataType.AIType)]
		public int typeID = 0;

		[ORKEditorHelp("Use Quantity", "This AI behaviour uses quantity mechanics.\n" +
			"I.e. it can be collected multiple times and each unit " +
			"will be unavailable while being equipped on an AI behaviour slot.\n" +
			"If disabled, the AI behaviour can only be collected once and " +
			"equipping it on a slot doesn't make it unavailable for other combatants/slots.", "")]
		public bool useQuantity = false;

		// prefab
		[ORKEditorHelp("Item Prefab", "The prefab spawned by the item collector when collecting this AI behaviour.", "")]
		[ORKEditorInfo(separator=true)]
		public GameObject prefab;

		[ORKEditorHelp("Spawn Offset", "Offset added to the game object position when spawning.", "")]
		public Vector3 spawnOffset = Vector3.zero;

		// sympathy
		[ORKEditorHelp("Sympathy Change", "Additional to the faction's take item sympathy change, this value will be added to the change.\n" +
			"Use negative values to decrease sympathy, positive values to increase.", "")]
		[ORKEditorInfo(separator=true)]
		public float sympathyChange = 0;

		// chance
		[ORKEditorInfo("Chance (%)", "The chance this AI behaviour will be used.", "",
			endFoldout=true, endFolds=2)]
		public FloatValue chanceValue = new FloatValue(100);


		// sale settings
		[ORKEditorInfo("Price Settings", "Set the prices for buying and selling this AI behaviour.", "",
			endFoldout=true)]
		public PriceSettings price = new PriceSettings();


		// move AI
		[ORKEditorHelp("Change On Use", "Only change the move AI when an action of this AI behaviour is used.", "")]
		[ORKEditorInfo("Move AI Settings", "Equipping this AI behaviour can influence the move AI of the combatant.", "")]
		public bool moveAIChangeOnUse = false;

		[ORKEditorInfo(separator=true, endFoldout=true)]
		public MoveAIChange moveAIChange = new MoveAIChange();


		// equip requirements
		[ORKEditorHelp("Single Equip", "A combatant can only equip one AI behaviour of this kind.\n" +
			"If disabled, a combatant can equip this AI behaviour multiple times on different slots.", "")]
		[ORKEditorInfo("Equip Requirements", "Equipping this AI behaviour on an AI behaviour slot " +
			"can depend on status requirements and game variable conditions.\n" +
			"The combatant equipping the AI behaviour is used for status checks and object game variables.", "")]
		public bool singleEquip = true;

		[ORKEditorHelp("Use Requirements", "Use status requirements and game variable conditions " +
			"to determine if this AI behaviour can be equipped.", "")]
		public bool useEquipRequirements = false;

		[ORKEditorHelp("Auto Unequip", "Automatically unequip this AI behaviour when the equip requirements are no longer valid.", "")]
		[ORKEditorLayout("useEquipRequirements", true)]
		public bool autoUnequip = false;

		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public SimpleCombatantRequirement equipRequirement;


		// user requirements
		[ORKEditorHelp("Use Requirements", "Use status requirements and game variable conditions " +
			"to determine if this AI behaviour can be used.", "")]
		[ORKEditorInfo("User Requirements", "Using this AI behaviour can depend on status requirements and " +
			"game variable conditions.\n" +
			"The combatant using the AI behaviour is used for status checks and object game variables.", "")]
		public bool useUserRequirements = false;

		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("useUserRequirements", true, endCheckGroup=true, autoInit=true)]
		public SimpleCombatantRequirement userRequirement;


		// notifications
		[ORKEditorHelp("Own Notifications", "This AI behaviour overrides the default item notifications.", "")]
		[ORKEditorInfo("Notification Settings", "AI behaviours can override the default item notifications.", "")]
		public bool ownNotifications = false;

		[ORKEditorInfo("AI Behaviour Added", "This notification will be displayed " +
			"when this AI behaviour is added to the player.", "", endFoldout=true)]
		[ORKEditorLayout("ownNotifications", true, autoInit=true)]
		public AINotification addedNotification;

		[ORKEditorInfo("AI Behaviour Removed", "This notification will be displayed " +
			"when this AI behaviour is removed from the player.", "",
			endFoldout=true, endFolds=2)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public AINotification removedNotification;


		// console texts
		[ORKEditorHelp("Own Add Text", "This AI behaviour overrides the default console add text.", "")]
		[ORKEditorInfo("Console Texts", "An AI behaviour can override the default console texts.", "")]
		public bool ownConsoleAdd = false;

		[ORKEditorInfo("Add Text", "The text displayed for adding this AI behaviour to the player.", "", endFoldout=true)]
		[ORKEditorLayout("ownConsoleAdd", true, endCheckGroup=true, autoInit=true)]
		public ConsoleTextAI consoleAdd;

		[ORKEditorHelp("Own Remove Text", "This AI behaviour overrides the default console remove text.", "")]
		[ORKEditorInfo(separator=true)]
		public bool ownConsoleRemove = false;

		[ORKEditorInfo("Remove Text", "The text displayed for removing this AI behaviour from the player.", "", endFoldout=true, endFolds=2)]
		[ORKEditorLayout("ownConsoleRemove", true, endCheckGroup=true, autoInit=true)]
		public ConsoleTextAI consoleRemove;


		// portrait
		[ORKEditorHelp("Use Portrait", "This AI behavoiur has a portrait that can be displayed in menus.", "")]
		[ORKEditorInfo("Portrait Settings", "The AI behaviour can display a portrait in menus when it's selected.", "")]
		public bool usePortrait = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("usePortrait", true, endCheckGroup=true, autoInit=true)]
		public Portrait portrait;


		// battle AI
		[ORKEditorArray(false, "Add Battle AI", "Adds a battle AI to this AI behaviour.\n" +
			"The battle AIs will be used in the order they're added (i.e. starting with 'Battle AI 0').", "",
			"Remove", "Removes this battle AI.", "", isMove=true, isCopy=true,
			removeType=ORKDataType.BattleAI, removeCheckField="battleAI",
			foldout=true, foldoutText=new string[] {
				"Battle AI", "Define the battle AI that will be used and requirements that must be met.", ""
			})]
		public BattleAISelection[] battleAI = new BattleAISelection[0];

		public AIBehaviour()
		{

		}

		public AIBehaviour(string name) : base(name)
		{

		}


		/*
		============================================================================
		Prefab functions
		============================================================================
		*/
		public GameObject GetPrefabInstance()
		{
			if(this.prefab != null)
			{
				return (GameObject)GameObject.Instantiate(this.prefab);
			}
			return null;
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public bool CanEquip(Combatant user)
		{
			return (!this.singleEquip || !user.AI.IsAIBehaviourEquipped(this.ID)) &&
				(!this.useEquipRequirements || this.equipRequirement.Check(user));
		}

		public bool CheckRequirements(Combatant user)
		{
			return ORK.GameSettings.CheckRandom(this.chanceValue.GetValue(user, user)) &&
				(!this.useUserRequirements || this.userRequirement.Check(user));
		}

		public BaseAction GetAction(Combatant user, List<Combatant> allies, List<Combatant> enemies)
		{
			BaseAction action = null;
			if(this.CheckRequirements(user))
			{
				for(int i = 0; i < this.battleAI.Length; i++)
				{
					action = this.battleAI[i].GetAction(user, allies, enemies);
					if(action != null)
					{
						break;
					}
				}
			}
			// action move AI changes
			if(action != null &&
				this.moveAIChangeOnUse)
			{
				this.moveAIChange.Change(user);
			}
			return action;
		}

		public bool ChangeMoveAI(Combatant user)
		{
			if(!this.moveAIChangeOnUse &&
				this.CheckRequirements(user))
			{
				if(this.moveAIChange.Change(user))
				{
					return true;
				}
			}
			return false;
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public int ID
		{
			get { return this.realID; }
		}

		public int TypeID
		{
			get { return this.typeID; }
		}

		public string GetName()
		{
			return this.languageInfo[ORK.Game.Language].GetName();
		}

		public string GetDescription()
		{
			return this.languageInfo[ORK.Game.Language].GetDescription();
		}

		public string GetIconTextCode()
		{
			return TextCode.AIBehaviourIcon + this.realID + "#";
		}

		public Texture GetIcon()
		{
			return this.languageInfo[ORK.Game.Language].GetIcon();
		}

		public GUIContent GetContent()
		{
			return this.languageInfo[ORK.Game.Language].GetContent();
		}

		public IContentSimple GetTypeContent()
		{
			return ORK.AITypes.Get(this.typeID);
		}

		public string GetInfo(Combatant c)
		{
			return "";
		}
	}
}
