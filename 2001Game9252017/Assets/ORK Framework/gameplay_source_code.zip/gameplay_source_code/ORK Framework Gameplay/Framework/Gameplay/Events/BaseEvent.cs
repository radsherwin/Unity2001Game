
using ORKFramework;
using ORKFramework.Events.Steps;
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Events
{
	public abstract class BaseEvent : BaseNode, IEventStarter
	{
		[ORKEditorInfo(hide=true)]
		public int startIndex = -1;

		[ORKEditorInfo(hide=true)]
		public BaseEventStep[] step = new BaseEventStep[0];


		// event execution
		protected IEventStarter starter;

		protected bool executing = false;

		protected int currentStep = 0;

		protected int currentStepFail = 0;

		protected long stepCounter = 0;

		protected bool stopFlag = false;

		protected List<int> stopList;


		// data
		protected VariableHandler variableHandler;

		protected SelectedDataHandler selectedData;


		// button press
		protected bool checkButtons = false;

		protected int[] buttonID;

		protected int[] buttonNext;


		// wait for step
		protected IStepUpdate waitStep;


		// time handling
		protected bool timeRunning = false;

		protected bool stepFinished = false;

		protected float time = 0.0f;

		protected bool noTimeDecrease = false;

		protected List<ContinueStep> continueSteps = new List<ContinueStep>();

		protected bool endAfterContinue = false;


		// camera
		protected Transform camera;

		protected Transform initialCamParent;

		protected Vector3 initialCamPosition;

		protected Quaternion initialCamRotation;

		protected float initialFieldOfView;


		// call other event
		protected BaseEvent calledEvent;

		protected bool gameOver = false;

		protected bool exitGame = false;


		// blocks
		protected int playerBlocks = 0;

		protected int cameraBlocks = 0;


		// found objects
		protected Dictionary<string, List<GameObject>> foundObjects = new Dictionary<string, List<GameObject>>();


		// open GUI boxes
		protected List<GUIBox> guiBox = new List<GUIBox>();


		/*
		============================================================================
		Local event variables functions
		============================================================================
		*/
		public VariableHandler Variables
		{
			get
			{
				if(this.variableHandler == null)
				{
					this.variableHandler = new VariableHandler(false);
				}
				return this.variableHandler;
			}
			set { this.variableHandler = value; }
		}


		/*
		============================================================================
		Data selection functions
		============================================================================
		*/
		public SelectedDataHandler SelectedData
		{
			get
			{
				if(this.selectedData == null)
				{
					this.selectedData = new SelectedDataHandler();
				}
				return this.selectedData;
			}
			set { this.selectedData = value; }
		}


		/*
		============================================================================
		Block functions
		============================================================================
		*/
		public void DoPlayerBlock(int add)
		{
			this.playerBlocks += add;
			ORK.Control.SetBlockPlayer(add, true);
		}

		public void DoCameraBlock(int add)
		{
			this.cameraBlocks += add;
			ORK.Control.SetBlockCamera(add, true);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeName()
		{
			return "Event Settings";
		}

		public override string GetNodeDetails()
		{
			return "";
		}

		public override string GetNextName(int index)
		{
			return "Start";
		}

		public override bool IsRemovable()
		{
			return false;
		}


		/*
		============================================================================
		Next functions
		============================================================================
		*/
		public override int GetNextCount()
		{
			return 1;
		}

		public override int GetNext(int index)
		{
			return this.startIndex;
		}

		public override void SetNext(int index, int next)
		{
			this.startIndex = next;
		}


		/*
		============================================================================
		Get/Set functions
		============================================================================
		*/
		public bool Executing
		{
			get { return this.executing; }
		}

		public bool Stopping
		{
			get { return this.stopFlag; }
		}

		public GameObject GameObject
		{
			get
			{
				if(ComponentHelper.IsAlive(this.starter))
				{
					return this.starter.GameObject;
				}
				else
				{
					return null;
				}
			}
		}

		public IEventStarter Starter
		{
			get { return this.starter; }
		}


		/*
		============================================================================
		Start/End functions
		============================================================================
		*/
		public abstract void StartEvent(IEventStarter s, object startingObject);

		protected void StartEvent()
		{
			this.executing = true;
			this.currentStep = this.startIndex;
			this.gameOver = false;
			this.exitGame = false;
			this.playerBlocks = 0;
			this.cameraBlocks = 0;

			if(this.GetCamera() != null)
			{
				this.initialCamParent = this.camera.parent;
				this.initialCamPosition = this.camera.position;
				this.initialCamRotation = this.camera.rotation;
				Camera cam = this.camera.GetComponent<Camera>();
				if(cam != null)
				{
					this.initialFieldOfView = cam.fieldOfView;
				}
			}

			this.ExecuteNextStep();
		}

		protected abstract void EndEvent();

		public virtual void StopEvent()
		{
			this.stopFlag = true;
		}


		/*
		============================================================================
		Step functions
		============================================================================
		*/
		public void StepFinished(int next)
		{
			if(this.stepCounter > ORK.GameControls.interaction.maxSteps)
			{
				this.stepFinished = true;
				this.StartTime(0, next);
			}
			else
			{
				this.stepCounter++;
				this.currentStep = next;
				this.ExecuteNextStep();
			}
		}

		public abstract void ExecuteNextStep();

		public virtual void ExecuteNextStepStop()
		{
			if(this.stopList == null)
			{
				this.stopList = new List<int>();
			}
			int next = this.step[this.currentStep].GetNext(0);
			if(this.stopList.Contains(next))
			{
				this.currentStep = -1;
				this.EndEvent();
			}
			else
			{
				this.stopList.Add(next);
				this.StepFinished(next);
			}
		}

		public void WaitForButton(int[] id, float t, int[] next, int nextFail)
		{
			this.checkButtons = true;
			this.buttonID = id;
			this.buttonNext = next;
			if(t == -1)
			{
				this.noTimeDecrease = true;
				this.StartTime(1, nextFail);
			}
			else
			{
				this.StartTime(t, nextFail);
			}
		}

		public void WaitForStep(IStepUpdate waitStep, float t, int nextFail)
		{
			this.waitStep = waitStep;
			if(t == -1)
			{
				this.noTimeDecrease = true;
				this.StartTime(1, nextFail);
			}
			else
			{
				this.StartTime(t, nextFail);
			}
		}

		public virtual void SetNextStep(int next)
		{
			this.currentStep = next;
		}


		/*
		============================================================================
		Time functions
		============================================================================
		*/
		public void StartTime(float t, int next)
		{
			this.stepCounter = 0;
			this.time = t;
			this.currentStep = next;
			this.timeRunning = true;
		}

		public void StartContinue(float t, BaseEventStep s)
		{
			this.continueSteps.Add(new ContinueStep(t, s));
		}

		public void Tick(float delta)
		{
			if(this.calledEvent != null)
			{
				this.calledEvent.Tick(delta);
			}
			else if(this.timeRunning)
			{
				if(this.stopFlag)
				{
					this.time = -1;
				}

				if(!this.noTimeDecrease)
				{
					this.time -= delta;
				}

				if(this.checkButtons)
				{
					if(this.buttonID.Length == 0 && Input.anyKeyDown)
					{
						this.currentStep = this.buttonNext[0];
						this.time = 0;
					}
					else if(this.CheckButtons(ref this.currentStep))
					{
						this.time = 0;
					}
				}
				else if(this.waitStep != null &&
					this.waitStep.Tick(delta, this, ref this.currentStep))
				{
					this.time = 0;
				}

				if(this.time <= 0)
				{
					this.timeRunning = false;

					// clean up
					this.buttonID = null;
					this.buttonNext = null;
					this.noTimeDecrease = false;
					this.checkButtons = false;
					this.waitStep = null;

					if(this.stepFinished)
					{
						this.ExecuteNextStep();
					}
					else
					{
						this.StepFinished(this.currentStep);
					}
				}
			}
			if(this.continueSteps.Count > 0)
			{
				for(int i = 0; i < this.continueSteps.Count; i++)
				{
					if(this.continueSteps[i].DoContinue(delta, this))
					{
						this.continueSteps.RemoveAt(i--);
					}
				}
				if(this.endAfterContinue && this.continueSteps.Count == 0)
				{
					this.endAfterContinue = false;
					this.EndEvent();
				}
			}
		}

		protected bool CheckButtons(ref int next)
		{
			for(int i = 0; i < this.buttonID.Length; i++)
			{
				if(ORK.InputKeys.Get(this.buttonID[i]).GetButton())
				{
					next = this.buttonNext[i];
					return true;
				}
			}
			return false;
		}


		/*
		============================================================================
		Camera functions
		============================================================================
		*/
		public Transform InitialCamParent
		{
			get { return this.initialCamParent; }
		}

		public Vector3 InitialCamPosition
		{
			get { return this.initialCamPosition; }
		}

		public Quaternion InitialCamRotation
		{
			get { return this.initialCamRotation; }
		}

		public float InitialFieldOfView
		{
			get { return this.initialFieldOfView; }
		}

		public virtual Transform GetCamera()
		{
			if(this.camera == null)
			{
				Camera c = Camera.main;
				if(c != null)
				{
					this.camera = c.transform;
				}
			}
			return this.camera;
		}

		public void ResetCameraPosition()
		{
			if(this.camera)
			{
				this.camera.parent = this.initialCamParent;
				this.camera.SetPositionAndRotation(
					this.initialCamPosition, this.initialCamRotation);
				Camera cam = this.camera.GetComponent<Camera>();
				if(cam != null)
				{
					cam.fieldOfView = this.initialFieldOfView;
				}
			}
		}

		public virtual bool PerformCamera
		{
			get { return true; }
		}


		/*
		============================================================================
		Actor functions
		============================================================================
		*/
		public abstract string GetActorName(int index);

		public abstract Portrait GetActorPortrait(int index, int typeID);

		public abstract List<GameObject> GetActorObject(int index);

		public abstract List<Combatant> GetActorCombatant(int index);


		/*
		============================================================================
		Waypoint functions
		============================================================================
		*/
		public abstract List<GameObject> GetWaypoint(int index);


		/*
		============================================================================
		Prefab functions
		============================================================================
		*/
		public abstract GameObject SpawnPrefab(int index, Vector3 position, Vector3 rotation);

		public abstract void DestroyPrefab(int index, int spawnID, float time);

		public abstract List<GameObject> GetSpawnedPrefab(int index, int spawnID);


		/*
		============================================================================
		Audio functions
		============================================================================
		*/
		public abstract AudioClip GetAudioClip(int index);


		/*
		============================================================================
		Found objects functions
		============================================================================
		*/
		public Dictionary<string, List<GameObject>> FoundObjects
		{
			get { return this.foundObjects; }
			set { this.foundObjects = value; }
		}

		public virtual void ChangeFoundObjects(string key, List<GameObject> list, ListChangeType changeType)
		{
			if(ListChangeType.Clear == changeType)
			{
				if(this.foundObjects.ContainsKey(key))
				{
					this.foundObjects[key].Clear();
				}
			}
			else if(ListChangeType.Set == changeType)
			{
				if(this.foundObjects.ContainsKey(key))
				{
					this.foundObjects[key].Clear();
				}
				else
				{
					this.foundObjects.Add(key, new List<GameObject>());
				}
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						this.foundObjects[key].Add(list[i]);
					}
				}
			}
			else
			{
				if(!this.foundObjects.ContainsKey(key))
				{
					this.foundObjects.Add(key, new List<GameObject>());
				}
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						if(ListChangeType.Add == changeType)
						{
							this.foundObjects[key].Add(list[i]);
						}
						else if(ListChangeType.Remove == changeType)
						{
							this.foundObjects[key].Remove(list[i]);
						}
					}
				}
			}
		}

		public virtual List<GameObject> GetFoundObjects(string key)
		{
			if(this.foundObjects.ContainsKey(key))
			{
				return new List<GameObject>(this.foundObjects[key]);
			}
			return new List<UnityEngine.GameObject>();
		}

		public int FoundObjectsCount(string key)
		{
			if(this.foundObjects.ContainsKey(key))
			{
				return this.foundObjects[key].Count;
			}
			return 0;
		}


		/*
		============================================================================
		Call event functions
		============================================================================
		*/
		public void CallMoveEvent(ORKMoveEvent eventAsset, List<GameObject> movingObject, int next,
			bool shareVariables, bool shareSelectedData, bool shareFoundObjects)
		{
			this.currentStep = next;
			if(eventAsset != null)
			{
				this.calledEvent = new MoveEvent(movingObject);
				this.calledEvent.SetData(eventAsset.GetData().ToDataObject());
				if(shareVariables)
				{
					this.calledEvent.Variables = this.Variables;
				}
				if(shareSelectedData)
				{
					this.calledEvent.SelectedData = this.SelectedData;
				}
				if(shareFoundObjects)
				{
					this.calledEvent.FoundObjects = this.FoundObjects;
				}
				this.calledEvent.foundObjects = this.foundObjects;
				this.calledEvent.StartEvent(this, null);
			}
			else
			{
				this.StepFinished(this.currentStep);
			}
		}

		public void CallGlobalEvent(ORKGameEvent eventAsset, int next,
			bool shareVariables, bool shareSelectedData, bool shareFoundObjects)
		{
			this.currentStep = next;
			if(eventAsset != null)
			{
				this.calledEvent = new GameEvent();
				this.calledEvent.SetData(eventAsset.GetData().ToDataObject());
				if(shareVariables)
				{
					this.calledEvent.Variables = this.Variables;
				}
				if(shareSelectedData)
				{
					this.calledEvent.SelectedData = this.SelectedData;
				}
				if(shareFoundObjects)
				{
					this.calledEvent.FoundObjects = this.FoundObjects;
				}
				this.calledEvent.StartEvent(this, this.GameObject);
			}
			else
			{
				this.StepFinished(this.currentStep);
			}
		}

		public void CallBattleEvent(ORKBattleEvent eventAsset, int next,
			bool shareVariables, bool shareSelectedData, bool shareFoundObjects)
		{
			this.currentStep = next;
			if(eventAsset != null)
			{
				this.calledEvent = new BattleEvent();
				this.calledEvent.SetData(eventAsset.GetData().ToDataObject());
				if(shareVariables)
				{
					this.calledEvent.Variables = this.Variables;
				}
				if(shareSelectedData)
				{
					this.calledEvent.SelectedData = this.SelectedData;
				}
				if(shareFoundObjects)
				{
					this.calledEvent.FoundObjects = this.FoundObjects;
				}
				this.calledEvent.StartEvent(this, this.GameObject);
			}
			else
			{
				this.StepFinished(this.currentStep);
			}
		}

		public void EventEnded()
		{
			this.calledEvent = null;
			this.StepFinished(this.currentStep);
		}

		public void DontDestroy()
		{
			if(ComponentHelper.IsAlive(this.starter))
			{
				this.starter.DontDestroy();
			}
		}

		public void OnSceneLoaded()
		{
			if(ComponentHelper.IsAlive(this.starter))
			{
				this.starter.OnSceneLoaded();
			}
		}

		public void SetGameOver()
		{
			this.gameOver = true;
		}

		public void SetExitGame()
		{
			this.exitGame = true;
		}


		/*
		============================================================================
		GUI box functions
		============================================================================
		*/
		public virtual void AddGUIBox(GUIBox box)
		{
			if(!this.guiBox.Contains(box))
			{
				this.guiBox.Add(box);
			}
		}

		public virtual void RemoveGUIBox(GUIBox box)
		{
			if(this.guiBox.Contains(box))
			{
				this.guiBox.Remove(box);
			}
		}

		public virtual void CloseAllGUIBoxes()
		{
			for(int i = 0; i < this.guiBox.Count; i++)
			{
				if(this.guiBox[i] != null &&
					!this.guiBox[i].IsClosing &&
					!this.guiBox[i].IsClosed)
				{
					if(this.guiBox[i].Content != null)
					{
						this.guiBox[i].Content.controlInterface = null;
					}
					this.guiBox[i].InitOut();
				}
			}
			this.guiBox.Clear();
		}
	}
}
