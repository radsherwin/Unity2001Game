﻿
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class AIRuleMoveAI : BaseData
	{
		[ORKEditorHelp("Change On Use", "Only change the move AI when an action of this AI ruleset is used.", "")]
		public bool moveAIChangeOnUse = false;

		[ORKEditorInfo(separator=true)]
		public MoveAIChange moveAIChange = new MoveAIChange();

		public AIRuleMoveAI()
		{

		}
	}
}
