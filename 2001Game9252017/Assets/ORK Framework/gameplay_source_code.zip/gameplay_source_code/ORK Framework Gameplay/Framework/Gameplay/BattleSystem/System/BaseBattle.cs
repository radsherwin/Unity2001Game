
using UnityEngine;
using System.Collections.Generic;
using System.Collections;

namespace ORKFramework
{
	public abstract class BaseBattle : BaseData
	{
		// block player control settings
		[ORKEditorHelp("Block Player Control", "Select when the player control will be blocked:\n" +
			"- None: The control wont be blocked.\n" +
			"- Battle: During the whole battle (i.e. from before the start event till after the end event).\n" +
			"- All Actions: While performing an action (all combatants).\n" +
			"- Player Actions: While performing an action of the player combatant.", "")]
		[ORKEditorInfo("Control Block Settings", "Define if and when the player and " +
			"camera control will be blocked during battle.", "",
			labelText="Player Control Block")]
		public BattleControlBlock playerControl = BattleControlBlock.None;

		[ORKEditorHelp("Block in Battle Menu", "Block the player control while displaying a battle menu.", "")]
		public bool playerBattleMenu = false;

		// block camera control settings
		[ORKEditorHelp("Block Camera Control", "Select when the camera control will be blocked:\n" +
			"- None: The control wont be blocked.\n" +
			"- Battle: During the whole battle (i.e. from before the start event till after the end event).\n" +
			"- All Actions: While performing an action (all combatants).\n" +
			"- Player Actions: While performing an action of the player combatant.", "")]
		[ORKEditorInfo(separator=true, labelText="Camera Control Block")]
		public BattleControlBlock cameraControl = BattleControlBlock.None;

		[ORKEditorHelp("Block in Battle Menu", "Block the camera control while displaying a battle menu.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool cameraBattleMenu = false;


		// move AI settings
		[ORKEditorHelp("Allow Move AI", "Combatants will use their move AI while fighting.\n" +
			"If disabled, move AI's wont work while a battle is running.", "")]
		[ORKEditorInfo("Move AI Settings", "Set if combatants can use their move AI while in a battle ofthis system type.", "")]
		public bool allowMoveAI = false;

		[ORKEditorHelp("Block In Battle", "The move AI of combatants that are participating in battle will be blocked.\n" +
			"If disabled, the move AI of all combatants can be used.", "")]
		[ORKEditorLayout("allowMoveAI", true)]
		public bool blockInBattleMoveAI = false;

		[ORKEditorHelp("Use Move AI Range", "The move AI range is used to determine if a combatant can use the move AI.\n" +
			"If disabled, the distance to the player doesn't prevent using the move AI.", "")]
		[ORKEditorInfo("Move AI Range", "The distance (in world units) a combatant can " +
			"have to the player to use the move AI.\n" +
			"This will be used while not in battle - " +
			"each battle system type can define it's own move AI settings.", "")]
		public bool useMoveAIRange = true;

		[ORKEditorLayout("useMoveAIRange", true, endCheckGroup=true, endGroups=2)]
		[ORKEditorInfo(endFoldout=true, endFolds=2)]
		public Range moveAIRange = new Range(50);


		// start events
		[ORKEditorHelp("Start Event", "Select the ORK battle start event asset used to start battles.\n" +
			"If none is selected, the battle will start right away and place all combatants at their battle spots.\n" +
			"This setting can be overridden by the battle setup in scenes.", "")]
		[ORKEditorInfo("Default Start/End Events", "Define the default battle start and battle end events.\n" +
			"The default events can be overridden in Battle components.", "")]
		public ORKBattleStartEvent startEvent;

		// end events
		[ORKEditorHelp("Victory Event", "Select the ORK battle end event asset used to end battles when the player group won.\n" +
			"If none is selected, the battle will end right away and collect all battle gains (without displaying them).\n" +
			"This setting can be overridden by the battle setup in scenes.", "")]
		public ORKBattleEndEvent victoryEvent;

		[ORKEditorHelp("Escape Event", "Select the ORK battle end event asset used to end battles when the player group escaped.\n" +
			"If none is selected, the battle will end right away and collect all battle gains (without displaying them).\n" +
			"This setting can be overridden by the battle setup in scenes.", "")]
		public ORKBattleEndEvent escapeEvent;

		[ORKEditorHelp("Defeat Event", "Select the ORK battle end event asset used to end battles when the player group has been defeated.\n" +
			"If none is selected, the battle will end right away and collect all battle gains (without displaying them), no game over will be called.\n" +
			"This setting can be overridden by the battle setup in scenes.", "")]
		public ORKBattleEndEvent defeatEvent;

		[ORKEditorHelp("Leave Arena Event", "Select the ORK battle end event asset used to end battles when the player has left the battle arena.\n" +
			"If none is selected, the battle will end right away and collect all battle gains (without displaying them).\n" +
			"This setting can be overridden by the battle setup in scenes.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public ORKBattleEndEvent leaveArenaEvent;


		// leave area settings
		[ORKEditorHelp("Use Leave Arena", "Ends the battle if the player leaves the battle arena.", "")]
		[ORKEditorInfo("Leave Arena Settings", "The battle can optionally end if the player leaves the battle arena.\n" +
			"If used, the player has to move outside a defined range of the battle arena " +
			"(i.e. the game object with the 'Battle' component attached) to trigger the 'Leave Arena' battle end.\n" +
			"Leaving the area will count as escaping in statistics." +
			"Not used in 'Real Time Battle Area' battles.", "")]
		public bool useLeaveArena = false;

		[ORKEditorLayout("useLeaveArena", true, endCheckGroup=true)]
		[ORKEditorInfo(endFoldout=true)]
		public Range leaveArenaRange = new Range(20);


		// battle gains settings
		[ORKEditorHelp("Use Add Type", "Items and equipment will be added to the " +
			"battle gains according to their inventory add type (e.g. auto stack).\n" +
			"If disabled, items/equipment will be added as is, i.e. with their defined quantity without grouping them together.", "")]
		[ORKEditorInfo("Battle Gains Collection", "Select if battle gains (loot, experience) are collected immediately " +
			"after an enemy has been defeated or at the end of the battle.\n" +
			"When collecting immediately, items and money can also be dropped into the game world.", "")]
		public bool gainsUseInventoryAddType = true;

		[ORKEditorHelp("Collect Immediately", "Battle gains are collected immediately after an enemy has been defeated.\n" +
			"If disabled, the battle gains are collected at the end of the battle (in a 'Battle End Event').", "")]
		public bool gainsCollectImmediately = false;

		[ORKEditorLayout("gainsCollectImmediately", true, autoInit=true)]
		public CollectBattleGainsSettings collectGains;

		[ORKEditorHelp("Drop Items", "Items gained from defeated enemies will be dropped into the " +
			"game world instead of added to the group inventory or item box.", "")]
		public bool gainsDropItems = false;

		[ORKEditorHelp("Drop AI", "AI behaviours and AI rulesets gained from defeated enemies will be dropped into the " +
			"game world instead of added to the group inventory or item box.", "")]
		public bool gainsDropAI = false;

		[ORKEditorHelp("Drop Recipes", "Crafting recipes gained from defeated enemies will be dropped into the " +
			"game world instead of added to the group inventory or item box.", "")]
		public bool gainsDropRecipes = false;

		[ORKEditorHelp("Drop Money", "Money gained from defeated enemies will be dropped into the " +
			"game world instead of added to the group inventory or item box.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool gainsDropMoney = false;


		// grid settings
		[ORKEditorHelp("Player Auto Grid Move", "Select if player controlled combatants can will be forced into the grid move command selection:\n" +
			"- None: No forced selection.\n" +
			"- First Action: First action of a turn.\n" +
			"- Always: Whenever the combatant's action selection comes up.", "")]
		[ORKEditorInfo("Grid Settings", "Settings for grid battles when using this battle system.", "")]
		public AutoGridMoveType playerAutoGridMove = AutoGridMoveType.None;

		[ORKEditorHelp("Turn End Orientation", "Combatants can select their orientation on the grid " +
			"at the end of their turn (i.e. after performing their actions).", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool gridTurnEndOrientation = false;


		// bonus settings
		public BattleBonuses bonuses = new BattleBonuses();


		// in-game
		protected List<Combatant> groupAuto;

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("gainsStack"))
			{
				data.Get("gainsStack", ref this.gainsUseInventoryAddType);
			}
			if(this.gainsCollectImmediately &&
				data.Contains<bool>("gainsShowText"))
			{
				this.collectGains = new CollectBattleGainsSettings();
				data.Get("gainsShowText", ref this.collectGains.display);
				data.Get("gainsAutoClose", ref this.collectGains.autoClose);
				data.Get("gainsAutoCloseTime", ref this.collectGains.closeTime);
				data.Get("gainsAutoCloseBlockAccept", ref this.collectGains.blockAccept);
			}
		}

		public virtual bool IsDynamicCombat()
		{
			return true;
		}

		public virtual bool CanCounter
		{
			get { return true; }
		}

		public virtual bool DeathImmediately
		{
			get { return false; }
		}

		public virtual bool EndImmediately
		{
			get { return false; }
		}

		public virtual bool IsMenuBackAllowed
		{
			get { return false; }
		}

		public virtual bool MenuBlockAutoAttack
		{
			get { return true; }
		}

		public virtual bool CanAutoAttack
		{
			get { return false; }
		}

		public virtual bool DefeatOnPlayerDeath
		{
			get { return false; }
		}

		public virtual bool DefendFirst
		{
			get { return false; }
		}

		public virtual Combatant SelectingCombatant
		{
			get { return null; }
		}


		/*
		============================================================================
		Action cost functions
		============================================================================
		*/
		public virtual float GetDefendActionCost(Combatant user)
		{
			return 0;
		}

		public virtual float GetEscapeActionCost(Combatant user)
		{
			return 0;
		}

		public virtual float GetNoneActionCost(Combatant user)
		{
			return 0;
		}

		public virtual float GetChangeMemberActionCost(Combatant user)
		{
			return 0;
		}

		public virtual float GetGridMoveActionCost(Combatant user)
		{
			return 0;
		}


		/*
		============================================================================
		Battle menu functions
		============================================================================
		*/
		public virtual void BattleMenuCanceled(Combatant user)
		{

		}

		public virtual bool CombatantClicked(Combatant combatant)
		{
			return false;
		}

		public virtual bool UseControlMap()
		{
			return false;
		}


		/*
		============================================================================
		Start functions
		============================================================================
		*/
		public virtual void StartBattle(bool changed)
		{
			this.groupAuto = null;
		}

		public virtual void RemoveFromOrder(Combatant combatant)
		{

		}

		public virtual void OrderChange(Combatant combatant, int change)
		{

		}

		public virtual void CombatantChanged(Combatant oldCombatant, Combatant newCombatant)
		{

		}


		/*
		============================================================================
		Tick functions
		============================================================================
		*/
		public virtual void Tick()
		{

		}

		public virtual bool DoCombatantTick()
		{
			return true;
		}


		/*
		============================================================================
		Action handling functions
		============================================================================
		*/
		public virtual void ActionAdded(BaseAction action)
		{

		}

		public virtual void ActionUnshifted(BaseAction action)
		{

		}

		protected void PerformNextAction()
		{
			ORK.StartCoroutine(this.PerformNextAction2());
		}

		protected IEnumerator PerformNextAction2()
		{
			yield return null;
			this.PerformNextAction3();
		}

		protected abstract void PerformNextAction3();

		public void PerformAction(BaseAction action)
		{
			if(action != null)
			{
				action.PerformAction();
				this.PerformingAction(action);
			}
			else
			{
				this.ActionFinished(null);
			}
		}

		public virtual void PerformingAction(BaseAction action)
		{

		}

		public virtual void ActionFinished(BaseAction action)
		{

		}


		/*
		============================================================================
		Battle end functions
		============================================================================
		*/
		public virtual void EndBattle()
		{

		}


		/*
		============================================================================
		Group auto functions
		============================================================================
		*/
		public void SetGroupAuto(Combatant combatant)
		{
			this.groupAuto = new List<Combatant>(combatant.Group.GetBattle());
			this.groupAuto.Remove(combatant);
		}

		public bool IsGroupAuto(Combatant combatant)
		{
			if(this.groupAuto != null &&
				this.groupAuto.Contains(combatant))
			{
				this.groupAuto.Remove(combatant);
				return true;
			}
			return false;
		}
	}
}

