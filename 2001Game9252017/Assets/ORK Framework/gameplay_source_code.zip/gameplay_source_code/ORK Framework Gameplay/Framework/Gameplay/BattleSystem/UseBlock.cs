
using System;

namespace ORKFramework
{
	public class UseBlock
	{
		public UseBlockType type = UseBlockType.Ability;

		public UseBlockScope scope = UseBlockScope.Single;

		public int id = -1;

		private int typeID = -1;

		public float time = 0;

		public EndAfter endType = EndAfter.None;

		public UseBlock(UseBlockType type, UseBlockScope scope, int id, float time, EndAfter endType)
		{
			this.type = type;
			this.scope = scope;
			this.id = id;
			this.time = time;
			this.endType = endType;

			if(UseBlockScope.Type == this.scope)
			{
				if(UseBlockType.Ability == this.type)
				{
					this.typeID = ORK.Abilities.Get(this.id).abilityType;
				}
				else if(UseBlockType.Item == this.type)
				{
					this.typeID = ORK.Items.Get(this.id).itemType;
				}
			}
			else if(UseBlockScope.RootType == this.scope)
			{
				if(UseBlockType.Ability == this.type)
				{
					this.typeID = ORK.AbilityTypes.Get(ORK.Abilities.Get(this.id).abilityType).RootType;
				}
				else if(UseBlockType.Item == this.type)
				{
					this.typeID = ORK.ItemTypes.Get(ORK.Items.Get(this.id).itemType).RootType;
				}
			}
		}

		public bool IsAbility
		{
			get { return UseBlockType.Ability == this.type; }
		}

		public bool IsItem
		{
			get { return UseBlockType.Item == this.type; }
		}

		public bool IsBlocked(UseBlockType checkType, int checkID)
		{
			if(this.type == checkType)
			{
				if(UseBlockScope.Single == this.scope)
				{
					return this.id == checkID;
				}
				else if(UseBlockScope.Type == this.scope)
				{
					int checkTypeID = -1;
					if(UseBlockType.Ability == this.type)
					{
						checkTypeID = ORK.Abilities.Get(checkID).abilityType;
					}
					else if(UseBlockType.Item == this.type)
					{
						checkTypeID = ORK.Items.Get(checkID).itemType;
					}
					return this.typeID == checkTypeID;
				}
				else if(UseBlockScope.RootType == this.scope)
				{
					int checkTypeID = -1;
					if(UseBlockType.Ability == this.type)
					{
						checkTypeID = ORK.AbilityTypes.Get(ORK.Abilities.Get(checkID).abilityType).RootType;
					}
					else if(UseBlockType.Item == this.type)
					{
						checkTypeID = ORK.ItemTypes.Get(ORK.Items.Get(checkID).itemType).RootType;
					}
					return this.typeID == checkTypeID;
				}
				else if(UseBlockScope.All == this.scope)
				{
					return true;
				}
			}
			return false;
		}


		/*
		============================================================================
		Time functions
		============================================================================
		*/
		public string GetReuseTimeText(int decimals)
		{
			if(EndAfter.Time == this.endType)
			{
				if(decimals == 1)
				{
					return (this.time > 0 ? this.time : 0).ToString("0.0");
				}
				else if(decimals == 2)
				{
					return (this.time > 0 ? this.time : 0).ToString("0.00");
				}
				return ((int)(this.time > 0 ? this.time : 0)).ToString();
			}
			else if(EndAfter.Turn == this.endType)
			{
				return ((int)(this.time > 0 ? this.time : 0)).ToString();
			}
			return "";
		}

		public bool ReduceTurn(Combatant combatant)
		{
			if(EndAfter.Turn == this.endType)
			{
				this.time -= 1;
				combatant.MarkHUDUpdate();
			}
			return this.time <= 0;
		}

		public bool ReduceTime(float t, Combatant combatant)
		{
			if(EndAfter.Time == this.endType)
			{
				this.time -= t;
				combatant.MarkHUDUpdate();
			}
			return this.time <= 0;
		}

		public bool IsRemoveOnBattleEnd()
		{
			return EndAfter.Turn == this.endType;
		}
	}
}
