﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class MenuControls : BaseData
	{
		[ORKEditorHelp("Accept Key", "The key used to accept selections (e.g. choice dialogues, battle menu, etc.).", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int acceptKeyID = 3;

		[ORKEditorHelp("Cancel Key", "The key used to cancel selections or return to previous selections " +
			"(e.g. return from target selection in battle menus).", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int cancelKeyID = 4;

		[ORKEditorHelp("Vertical Axis", "The key used to move the menu cursor vertically.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int verticalAxisID = 2;

		[ORKEditorHelp("Horizontal Axis", "The key used to move the menu cursor horizontally.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int horizontalAxisID = 1;

		public MenuControls()
		{

		}
	}
}
