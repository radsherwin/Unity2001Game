
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Events
{
	public class ChanceEventNextNode : BaseData
	{
		[ORKEditorInfo(labelText="Minimum Range")]
		public EventFloat minimum = new EventFloat();
		
		[ORKEditorInfo(separator=true, labelText="Maximum Range")]
		public EventFloat maximum = new EventFloat();
		
		[ORKEditorInfo(hide=true)]
		public int next = -1;
		
		public ChanceEventNextNode()
		{
			
		}
		
		public bool Contains(float chance, BaseEvent baseEvent)
		{
			return this.minimum.GetValue(baseEvent) <= chance && 
				chance <= this.maximum.GetValue(baseEvent);
		}
		
		
		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public string GetInfoText()
		{
			return this.minimum.GetInfoText() + " - " + this.maximum.GetInfoText();
		}
	}
}
