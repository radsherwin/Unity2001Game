
using UnityEngine;
using ORKFramework.AI;
using System.Collections.Generic;

namespace ORKFramework.UI
{
	public class TypeBMItem : BMItem
	{
		private int typeID = -1;

		private BattleMenuItem parent;

		private bool isSubMenu = false;

		public bool hasSubTypes = false;

		public int slotIndex = 0;

		public TypeBMItem(ChoiceContent content, int typeID, BattleMenuItem parent, bool isSubMenu)
		{
			this.content = content;
			this.typeID = typeID;
			this.parent = parent;
			this.isSubMenu = isSubMenu;
		}

		public override bool ActiveCheck(Combatant owner)
		{
			bool tmp = this.content.Active;
			if(BMItemType.Ability == this.parent.type)
			{
				this.content.Active = !owner.Status.BlockAbilities &&
					!owner.Status.IsAbilityTypeBlocked(this.typeID) &&
					owner.Abilities.HasType(this.typeID, UseableIn.Battle,
						((AbilityBattleMenuItem)this.parent.settings).addTemporaryAbilities);
			}
			else if(BMItemType.Item == this.parent.type)
			{
				this.content.Active = !owner.Status.BlockItems &&
					!owner.Status.IsItemTypeBlocked(this.typeID) &&
					owner.Inventory.HasUseableItemsByType(this.typeID, UseableIn.Battle, true);
			}
			return tmp != this.content.Active;
		}

		public override bool Accepted(Combatant owner)
		{
			if(owner.BattleMenu != null)
			{
				BattleMenuMode mode = BattleMenuMode.List;
				List<BMItem> list = new List<BMItem>();

				if(BMItemType.Ability == this.parent.type)
				{
					AbilityBattleMenuItem settings = (AbilityBattleMenuItem)this.parent.settings;

					if((!this.isSubMenu && settings.subMenu) ||
						this.hasSubTypes)
					{
						mode = BattleMenuMode.AbilityType;
						owner.BattleMenu.CurrentParentType = this.typeID;

						List<int> types = owner.Abilities.GetTypes(UseableIn.Battle,
							settings.addTemporaryAbilities, this.typeID);
						settings.typeSorter.Sort(ref types, ORKDataType.AbilityType);

						for(int i = 0; i < types.Count; i++)
						{
							AbilityType abilityType = ORK.AbilityTypes.Get(types[i]);
							if(abilityType.ID == this.typeID || abilityType.ParentType == this.typeID)
							{
								TypeBMItem tmp = new TypeBMItem(
									owner.BattleMenu.Settings.contentLayout.GetChoiceContent(abilityType),
									types[i], this.parent, true);
								if(abilityType.ParentType == this.typeID)
								{
									tmp.hasSubTypes = abilityType.HasSubTypes();
								}
								list.Add(tmp);
							}
						}
					}
					else
					{
						mode = BattleMenuMode.Ability;

						List<AbilityShortcut> abilities = owner.Abilities.GetByType(this.typeID,
							UseableIn.Battle, settings.addTemporaryAbilities, true);
						settings.contentSorter.Sort(ref abilities);
						for(int i = 0; i < abilities.Count; i++)
						{
							if(!abilities[i].Setting.hidden)
							{
								list.Add(new AbilityBMItem(abilities[i],
									owner.BattleMenu.Settings.contentLayout.GetChoiceContent(abilities[i], owner)));
							}
						}
					}
				}
				else if(BMItemType.Item == this.parent.type)
				{
					ItemBattleMenuItem settings = (ItemBattleMenuItem)this.parent.settings;

					if((!this.isSubMenu && settings.subMenu) ||
						this.hasSubTypes)
					{
						mode = BattleMenuMode.ItemType;
						owner.BattleMenu.CurrentParentType = this.typeID;

						List<int> types = owner.Inventory.GetUseableItemTypes(UseableIn.Battle, this.typeID);
						settings.typeSorter.Sort(ref types, ORKDataType.ItemType);

						for(int i = 0; i < types.Count; i++)
						{
							ItemType itemType = ORK.ItemTypes.Get(types[i]);
							if(itemType.ID == this.typeID || itemType.ParentType == this.typeID)
							{
								TypeBMItem tmp = new TypeBMItem(
									owner.BattleMenu.Settings.contentLayout.GetChoiceContent(itemType),
									types[i], this.parent, true);
								if(itemType.ParentType == this.typeID)
								{
									tmp.hasSubTypes = itemType.HasSubTypes();
								}
								list.Add(tmp);
							}
						}
					}
					else
					{
						mode = BattleMenuMode.Item;

						List<ItemShortcut> items = owner.Inventory.GetUseableItemsByType(this.typeID, UseableIn.Battle, true);
						settings.contentSorter.Sort(ref items);
						for(int i = 0; i < items.Count; i++)
						{
							if(!items[i].Setting.hidden)
							{
								list.Add(new ItemBMItem(items[i] as ItemShortcut,
									owner.BattleMenu.Settings.contentLayout.GetChoiceContent(items[i], owner)));
							}
						}
					}
				}
				else if(BMItemType.AIBehaviour == this.parent.type)
				{
					AIBehaviourBattleMenuItem settings = (AIBehaviourBattleMenuItem)this.parent.settings;

					if(this.hasSubTypes)
					{
						mode = BattleMenuMode.AIType;
						owner.BattleMenu.CurrentParentType = this.typeID;

						List<int> types = owner.Inventory.AICollection.GetAIBehaviourTypes(this.typeID);
						settings.typeSorter.Sort(ref types, ORKDataType.AIType);

						for(int i = 0; i < types.Count; i++)
						{
							AIType aiType = ORK.AITypes.Get(types[i]);
							if(aiType.ID == this.typeID || aiType.ParentType == this.typeID)
							{
								TypeBMItem tmp = new TypeBMItem(
									owner.BattleMenu.Settings.contentLayout.GetChoiceContent(aiType),
									types[i], this.parent, true);
								tmp.slotIndex = this.slotIndex;
								if(aiType.ParentType == this.typeID)
								{
									tmp.hasSubTypes = aiType.HasSubTypes();
								}
								list.Add(tmp);
							}
						}
					}
					else
					{
						mode = BattleMenuMode.AIBehaviour;

						List<AIBehaviourShortcut> behaviours = owner.Inventory.AICollection.GetAIBehavioursByType(this.typeID, true);

						for(int i = 0; i < behaviours.Count; i++)
						{
							list.Add(new AIBehaviourBMItem(this.slotIndex, behaviours[i],
								owner.BattleMenu.Settings.contentLayout.GetChoiceContent(behaviours[i])));
						}

						if(settings.unequipButton.UnequipFirst)
						{
							list.Insert(0, new AIBehaviourBMItem(this.slotIndex, null,
								settings.unequipButton.GetButton(owner.BattleMenu.Settings.contentLayout)));
						}
						else if(settings.unequipButton.UnequipLast)
						{
							list.Add(new AIBehaviourBMItem(this.slotIndex, null,
								settings.unequipButton.GetButton(owner.BattleMenu.Settings.contentLayout)));
						}
					}
				}
				else if(BMItemType.AIRuleset == this.parent.type)
				{
					AIRulesetBattleMenuItem settings = (AIRulesetBattleMenuItem)this.parent.settings;

					if(this.hasSubTypes)
					{
						mode = BattleMenuMode.AIType;
						owner.BattleMenu.CurrentParentType = this.typeID;

						List<int> types = owner.Inventory.AICollection.GetAIRulesetTypes(this.typeID);
						settings.typeSorter.Sort(ref types, ORKDataType.AIType);

						for(int i = 0; i < types.Count; i++)
						{
							AIType aiType = ORK.AITypes.Get(types[i]);
							if(aiType.ID == this.typeID || aiType.ParentType == this.typeID)
							{
								TypeBMItem tmp = new TypeBMItem(
									owner.BattleMenu.Settings.contentLayout.GetChoiceContent(aiType),
									types[i], this.parent, true);
								tmp.slotIndex = this.slotIndex;
								if(aiType.ParentType == this.typeID)
								{
									tmp.hasSubTypes = aiType.HasSubTypes();
								}
								list.Add(tmp);
							}
						}
					}
					else
					{
						mode = BattleMenuMode.AIRuleset;

						List<AIRulesetShortcut> rulesets = owner.Inventory.AICollection.GetAIRulesetsByType(this.typeID, true);

						for(int i = 0; i < rulesets.Count; i++)
						{
							list.Add(new AIRulesetBMItem(this.slotIndex, rulesets[i],
								owner.BattleMenu.Settings.contentLayout.GetChoiceContent(rulesets[i])));
						}

						if(settings.unequipButton.UnequipFirst)
						{
							list.Insert(0, new AIRulesetBMItem(this.slotIndex, null,
								settings.unequipButton.GetButton(owner.BattleMenu.Settings.contentLayout)));
						}
						else if(settings.unequipButton.UnequipLast)
						{
							list.Add(new AIRulesetBMItem(this.slotIndex, null,
								settings.unequipButton.GetButton(owner.BattleMenu.Settings.contentLayout)));
						}
					}
				}

				owner.BattleMenu.Settings.AddBack(list);

				owner.BattleMenu.Show(list, 0, mode);
				return true;
			}
			return false;
		}
	}
}
