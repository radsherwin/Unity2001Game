﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class GridDeploymentCell : BaseData
	{
		[ORKEditorHelp("Deployment Type", "Select if this cell is available for deployment:\n" +
			"- None: This cell is not available for deployment.\n" +
			"- Player: Player combatants can be deployed on this cell.\n" +
			"- Ally: Allies of the player can be deployed on this cell.\n" +
			"- Enemy: Enemies of the player can be deployed on this cell.\n" +
			"- All: All combatants can be deployed on this cell.\n" +
			"- Faction: Combatants of a selected faction can be deployed on this cell.", "")]
		public GridDeploymentType type = GridDeploymentType.None;

		[ORKEditorHelp("Faction", "Select the faction that can deploy on this cell.", "")]
		[ORKEditorInfo(ORKDataType.Faction)]
		[ORKEditorLayout("type", GridDeploymentType.Faction, endCheckGroup=true)]
		public int factionID = 0;

		public GridDeploymentCell()
		{

		}

		public bool CanDeploy(Combatant combatant)
		{
			if(this.type == GridDeploymentType.All)
			{
				return true;
			}
			else if(this.type == GridDeploymentType.Player)
			{
				return combatant.IsPlayerControlled();
			}
			else if(this.type == GridDeploymentType.Ally)
			{
				return !combatant.Group.IsEnemy(ORK.Game.ActiveGroup.Leader);
			}
			else if(this.type == GridDeploymentType.Enemy)
			{
				return combatant.Group.IsEnemy(ORK.Game.ActiveGroup.Leader);
			}
			else if(this.type == GridDeploymentType.Faction)
			{
				return combatant.Group.FactionID == this.factionID;
			}
			return false;
		}
	}
}
