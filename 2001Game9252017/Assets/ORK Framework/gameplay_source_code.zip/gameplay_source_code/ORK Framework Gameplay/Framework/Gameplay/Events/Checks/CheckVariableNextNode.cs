
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Events
{
	[System.Serializable]
	public class CheckVariableNextNode : CheckVariableBase
	{
		[ORKEditorInfo(hide=true)]
		public int next = -1;
		
		public CheckVariableNextNode()
		{
			
		}
	}
}
