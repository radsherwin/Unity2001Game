
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public struct MoveSpeed : IBaseData
	{
		[ORKEditorHelp("Speed Type", "Select the speed used to move:\n" +
			"- Walk: The combatant's walk speed.\n" +
			"- Run: The combatant's run speed.\n" +
			"- Sprint: The combatant's sprint speed.\n" +
			"- Value: A defined value.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public MoveSpeedType type;

		[ORKEditorHelp("Speed", "The speed in world units per second used to move.", "")]
		[ORKEditorLayout("type", MoveSpeedType.Value, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float speed;

		public MoveSpeed(MoveSpeedType type, float speed)
		{
			this.type = type;
			this.speed = speed;
		}


		/*
		============================================================================
		Speed functions
		============================================================================
		*/
		public float GetSpeed(Combatant c)
		{
			if(MoveSpeedType.Value == this.type)
			{
				return this.speed;
			}
			else
			{
				return c.GetMoveSpeed(this.type);
			}
		}


		/*
		============================================================================
		Data handling functions
		============================================================================
		*/
		public DataObject GetData()
		{
			DataObject data = new DataObject();
			data.Set("type", this.type);
			data.Set("speed", this.speed);
			return data;
		}

		public void SetData(DataObject data)
		{
			if(data != null)
			{
				data.Get("type", ref this.type);
				data.Get("speed", ref this.speed);
			}
		}

		public void EditorAutoSetup(string fieldName)
		{

		}
	}
}
