
using System.Collections.Generic;
using UnityEngine;

namespace ORKFramework
{
	public class CombatantActions
	{
		private Combatant owner;


		// queue
		private Queue<BaseAction> actionQueue = new Queue<BaseAction>();

		private bool actionFired = false;

		private bool finishAttackQueue = false;


		// cast time
		private AbilityAction castAbilityAction = null;


		// flags
		private bool blockActionUse = false;

		private bool isChoosingAction = false;

		private bool finishedChoosing = false;

		private bool firstAction = false;

		private CombatantActionState actionState = CombatantActionState.Available;

		private bool waitForAction = false;

		private bool selectingCellHighlight = false;


		// ai
		private List<BaseAction> nextAction = new List<BaseAction>();


		// auto attack
		private bool autoAttacking = false;

		private float autoAttackTime = 0;


		// notify
		private CombatantChanged actionStateChangedHandler;
		public event CombatantChanged ActionStateChanged
		{
			add { this.actionStateChangedHandler += value; }
			remove { this.actionStateChangedHandler -= value; }
		}

		private CombatantChanged castingStateChangedHandler;
		public event CombatantChanged CastingStateChanged
		{
			add { this.castingStateChangedHandler += value; }
			remove { this.castingStateChangedHandler -= value; }
		}

		private CombatantChanged choosingStateChangedHandler;
		public event CombatantChanged ChoosingStateChanged
		{
			add { this.choosingStateChangedHandler += value; }
			remove { this.choosingStateChangedHandler -= value; }
		}

		public CombatantActions(Combatant owner)
		{
			this.owner = owner;
		}

		/// <summary>
		/// Notifies all action state change listeners that the action state changed.
		/// </summary>
		public void FireActionStateChanged()
		{
			if(this.actionStateChangedHandler != null)
			{
				this.actionStateChangedHandler(this.owner);
			}
		}

		/// <summary>
		/// Notifies all casting state change listeners that the casting state changed.
		/// </summary>
		public void FireCastingStateChanged()
		{
			if(this.castingStateChangedHandler != null)
			{
				this.castingStateChangedHandler(this.owner);
			}
		}

		/// <summary>
		/// Notifies all casting state change listeners that the casting state changed.
		/// </summary>
		public void FireChoosingStateChanged()
		{
			if(this.choosingStateChangedHandler != null)
			{
				this.choosingStateChangedHandler(this.owner);
			}
		}

		/// <summary>
		/// Clears the queued actions and states - used at the start and end of a battle.
		/// </summary>
		/// <param name='start'>
		/// <c>true</c> if at the start of a battle.
		/// </param>
		public void Clear(bool start)
		{
			this.actionQueue.Clear();
			this.finishedChoosing = false;
			this.actionFired = false;
			this.finishAttackQueue = false;

			this.IsChoosing = false;
			this.waitForAction = false;
			if(this.ActionState == CombatantActionState.Casting &&
				this.castAbilityAction != null &&
				!this.castAbilityAction.castMove)
			{
				this.owner.Status.ChangeStopMovement(-1);
			}
			this.castAbilityAction = null;
			this.autoAttacking = false;
			this.ActionState = CombatantActionState.Available;
			this.owner.AI.Clear();
			this.nextAction.Clear();

			if(start)
			{
				this.autoAttackTime = Random.Range(0.0f, this.owner.Setting.autoAttack.interval);
			}
			this.FireCastingStateChanged();
		}

		/// <summary>
		/// Gets the number of queued actions.
		/// </summary>
		/// <value>
		/// The action count.
		/// </value>
		public int Count
		{
			get { return this.actionQueue.Count; }
		}

		/// <summary>
		/// Gets or sets a value indicating whether the combatant is in action (i.e. performs a battle action).
		/// </summary>
		/// <value>
		/// <c>true</c> if in action; otherwise, <c>false</c>.
		/// </value>
		public CombatantActionState ActionState
		{
			get { return this.actionState; }
			set
			{
				if(this.actionState != value)
				{
					this.actionState = value;

					if(this.actionState == CombatantActionState.Available ||
						this.actionState == CombatantActionState.EndingAction)
					{
						if(this.autoAttacking)
						{
							this.autoAttacking = false;
							this.autoAttackTime = this.owner.Setting.autoAttack.interval;
						}
						else
						{
							this.waitForAction = false;
						}
					}

					this.FireActionStateChanged();
				}
			}
		}

		public bool BlockActionUse
		{
			get { return this.blockActionUse; }
			set
			{
				if(this.blockActionUse != value)
				{
					this.blockActionUse = value;
					this.owner.MarkHUDUpdate();
				}
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether the combatant is choosing an action.
		/// </summary>
		/// <value>
		/// <c>true</c> if choosing; otherwise, <c>false</c>.
		/// </value>
		public bool IsChoosing
		{
			get { return this.isChoosingAction; }
			set
			{
				if(this.isChoosingAction != value)
				{
					this.isChoosingAction = value;
					this.SelectingGridHighlight(true);
					this.FireChoosingStateChanged();
				}
			}
		}

		/// <summary>
		/// Gets a value indicating whether the combatant can choose an action.
		/// </summary>
		/// <value>
		/// <c>true</c> if the combatant can choose; otherwise, <c>false</c>.
		/// </value>
		public bool CanChoose
		{
			get
			{
				return !this.owner.Dead && !this.finishedChoosing &&
					!this.IsChoosing &&
					(this.ActionState == CombatantActionState.Available || this.autoAttacking) &&
					!this.owner.Status.StopMove &&
					((ORK.Battle.IsActiveTime() && ORK.BattleSystem.activeTime.multiChoice) ||
						((ORK.Battle.IsTurnBased() || ORK.Battle.IsPhase()) &&
							this.owner.Battle.UsedActionBar < this.owner.Battle.ActionBar) ||
						!this.waitForAction) &&
					(!ORK.Battle.IsActiveTime() || (!this.finishAttackQueue &&
						this.owner.Battle.UsedActionBar < ORK.BattleSystem.activeTime.maxTimebar)) &&
					((!ORK.Battle.IsTurnBased() && !ORK.Battle.IsPhase()) ||
						this.owner.Battle.UsedActionBar < this.owner.Battle.ActionBar);
			}
		}

		public bool FinishedChoosing
		{
			get { return this.finishedChoosing; }
			set { this.finishedChoosing = value; }
		}

		/// <summary>
		/// The combatant chooses a battle action.
		/// Depending on the combatant (e.g. player, enemy, AI controlled), 
		/// either displays the battle menu or chooses an action based on AI settings.
		/// </summary>
		public void Choose(bool newTurn, bool autoCallMenu)
		{
			ORK.Battle.FireLatestTurn(this.owner);
			if(newTurn)
			{
				this.firstAction = true;
			}

			// grid cell > start turn events
			if(newTurn &&
				ORK.Battle.IsBattleRunning() &&
				ORK.Battle.Grid != null &&
				this.owner.GridCell != null)
			{
				GridCellEventHandler eventHandler = new GridCellEventHandler(this.owner.GridCell, GridCellEventStartType.StartTurn);
				if(eventHandler.HasEvents)
				{
					eventHandler.Start(this.owner, delegate ()
					{
						this.owner.Battle.InitNewTurn(true);
						this.Choose(false, autoCallMenu);
					});
				}
				else
				{
					this.owner.Battle.InitNewTurn(true);
					this.Choose(false, autoCallMenu);
				}
			}
			// choose actions
			else if((newTurn && this.owner.Battle.InitNewTurn(true)) ||
				(!newTurn && !this.owner.CheckDeath()))
			{
				this.IsChoosing = true;

				// grid move first (player controlled only)
				if(ORK.Battle.IsBattleRunning() &&
					ORK.Battle.System != null &&
					ORK.Battle.Grid != null &&
					(AutoGridMoveType.Always == ORK.Battle.System.playerAutoGridMove ||
						(AutoGridMoveType.FirstAction == ORK.Battle.System.playerAutoGridMove &&
							this.firstAction)) &&
					!this.owner.IsAIControlled() &&
					this.owner.IsPlayerControlled() &&
					this.owner.Battle.GridMoveRange > 0 &&
					!this.owner.Status.StopMove &&
					!this.owner.Status.StopMovement &&
					this.owner.Battle.GridMoveState == GridMoveState.Available)
				{
					this.firstAction = false;
					this.owner.BattleMenu.StartGridMoveSelection(null, autoCallMenu);
				}
				// action choice
				else
				{
					this.firstAction = false;

					List<Combatant> allies = ORK.Game.Combatants.Get(this.owner,
					true, Range.Battle, Consider.No, Consider.Ignore, Consider.Yes);
					List<Combatant> enemies = ORK.Game.Combatants.Get(this.owner,
					true, Range.Battle, Consider.Yes, Consider.Ignore, Consider.Yes);

					if(this.owner.Status.StopMove ||
						(this.owner.Status.AutoAttack && (this.owner.Status.BlockAttack || enemies.Count == 0)) ||
						(this.owner.Status.AttackAllies && (this.owner.Status.BlockAttack || allies.Count == 0)))
					{
						this.Add(new NoneAction(this.owner), false);
					}
					else if(this.owner.Status.AutoAttack || this.owner.Status.AttackAllies)
					{
						if(this.owner.IsAIControlled())
						{
							this.owner.AI.RealTimeTimeout = this.owner.Setting.aiTimeout;
						}

						BaseAction action = new AbilityAction(this.owner, this.owner.Abilities.GetCurrentBaseAttack());
						action.AutoTarget(this.owner.Battle.LastTargets, allies, enemies);
						this.Add(action, false);
					}
					else if(this.nextAction.Count > 0)
					{
						BaseAction action = this.nextAction[0];
						this.nextAction.RemoveAt(0);
						this.Add(action, false);
					}
					else if(this.owner.IsAIControlled())
					{
						this.Add(this.owner.AI.GetAction(allies, enemies), false);
					}
					else if(this.owner.IsPlayerControlled())
					{
						if(autoCallMenu)
						{
							this.owner.ShowBattleMenu();
						}
					}
					else
					{
						this.owner.Battle.EndTurnCommand();
					}
				}
			}
			else
			{
				this.owner.Battle.EndTurnCommand();
			}
		}

		public void ChooseAuto(bool newTurn)
		{
			// grid cell > start turn events
			if(newTurn &&
				ORK.Battle.IsBattleRunning() &&
				ORK.Battle.Grid != null &&
				this.owner.GridCell != null)
			{
				GridCellEventHandler eventHandler = new GridCellEventHandler(this.owner.GridCell, GridCellEventStartType.StartTurn);
				if(eventHandler.HasEvents)
				{
					eventHandler.Start(this.owner, delegate ()
					{
						this.owner.Battle.InitNewTurn(true);
						this.ChooseAuto(false);
					});
				}
				else
				{
					this.owner.Battle.InitNewTurn(true);
					this.ChooseAuto(false);
				}
			}
			// auto choose action
			else if((newTurn && this.owner.Battle.InitNewTurn(true)) ||
				(!newTurn && !this.owner.CheckDeath()))
			{
				this.IsChoosing = true;
				this.Add(this.owner.AI.GetAction(
						ORK.Game.Combatants.Get(this.owner, true, Range.Battle,
							Consider.No, Consider.Ignore, Consider.Ignore),
						ORK.Game.Combatants.Get(this.owner, true, Range.Battle,
							Consider.Yes, Consider.Ignore, Consider.Ignore)),
					false);
			}
			else
			{
				this.owner.Battle.EndTurnCommand();
			}
		}

		public void SelectingGridHighlight(bool doHighlight)
		{
			if(ORK.Battle.Grid != null &&
				this.owner.GridCell != null)
			{
				GridHighlightType highlightType = GridHighlightType.None;

				// player
				if(this.owner.IsPlayerControlled())
				{
					if(ORK.BattleSystem.gridHighlights.selectingPlayerHighlight.enable)
					{
						highlightType = GridHighlightType.SelectingPlayer;
					}
				}
				// enemy
				else if(this.owner.IsEnemy(ORK.Game.ActiveGroup.Leader))
				{
					if(ORK.BattleSystem.gridHighlights.selectingEnemyHighlight.enable)
					{
						highlightType = GridHighlightType.SelectingEnemy;
					}
				}
				// ally
				else if(ORK.BattleSystem.gridHighlights.selectingAllyHighlight.enable)
				{
					highlightType = GridHighlightType.SelectingAlly;
				}

				if(highlightType != GridHighlightType.None)
				{
					if(doHighlight && this.isChoosingAction)
					{
						if(!this.selectingCellHighlight)
						{
							this.selectingCellHighlight = true;
							this.owner.GridCell.Highlight(highlightType);
						}
					}
					else if(this.selectingCellHighlight)
					{
						this.selectingCellHighlight = false;
						this.owner.GridCell.StopHighlight(highlightType);
					}
				}
			}
		}


		/*
		============================================================================
		Auto attack functions
		============================================================================
		*/
		/// <summary>
		/// Gets a value indicating whether the combatant is currently auto attacking.
		/// </summary>
		/// <value>
		/// <c>true</c> if auto attacking; otherwise, <c>false</c>.
		/// </value>
		public bool AutoAttacking
		{
			get { return this.autoAttacking; }
		}


		/*
		============================================================================
		Battle action functions
		============================================================================
		*/
		/// <summary>
		/// Lets the combatant fire a battle action. 
		/// Depending on the state and battle systems the action can be added to the 
		/// battle's action queue, the combatant's action queue or not fired at all.
		/// </summary>
		/// <param name='action'>
		/// The action.
		/// </param>
		/// <param name='newTurn'>
		/// <c>true</c> if a new turn should be initialized.
		/// </param>
		public void Add(BaseAction action, bool newTurn)
		{
			if(newTurn && !this.owner.Battle.InitNewTurn(true))
			{
				ORK.Battle.Actions.Add(null);
				return;
			}
			if(action is GridMoveAction &&
				this.owner.Battle.GridMoveState != GridMoveState.Available)
			{
				action = null;
			}

			this.owner.EndBattleMenu(false);
			this.IsChoosing = false;

			if(action != null &&
				ORK.Battle.IsActiveTime())
			{
				bool add = true;
				if(!this.owner.Dead && !action.IsType(ActionType.CounterAttack) && !action.autoAttackFlag)
				{
					if((!ORK.BattleSystem.activeTime.multiChoice && this.owner.Battle.UsedActionBar == 0) ||
						(ORK.BattleSystem.activeTime.multiChoice &&
						this.owner.Battle.UsedActionBar + action.ActionCost <= ORK.BattleSystem.activeTime.maxTimebar))
					{
						this.owner.Battle.UsedActionBar += action.ActionCost;
					}
					else
					{
						add = false;
						ORK.Battle.Actions.Add(null);
					}
				}

				if(add)
				{
					if(action is GridMoveAction)
					{
						this.owner.Battle.GridMoveState = GridMoveState.Selected;
					}

					if(this.owner.Battle.ActionBar < ORK.BattleSystem.activeTime.actionBorder ||
						this.actionQueue.Count > 0 || this.actionFired)
					{
						this.actionQueue.Enqueue(action);
					}
					else
					{
						this.actionFired = true;
						ORK.Battle.Actions.Add(action);
					}
				}
			}
			else if(action != null &&
				(ORK.Battle.IsTurnBased() || ORK.Battle.IsPhase()))
			{
				bool add = true;
				if(!this.owner.Dead && !action.IsType(ActionType.CounterAttack) && !action.autoAttackFlag)
				{
					if(this.owner.Battle.UsedActionBar + action.ActionCost <= this.owner.Battle.ActionBar)
					{
						this.owner.Battle.UsedActionBar += action.ActionCost;
					}
					else
					{
						add = false;
						ORK.Battle.Actions.Add(null);
					}
				}

				if(add)
				{
					if(action is GridMoveAction)
					{
						this.owner.Battle.GridMoveState = GridMoveState.Selected;
					}

					this.actionFired = true;
					ORK.Battle.Actions.Add(action);
				}
			}
			else
			{
				if(action is GridMoveAction)
				{
					this.owner.Battle.GridMoveState = GridMoveState.Selected;
				}

				this.actionFired = true;
				ORK.Battle.Actions.Add(action);
			}
		}

		/// <summary>
		/// Notifies the combatant that his actions 
		/// have been removed from the battle's action queue.
		/// </summary>
		public void Removed()
		{
			this.actionFired = false;
			this.finishAttackQueue = false;
			this.finishedChoosing = false;
			this.owner.Battle.TurnPerformed = true;
			this.owner.Battle.ReceiveActionsPerTurn = true;
			this.waitForAction = false;
			this.owner.Battle.TurnValue = 0;
			this.owner.Battle.ActionBar = 0;
			this.owner.Battle.UsedActionBar = 0;
		}

		/// <summary>
		/// Dequeues the next action from the combatant's action queue 
		/// and add's it to the battle's action queue.
		/// </summary>
		/// <returns>
		/// <c>true</c> if an action was available; otherwise <c>false</c>.
		/// </returns>
		public bool DequeueNextAction()
		{
			if(this.actionQueue.Count > 0)
			{
				this.actionFired = true;
				this.waitForAction = true;
				this.owner.Battle.Defending = false;
				ORK.Battle.Actions.Add(this.actionQueue.Dequeue());
				return true;
			}
			else
			{
				this.actionFired = false;
				this.finishAttackQueue = false;
				if(this.finishedChoosing ||
					this.owner.Battle.UsedActionBar >= this.owner.Battle.ActionBar)
				{
					this.owner.Battle.UsedActionBar = this.owner.Battle.ActionBar;
					this.owner.Battle.ReceiveActionsPerTurn = true;
				}
				this.finishedChoosing = false;
				this.waitForAction = false;
				return false;
			}
		}

		/// <summary>
		/// Adds a battle action as next action of the combatant. 
		/// The combatant will try to use this action the next time he can choose an action.
		/// </summary>
		/// <param name='action'>
		/// The battle action.
		/// </param>
		public void AddNextAction(BaseAction action, NextBattleActionChange actionChange)
		{
			if(action != null)
			{
				if(NextBattleActionChange.Add == actionChange)
				{
					this.nextAction.Add(action);
				}
				else if(NextBattleActionChange.Set == actionChange)
				{
					this.nextAction.Clear();
					this.nextAction.Add(action);
				}
				else if(NextBattleActionChange.First == actionChange)
				{
					this.nextAction.Insert(0, action);
				}
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether the combatant should finish his action queue 
		/// (i.e. use all actions added to his queue).
		/// </summary>
		/// <value>
		/// <c>true</c> if the action queue should be finished; otherwise, <c>false</c>.
		/// </value>
		public bool FinishAttackQueue
		{
			get { return this.finishAttackQueue; }
			set { this.finishAttackQueue = value; }
		}

		/// <summary>
		/// Gets or sets a value indicating whether the combatant is waiting for an action to start.
		/// </summary>
		/// <value>
		/// <c>true</c> if waiting; otherwise, <c>false</c>.
		/// </value>
		public bool IsWaiting
		{
			get { return this.waitForAction; }
			set { this.waitForAction = value; }
		}

		/// <summary>
		/// Gets a value indicating whether the combatant fired an action.
		/// </summary>
		/// <value>
		/// <c>true</c> if fired; otherwise, <c>false</c>.
		/// </value>
		public bool Fired
		{
			get { return this.actionFired; }
		}

		/// <summary>
		/// Checks if the combatant is able to perform an action.
		/// </summary>
		/// <returns>
		/// <c>true</c> if the combatant can perform actions; otherwise false.
		/// </returns>
		/// <param name='isAutoAttack'>
		/// <c>true</c> if checking for performing an auto attack.
		/// </param>
		public bool AllowPerformingAction(bool isAutoAttack)
		{
			return this.ActionState == CombatantActionState.Available &&
				(!ORK.Battle.IsActiveTime() ||
					(this.owner.Battle.ActionBar >= this.owner.Battle.UsedActionBar &&
					(this.finishAttackQueue || isAutoAttack ||
						((UseTimebarAction.ActionBorder == ORK.BattleSystem.activeTime.useTimebarAction &&
							this.owner.Battle.ActionBar >= ORK.BattleSystem.activeTime.actionBorder) ||
						(UseTimebarAction.MaxTimebar == ORK.BattleSystem.activeTime.useTimebarAction &&
							this.owner.Battle.ActionBar >= ORK.BattleSystem.activeTime.maxTimebar) ||
						(UseTimebarAction.EndTurn == ORK.BattleSystem.activeTime.useTimebarAction &&
							this.finishedChoosing)))));
		}


		/*
		============================================================================
		Ability cast functions
		============================================================================
		*/
		/// <summary>
		/// Determines whether the combatant is casting an ability.
		/// </summary>
		/// <returns>
		/// <c>true</c> if casting; otherwise, <c>false</c>.
		/// </returns>
		public bool IsCastingAbility
		{
			get
			{
				return this.ActionState == CombatantActionState.Casting &&
				  this.castAbilityAction != null;
			}
		}

		public AbilityShortcut GetCastingAbility()
		{
			if(this.ActionState == CombatantActionState.Casting &&
				this.castAbilityAction != null)
			{
				return this.castAbilityAction.Ability;
			}
			return null;
		}

		public bool CanCastMove()
		{
			if(this.ActionState == CombatantActionState.Casting &&
				this.castAbilityAction != null)
			{
				return this.castAbilityAction.castMove;
			}
			return false;
		}

		public bool CanCancelCast()
		{
			if(this.ActionState == CombatantActionState.Casting &&
				this.castAbilityAction != null)
			{
				return this.castAbilityAction.Ability.Cancelable();
			}
			return false;
		}

		/// <summary>
		/// Gets the name of the casting ability.
		/// </summary>
		/// <returns>
		/// The ability name.
		/// </returns>
		public string GetCastAbilityName()
		{
			if(this.ActionState == CombatantActionState.Casting &&
				this.castAbilityAction != null)
			{
				return this.castAbilityAction.GetName();
			}
			return "";
		}

		/// <summary>
		/// The combatant will cast a defined ability.
		/// </summary>
		/// <param name='action'>
		/// The ability action to cast.
		/// </param>
		public void CastAbility(AbilityAction action)
		{
			this.castAbilityAction = action;
			this.ActionState = CombatantActionState.Casting;
			if(!this.castAbilityAction.castMove)
			{
				this.owner.Status.ChangeStopMovement(1);
			}
			this.FireCastingStateChanged();
		}

		/// <summary>
		/// Gets the remaining cast time of the casting ability.
		/// </summary>
		/// <returns>
		/// The cast time.
		/// </returns>
		public float GetCastTime()
		{
			float time = -1;
			if(this.ActionState == CombatantActionState.Casting &&
				this.castAbilityAction != null)
			{
				time = this.castAbilityAction.castTime;
			}
			return time;
		}

		/// <summary>
		/// Gets the maximum cast time of the casting ability.
		/// </summary>
		/// <returns>
		/// The maximum cast time.
		/// </returns>
		public float GetCastTimeMax()
		{
			float time = -1;
			if(this.ActionState == CombatantActionState.Casting &&
				this.castAbilityAction != null)
			{
				time = this.castAbilityAction.castTimeMax;
			}
			return time;
		}

		/// <summary>
		/// Cancel casting an ability.
		/// </summary>
		public void CancelCast()
		{
			if(this.ActionState == CombatantActionState.Casting &&
				this.castAbilityAction != null &&
				this.castAbilityAction.CancelAbilityCast())
			{
				if(ORK.BattleTexts.useCastCancelNotification && ORK.BattleTexts.castCancelTextSettings != null)
				{
					ORK.BattleTexts.castCancelTextSettings.ShowText(this.GetCastAbilityName(), this.owner.GameObject);
				}

				if(this.owner.IsAIControlled())
				{
					this.owner.AI.RealTimeTimeout = this.owner.Setting.aiTimeout;
				}

				this.ActionState = CombatantActionState.Available;

				if(!this.castAbilityAction.castMove)
				{
					this.owner.Status.ChangeStopMovement(-1);
				}
				this.waitForAction = false;

				if(!this.castAbilityAction.autoAttackFlag &&
					(ORK.Battle.IsActiveTime() ||
					ORK.Battle.IsTurnBased() ||
					ORK.Battle.IsPhase()))
				{
					this.owner.Battle.ActionBar -= this.castAbilityAction.ActionCost;
					this.owner.Battle.UsedActionBar -= this.castAbilityAction.ActionCost;
				}
				this.castAbilityAction = null;

				this.FireCastingStateChanged();
				this.DequeueNextAction();
			}
		}


		/*
		============================================================================
		Time functions
		============================================================================
		*/
		/// <summary>
		/// Update function called each frame.
		/// </summary>
		/// <param name='battleTime'>
		/// The time since the last tick.
		/// </param>
		public void Tick(float battleTime)
		{
			// ability casting
			if(this.ActionState == CombatantActionState.Casting &&
				this.castAbilityAction != null &&
				!this.autoAttacking)
			{
				this.castAbilityAction.castTime += battleTime;
				if(this.castAbilityAction.castTime >= this.castAbilityAction.castTimeMax)
				{
					AbilityAction tmpCast = this.castAbilityAction;
					tmpCast.casted = true;

					this.castAbilityAction = null;
					this.ActionState = CombatantActionState.InAction;
					this.waitForAction = false;

					if(!tmpCast.castMove)
					{
						this.owner.Status.ChangeStopMovement(-1);
					}

					this.FireCastingStateChanged();

					ORK.Battle.Actions.Perform(tmpCast);
				}
				this.owner.MarkHUDUpdate();
			}

			// auto attack
			if(this.owner.Battle.InBattle &&
				this.owner.Battle.EnableAutoAttack &&
				!this.autoAttacking && !this.owner.Battle.Defending &&
				this.owner.Setting.autoAttack.active &&
				this.ActionState == CombatantActionState.Available &&
				ORK.Battle.IsDynamicCombat() && ORK.Battle.CanAutoAttack &&
				(!this.IsChoosing || !ORK.Battle.MenuBlockAutoAttack))
			{
				if(this.autoAttackTime > 0)
				{
					this.autoAttackTime -= battleTime;
				}
				else if(!this.owner.Status.StopMove)
				{
					BaseAction autoAction = this.owner.Setting.autoAttack.GetAction(this.owner);
					if(autoAction != null)
					{
						this.autoAttacking = true;
						this.Add(autoAction, false);
					}
				}
			}
		}
	}
}
