﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class StatusValueResearchItem : BaseData, IContent
	{
		[ORKEditorHelp("Status Value", "Select the status value that can be upgraded.", "")]
		[ORKEditorInfo(ORKDataType.StatusValue, "type", StatusValueType.Normal, true)]
		public int statusID = 0;

		[ORKEditorHelp("Change", "Define the value added to the status value.", "")]
		public int change = 1;

		[ORKEditorHelp("Show Notification", "The status value's change notifications will be displayed (if defined).", "")]
		public bool showNotification = true;

		[ORKEditorHelp("Show Console", "The changes will be displayed in the console.", "")]
		public bool showConsole = true;

		public StatusValueResearchItem()
		{

		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public int ID
		{
			get { return this.statusID; }
		}

		public int TypeID
		{
			get { return ORK.StatusValues.Get(this.statusID).statusTypeID; }
		}

		public string GetName()
		{
			return ORK.StatusValues.Get(this.statusID).GetName();
		}

		public string GetDescription()
		{
			return ORK.StatusValues.Get(this.statusID).GetDescription();
		}

		public string GetIconTextCode()
		{
			return ORK.StatusValues.Get(this.statusID).GetIconTextCode();
		}

		public Texture GetIcon()
		{
			return ORK.StatusValues.Get(this.statusID).GetIcon();
		}

		public GUIContent GetContent()
		{
			return ORK.StatusValues.Get(this.statusID).GetContent();
		}

		public IContentSimple GetTypeContent()
		{
			return ORK.StatusTypes.Get(ORK.StatusValues.Get(this.statusID).statusTypeID);
		}

		public string GetInfo(Combatant c)
		{
			return "";
		}


		/*
		============================================================================
		Learning functions
		============================================================================
		*/
		public void ResearchFinished(Combatant combatant)
		{
			combatant.Status[this.statusID].AddBaseValue(this.change);
			combatant.Status[this.statusID].AddValue(this.change, false, false, false, false,
				this.showNotification, this.showConsole);
			combatant.MarkResetStatus();
		}
	}
}
