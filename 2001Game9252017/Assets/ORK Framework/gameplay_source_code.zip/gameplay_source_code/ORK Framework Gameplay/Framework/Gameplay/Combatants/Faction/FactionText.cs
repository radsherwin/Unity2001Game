﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class FactionText : BaseData
	{
		[ORKEditorHelp("Text", "Define this faction text.", "")]
		[ORKEditorInfo(isTextArea=true)]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public string[] text = ArrayHelper.CreateArray(ORK.Languages.Count, "");

		public FactionText()
		{

		}
	}
}
