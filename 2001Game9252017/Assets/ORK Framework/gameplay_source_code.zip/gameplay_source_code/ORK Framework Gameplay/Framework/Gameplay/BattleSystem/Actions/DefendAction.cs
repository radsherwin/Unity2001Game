
using System.Collections.Generic;

namespace ORKFramework
{
	public class DefendAction : BaseAction
	{
		public DefendAction(Combatant user)
		{
			this.user = user;
			this.target = new List<Combatant>();
			this.target.Add(user);

			this.actionCost = ORK.Battle.GetDefendActionCost(this.user);

			this.CheckActionAffiliation();
		}

		public override bool IsType(ActionType t)
		{
			return ActionType.Defend == t;
		}

		public override IShortcut Shortcut
		{
			get { return this.user.Shortcuts.DefendShortcut; }
		}


		/*
		============================================================================
		Action performing functions
		============================================================================
		*/
		public override bool CanUse()
		{
			return this.user != null && !this.user.Dead &&
				!this.user.Status.BlockDefend;
		}

		protected override void ActionStartSetup()
		{
			if(ORK.BattleTexts.showInfo)
			{
				ORK.BattleTexts.defendInfo.Show(this.user, "");
			}

			if(ORK.ConsoleSettings.displayActions)
			{
				if(this.user.Setting.ownConsoleDefend)
				{
					this.user.Setting.consoleDefend.Print(this.user, this.target, null);
				}
				else
				{
					ORK.ConsoleSettings.actionDefend.Print(this.user, this.target, null);
				}
			}

			this.user.GetDefendEvent(ref this.events);
		}

		public override void Calculate(List<Combatant> ts, float damageFactor, bool animate)
		{
			if(!ORK.BattleSettings.camera.IsNone)
			{
				if(ts.Count == 1 && ts[0] != null && ts[0].GameObject != null)
				{
					ORK.BattleSettings.camera.SetLatestDamage(ts[0].GameObject.transform);
				}
				else if(ts.Count > 1)
				{
					ORK.BattleSettings.camera.SetLatestDamage(ORK.Battle.GetGroupCenter(ts).transform);
				}
			}

			if(this.user != null && !this.user.Dead &&
				ts.Count > 0 && ts[0] != null &&
				!this.user.Status.BlockDefend)
			{
				this.user.Battle.Defending = true;
				this.userConsumeDone = true;
			}
		}

		protected override void ActionEndSetup()
		{
			this.user.Abilities.LastAbilityID = -1;
		}
	}
}
