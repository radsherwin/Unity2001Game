
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GroupShortcutSlot : ISaveData
	{
		private Combatant owner;

		private IShortcut shortcut;


		// load index
		private int tmpIndex = -1;

		public GroupShortcutSlot()
		{

		}

		public GroupShortcutSlot(Combatant owner, IShortcut shortcut)
		{
			this.owner = owner;
			this.shortcut = shortcut;
		}

		public GroupShortcutSlot(Group group, DataObject data)
		{
			this.LoadGame(data);
			this.owner = group.MemberAt(this.tmpIndex);
		}


		/*
		============================================================================
		Get functions
		============================================================================
		*/
		public Combatant Owner
		{
			get { return this.owner; }
		}

		public IShortcut Shortcut
		{
			get
			{
				this.RenewShortcut();
				return this.shortcut;
			}
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public bool CheckShortcut()
		{
			return this.shortcut is MoneyShortcut ||
				(this.shortcut is AbilityShortcut &&
					this.owner.Abilities.Has((AbilityShortcut)this.shortcut)) ||
				((this.shortcut is ItemShortcut || this.shortcut is EquipShortcut) &&
					this.owner.Inventory.Has(this.shortcut)) ||
				shortcut is DefendShortcut ||
				shortcut is EscapeShortcut ||
				shortcut is NoneShortcut ||
				shortcut is GridMoveShortcut ||
				shortcut is GridOrientationShortcut ||
				shortcut is GridExamineShortcut;
		}

		private void RenewShortcut()
		{
			if(this.shortcut is AbilityShortcut)
			{
				this.shortcut = this.owner.Abilities.Get(this.shortcut as AbilityShortcut);
			}
			else if(this.shortcut is ItemShortcut)
			{
				if(this.owner.Inventory.Has(this.shortcut))
				{
					this.shortcut = this.owner.Inventory.GetItem(this.shortcut.ID);
				}
			}
			else if(this.shortcut is EquipShortcut)
			{
				if(this.owner.Inventory.Has(this.shortcut))
				{
					this.shortcut = this.owner.Inventory.GetEquipment(this.shortcut as EquipShortcut);
				}
			}
			else if(this.shortcut is MoneyShortcut)
			{
				if(this.owner.Inventory.Has(this.shortcut))
				{
					this.shortcut = this.owner.Inventory.GetMoneyShortcut(this.shortcut.ID);
				}
			}
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();

			data.Set("combatant", this.owner.Group.GetMemberIndex(this.owner));
			data.Set("shortcut", this.shortcut.SaveGame());

			return data;
		}

		public void LoadGame(DataObject data)
		{
			if(data != null)
			{
				this.tmpIndex = -1;
				data.Get("combatant", ref this.tmpIndex);

				DataObject tmp = data.GetFile("shortcut");
				if(tmp != null)
				{
					string typeInfo = "";
					tmp.Get(DataSerializer.TYPE, ref typeInfo);
					if(typeInfo.EndsWith("Shortcut"))
					{
						IShortcut tmpShortcut = ReflectionTypeHandler.Instance.CreateInstance(
							System.Type.GetType("ORKFramework." + typeInfo)) as IShortcut;
						if(tmpShortcut != null &&
							ShortcutHelper.CheckValidID(tmpShortcut))
						{
							tmpShortcut.LoadGame(tmp);
							this.shortcut = tmpShortcut;
						}
					}
				}
			}
		}
	}
}
