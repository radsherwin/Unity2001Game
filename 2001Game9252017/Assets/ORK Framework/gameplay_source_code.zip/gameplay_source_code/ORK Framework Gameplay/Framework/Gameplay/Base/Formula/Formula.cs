
using UnityEngine;
using ORKFramework.Formulas;
using ORKFramework.Formulas.Steps;
using System.Collections.Generic;

namespace ORKFramework.Formulas
{
	public class Formula : BaseNode
	{
		[ORKEditorHelp("Name", "The name of the formula.", "")]
		[ORKEditorInfo("Formula Settings", "Set the name and base settings of the formula.", "",
			expandWidth=true)]
		public string name = "";

		[ORKEditorHelp("Type", "The type of the formula.\n" +
			"Formula types are only used to filter the formula list.", "")]
		[ORKEditorInfo(ORKDataType.FormulaType)]
		public int typeID = 0;


		// min/max values
		[ORKEditorHelp("Use Mininum Value", "The formula result will have a minimum value.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useMinValue = false;

		[ORKEditorHelp("Minimum Value", "If the formula result is below this value, it will be set to this value.", "")]
		[ORKEditorLayout("useMinValue", true, endCheckGroup=true)]
		public float minValue = 0;

		[ORKEditorHelp("Use Maximum Value", "The formula result will have a maximum value.", "")]
		public bool useMaxValue = false;

		[ORKEditorHelp("Maximum Value", "If the formula result is above this value, it will be set to this value.", "")]
		[ORKEditorLayout("useMaxValue", true, endCheckGroup=true)]
		[ORKEditorLimit("minValue", false)]
		public float maxValue = 0;

		[ORKEditorInfo(separator=true, labelText="Start Value")]
		public FormulaFloat startValue = new FormulaFloat();

		[ORKEditorHelp("Operator", "The operator decides how the start value is calculated to " +
			"the initial value passed to the formula (e.g. from an ability):\n" +
			"- Add: Adds the start value to the initial value.\n" +
			"- Sub: Subtracts the start value from the initial value.\n" +
			"- Multiply: Multiplies the initial value with the start value.\n" +
			"- Divide: Divides the initial value by the start value.\n" +
			"- Modulo: Uses the modulo operator, the initial value % the start value.\n" +
			"- Power Of: The initial value to the power of the start value.\n" +
			"- Log: The initial value is used in a logarithmic calculation with the start value as base.\n" +
			"- Set: Sets the current formula value to the start value, the initial value is lost.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public FormulaOperator formulaOperator = FormulaOperator.Set;


		// formula steps
		[ORKEditorInfo(hide=true)]
		public int startIndex = -1;

		[ORKEditorInfo(hide=true)]
		public BaseFormulaStep[] step = new BaseFormulaStep[0];

		public Formula()
		{

		}

		public Formula(string n) : base()
		{
			this.name = n;
		}

		public float Calculate(FormulaCall call)
		{
			if(call.user != null && call.target != null)
			{
				ValueHelper.UseOperator(ref call.result, this.startValue.GetValue(call), this.formulaOperator);
				int currentStep = this.startIndex;

				while(currentStep >= 0 && currentStep < this.step.Length)
				{
					if(this.step[currentStep].IsEnabled)
					{
						currentStep = this.step[currentStep].Calculate(call);
					}
					else
					{
						currentStep = this.step[currentStep].GetNext(0);
					}
				}
			}

			if(this.useMinValue && call.result < this.minValue)
			{
				call.result = this.minValue;
			}
			else if(this.useMaxValue && call.result > this.maxValue)
			{
				call.result = this.maxValue;
			}

			return call.result;
		}

		public float CalculatePreview(FormulaCall call)
		{
			if(call.user != null && call.target != null)
			{
				ValueHelper.UseOperator(ref call.result, this.startValue.GetValue(call), this.formulaOperator);
				int currentStep = this.startIndex;

				while(currentStep >= 0 && currentStep < this.step.Length)
				{
					if(this.step[currentStep].IsEnabled)
					{
						currentStep = this.step[currentStep].CalculatePreview(call);
					}
					else
					{
						currentStep = this.step[currentStep].GetNext(0);
					}
				}
			}

			if(this.useMinValue && call.result < this.minValue)
			{
				call.result = this.minValue;
			}
			else if(this.useMaxValue && call.result > this.maxValue)
			{
				call.result = this.maxValue;
			}

			return call.result;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeName()
		{
			return "Formula Settings";
		}

		public override string GetNodeDetails()
		{
			return (this.useMinValue ? this.minValue.ToString() : "X") + " - " + (this.useMaxValue ? this.maxValue.ToString() : "X");
		}

		public override string GetNextName(int index)
		{
			return "Start";
		}

		public override bool IsRemovable()
		{
			return false;
		}


		/*
		============================================================================
		Next functions
		============================================================================
		*/
		public override int GetNextCount()
		{
			return 1;
		}

		public override int GetNext(int index)
		{
			return this.startIndex;
		}

		public override void SetNext(int index, int next)
		{
			this.startIndex = next;
		}
	}
}
