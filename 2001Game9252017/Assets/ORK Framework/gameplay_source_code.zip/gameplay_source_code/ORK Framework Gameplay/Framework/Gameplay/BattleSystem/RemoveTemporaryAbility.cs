﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class RemoveTemporaryAbility
	{
		public int id = -1;

		public float time = 0;

		public EndAfter endType = EndAfter.None;

		public RemoveTemporaryAbility(int id, float time, EndAfter endType)
		{
			this.id = id;
			this.time = time;
			this.endType = endType;
		}

		public void Remove(Combatant combatant)
		{
			combatant.Abilities.RemoveTemporaryAbility(this.id);
		}


		/*
		============================================================================
		Time functions
		============================================================================
		*/
		public bool ReduceTurn()
		{
			if(EndAfter.Turn == this.endType)
			{
				this.time -= 1;
			}
			return this.time <= 0;
		}

		public bool ReduceTime(float t)
		{
			if(EndAfter.Time == this.endType)
			{
				this.time -= t;
			}
			return this.time <= 0;
		}

		public bool IsRemoveOnBattleEnd()
		{
			return EndAfter.Turn == this.endType;
		}
	}
}
