﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GridExamineSettings : BaseData
	{
		// settings
		[ORKEditorHelp("Allow Cancel", "The grid cell selection can be canceled using the 'Cancel' key defined in the game controls.\n" +
			"If disabled, the cell of the selecting combatant must be selected and accepted to stop the grid examination.", "")]
		public bool allowCancel = false;

		[ORKEditorHelp("Block Action Use", "Using actions is blocked for the combatant during the grid cell selection.\n" +
			"This isn't used during 'Always Active' selection phases.", "")]
		public bool blockActionUse = false;


		// always active
		[ORKEditorHelp("Always Active", "Grid examine is always active during grid battles.\n" +
			"Please note that grid examine isn't active during other cell selections (e.g. move command or target cell selections), " +
			"but you can enable showing the cell info and combatant info dialogues for the selected cell in the individual settings.\n" +
			"'Block Action Use' is not used during 'Always Active' selection phases.", "")]
		[ORKEditorInfo(separator=true, labelText="Always Active Examine")]
		public bool alwaysActive = false;

		[ORKEditorHelp("During Target Selection", "Grid examine is also active during target selections.\n" +
			"If disabled, 'Always Active' isn't used when a target for an action is being selected.", "")]
		[ORKEditorLayout("alwaysActive", true)]
		public bool alwaysActiveDuringTargetSelection = false;

		[ORKEditorHelp("During Actions", "Grid examine is also active during actions.\n" +
			"If disabled, 'Always Active' is only used while no action is being performed.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool alwaysActiveDuringActions = false;

		// external
		[ORKEditorHelp("Examine Cell", "Display the cell info text for the selected combatant's cell during target selections.\n" +
			"This isn't used for target cell selections, see the separate setting in the 'Target Cell Selection' settings.", "")]
		[ORKEditorLayout(new string[] { "alwaysActive", "alwaysActiveDuringTargetSelection" },
			new System.Object[] { false, false },
			needed=Needed.One)]
		[ORKEditorInfo(separator=true, labelText="Target Selection Examine")]
		public bool targetExamineCell = false;

		[ORKEditorHelp("Examine Cell Combatant", "Display the combatant info dialogue for the selected combatant ('Examine Grid' settings).\n" +
			"Please note that this only shows the information dialogue and " +
			"doesn't show cell highlights (e.g. move range of a combatant).\n" +
			"This isn't used for target cell selections, see the separate setting in the 'Target Cell Selection' settings", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool targetExamineCellCombatant = false;


		// camera control target
		[ORKEditorHelp("Camera Control Target", "Changes the camera control target to the selected cell.\n" +
			"The camera control must descent from the 'BaseCameraControl' class (like all built-in camera controls).", "")]
		[ORKEditorInfo("Camera Control Target", "Optionally change the camera control target to the selected cell.\n" +
			"The camera control must descent from the 'BaseCameraControl' class (like all built-in camera controls).", "")]
		public bool cameraControlTarget = false;

		[ORKEditorHelp("Own Transition", "Use a custom camera control transition when changing the camera control target.\n" +
			"If disabled, the default transition defined in 'Base/Control > Game Controls' will be used.", "")]
		[ORKEditorLayout("cameraControlTarget", true)]
		public bool ownControlTargetTransition = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownControlTargetTransition", true, endCheckGroup=true, endGroups=2, autoInit=true)]
		public CameraControlTargetTransition controlTargetTransition;


		// info text
		[ORKEditorHelp("Show Info Text", "An info text will be displayed while selecting a target cell.", "")]
		[ORKEditorInfo("Info Text", "Optionally display an info text box while the player selects a target cell.", "")]
		public bool showInfo = false;

		[ORKEditorInfo(separator=true, endFoldout=true, label=new string[] {
			"%un = user name, %ud = user description, %ui = user icon",
			"%n = cell name, %d = cell description, %i = cell icon",
			"% = move cost (0), %1 = move cost (0.0), %2 = move cost (0.00)"
		})]
		[ORKEditorLayout("showInfo", true, endCheckGroup=true, autoInit=true)]
		public InfoBoxChoice info;


		// own cell selection
		[ORKEditorHelp("Own Cell Selection", "The grid examination uses a different cell selection setup.\n" +
			"If disabled, the cell selection will be used.", "")]
		[ORKEditorInfo("Cell Selection", "The grid examination can optionally override the cell selection settings.", "")]
		public bool ownCellSelection = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownCellSelection", true, endCheckGroup=true, autoInit=true)]
		public GridCellSelectionSettings selection;


		// cell info text
		[ORKEditorHelp("Show Cell Info Text", "An cell info text will be displayed while selecting a target cell.", "")]
		[ORKEditorInfo("Cell Info Text", "Optionally display a cell info text box while the player selects a target cell.", "")]
		public bool showCellInfo = false;

		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("showCellInfo", true, endCheckGroup=true, autoInit=true)]
		public GridCellInfoChoice cellInfo;


		// combatant information
		// move range display
		[ORKEditorHelp("Show Move Range", "Highlight the move range of the examined combatant.", "")]
		[ORKEditorInfo("Combatant Info Dialogue", "Define how the combatant information dialogue " +
			"(displaying bestiary information) will look like.", "",
			labelText="Move Range Display")]
		public bool showMoveRange = false;

		[ORKEditorHelp("Max Move Range (Enemy)", "Show the maximum move range of enemy combatants.\n" +
			"If disabled, the current move range will be shown.", "")]
		[ORKEditorLayout("showMoveRange", true)]
		public bool moveRangeMaxEnemy = true;

		[ORKEditorHelp("Max Move Range (Ally)", "Show the maximum move range of ally combatants.\n" +
			"If disabled, the current move range will be shown.", "")]
		public bool moveRangeMaxAlly = true;

		[ORKEditorHelp("Auto Show Move Range", "The move range is automatically shown when a cell with a combatant is selected.", "")]
		public bool moveRangeAuto = false;

		[ORKEditorHelp("Move Range Input Key", "Select the input key used to show/hide the move range of a cell's combatant.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("moveRangeAuto", false)]
		public int moveRangeKeyID = 0;

		[ORKEditorHelp("Move Range Audio", "Played when the move range is shown/hidden.", "")]
		public AudioClip moveRangeAudio;

		[ORKEditorHelp("Move Range Volume", "The volume (0-1) used to play the move range clip.", "")]
		[ORKEditorLayout("moveRangeAudio", null, elseCheckGroup=true, endCheckGroup=true, endGroups=3)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float moveRangeVolume = 1.0f;


		// attack range display
		[ORKEditorHelp("Show Attack Range", "Highlight the attack range of the examined combatant.\n" +
			"The attack range is the use range of the combatant's base attack.", "")]
		[ORKEditorInfo(separator=true, labelText="Attack Range Display")]
		public bool showAttackRange = false;

		[ORKEditorHelp("Auto Show Attack Range", "The attack range is automatically shown when a cell with a combatant is selected.", "")]
		[ORKEditorLayout("showAttackRange", true)]
		public bool attackRangeAuto = false;

		[ORKEditorHelp("Attack Range Input Key", "Select the input key used to show/hide the attack range of a cell's combatant.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("attackRangeAuto", false)]
		public int attackRangeKeyID = 0;

		[ORKEditorHelp("Attack Range Audio", "Played when the attack range is shown/hidden.", "")]
		public AudioClip attackRangeAudio;

		[ORKEditorHelp("Attack Range Volume", "The volume (0-1) used to play the attack range clip.", "")]
		[ORKEditorLayout("attackRangeAudio", null, elseCheckGroup=true, endCheckGroup=true, endGroups=3)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float attackRangeVolume = 1.0f;


		// combatant info dialogue
		[ORKEditorHelp("Auto Show Info", "Automatically display the combatant information dialogue when a cell with a combatant is selected.\n" +
			"If disabled, the cell must be accepted to show the combatant information dialogue.", "")]
		[ORKEditorInfo(separator=true, labelText="Dialogue Settings")]
		public bool combatantAutoShow = false;

		[ORKEditorInfo(endFoldout=true)]
		public BestiaryChoice combatantInfoDisplay = new BestiaryChoice();


		// in-game
		private GameObject previousCameraControlTarget;

		private Notify notify;


		// selection
		private bool isAlwaysActive = false;

		private bool isExternalCall = false;

		private bool isSelecting = false;

		private bool canSelect = true;

		private BattleGridPathFinder path = new BattleGridPathFinder();

		private List<BattleGridCellComponent> useRangeCells;

		private SelectGridCellBool selectCellFunction;

		private SelectGridCell acceptCellFunction;

		private GridCellCheck acceptCheckFunction;

		public GridExamineSettings()
		{

		}

		public void Clear()
		{
			this.CloseInfoBox();
			this.CloseCellInfoBox();
			this.StopHighlights();
			this.combatantInfoDisplay.Close();

			if(this.isSelecting)
			{
				if(!this.isAlwaysActive &&
					this.blockActionUse &&
					ORK.BattleSystem.gridSettings.SelectingCombatant != null)
				{
					ORK.BattleSystem.gridSettings.SelectingCombatant.Actions.BlockActionUse = false;
				}
				this.isSelecting = false;
			}

			this.isAlwaysActive = false;
			this.isExternalCall = false;
			this.canSelect = true;
			this.notify = null;
			this.previousCameraControlTarget = null;

			this.path.Clear();
			if(this.useRangeCells != null)
			{
				this.useRangeCells.Clear();
			}
		}

		public bool IsAlwaysActiveOn
		{
			get { return this.isAlwaysActive && this.isSelecting; }
		}

		public bool ExamineTarget
		{
			get
			{
				return (!this.alwaysActive || !this.alwaysActiveDuringTargetSelection) &&
					(this.targetExamineCell || this.targetExamineCellCombatant);
			}
		}


		/*
		============================================================================
		GUI box functions
		============================================================================
		*/
		private string InfoReplace(string text)
		{
			float cost = ORK.BattleSystem.gridSettings.SelectedCell.Settings.moveCost.GetValue(
				ORK.BattleSystem.gridSettings.SelectingCombatant,
				ORK.BattleSystem.gridSettings.SelectingCombatant);
			return text.
				Replace("%un", ORK.BattleSystem.gridSettings.SelectingCombatant.GetName()).
				Replace("%ud", ORK.BattleSystem.gridSettings.SelectingCombatant.GetDescription()).
				Replace("%ui", ORK.BattleSystem.gridSettings.SelectingCombatant.GetIconTextCode()).
				Replace("%n", ORK.BattleSystem.gridSettings.SelectedCell.Settings.GetName(
					ORK.BattleSystem.gridSettings.SelectingCombatant)).
				Replace("%d", ORK.BattleSystem.gridSettings.SelectedCell.Settings.GetDescription(
					ORK.BattleSystem.gridSettings.SelectingCombatant)).
				Replace("%i", ORK.BattleSystem.gridSettings.SelectedCell.Settings.GetIconTextCode()).
				Replace("%2", cost.ToString("0.00")).
				Replace("%1", cost.ToString("0.0")).
				Replace("%", cost.ToString("0"));
		}

		private void ShowInfoBox()
		{
			if(this.showInfo)
			{
				this.info.Show(this.info.useTitle ?
					GridCellInfoChoice.CellInfoReplace(this.info.title[ORK.Game.Language],
						ORK.BattleSystem.gridSettings.SelectedCell,
						ORK.BattleSystem.gridSettings.SelectingCombatant) : "",
					GridCellInfoChoice.CellInfoReplace(this.info.infoText[ORK.Game.Language],
						ORK.BattleSystem.gridSettings.SelectedCell,
						ORK.BattleSystem.gridSettings.SelectingCombatant),
					null);
			}
		}

		private void CloseInfoBox()
		{
			if(this.showInfo)
			{
				this.info.Close();
			}
		}

		private void ShowCellInfoBox()
		{
			if(this.showCellInfo)
			{
				this.cellInfo.Show(
					ORK.BattleSystem.gridSettings.SelectingCombatant,
					ORK.BattleSystem.gridSettings.SelectedCell, null);
			}
		}

		private void CloseCellInfoBox()
		{
			if(this.showCellInfo)
			{
				this.cellInfo.Close();
			}
		}


		/*
		============================================================================
		Audio functions
		============================================================================
		*/
		public void PlayMoveRange()
		{
			if(this.moveRangeAudio != null &&
				ORK.Audio != null)
			{
				ORK.Audio.PlayOneShot(this.moveRangeAudio,
					this.moveRangeVolume * ORK.Game.SoundVolume);
			}
		}

		public void PlayAttackRange()
		{
			if(this.attackRangeAudio != null &&
				ORK.Audio != null)
			{
				ORK.Audio.PlayOneShot(this.attackRangeAudio,
					this.attackRangeVolume * ORK.Game.SoundVolume);
			}
		}


		/*
		============================================================================
		Grid examination functions
		============================================================================
		*/
		public void Start(Combatant combatant, BattleGridCellComponent selectedCell, Notify notify)
		{
			ORK.BattleSystem.gridSettings.InitSelection(GridSelectionType.Examine, combatant);
			this.previousCameraControlTarget = ORK.Control.CameraControlTarget;

			this.isAlwaysActive = false;
			this.notify = notify == null && combatant.BattleMenu.IsOpen ?
				combatant.BattleMenu.EndGridExamineClose : notify;
			ORK.BattleSystem.gridSettings.SelectingCombatant.BattleMenu.CloseSilent();

			ORK.BattleSystem.gridSettings.SelectingCombatant.Shortcuts.Active =
				ORK.BattleSystem.gridSettings.SelectingCombatant.Shortcuts.GridExamineShortcut;
			if(this.blockActionUse)
			{
				ORK.BattleSystem.gridSettings.SelectingCombatant.Actions.BlockActionUse = true;
			}

			if(this.selectCellFunction == null)
			{
				this.selectCellFunction = this.SelectCell;
				this.acceptCellFunction = this.AcceptCell;
				this.acceptCheckFunction = this.CheckAcceptCell;
			}

			this.ShowInfoBox();

			this.isSelecting = true;
			ORK.BattleSystem.gridSettings.SelectedCell = null;
			this.SelectCell(selectedCell, true);
		}

		public void StartAlwaysActive(Combatant combatant, BattleGridCellComponent selectedCell)
		{
			ORK.BattleSystem.gridSettings.InitSelection(GridSelectionType.Examine, combatant);
			this.previousCameraControlTarget = ORK.Control.CameraControlTarget;

			this.isAlwaysActive = true;
			this.notify = null;

			if(this.selectCellFunction == null)
			{
				this.selectCellFunction = this.SelectCell;
				this.acceptCellFunction = this.AcceptCell;
				this.acceptCheckFunction = this.CheckAcceptCell;
			}

			this.ShowInfoBox();

			this.isSelecting = true;
			ORK.BattleSystem.gridSettings.SelectedCell = null;
			this.SelectCell(selectedCell, true);
		}

		public void Restart(Combatant combatant)
		{
			if(ORK.BattleSystem.gridSettings.SelectingCombatant == combatant)
			{
				BattleGridCellComponent tmpCell = ORK.BattleSystem.gridSettings.SelectedCell;
				ORK.BattleSystem.gridSettings.SelectedCell = null;
				this.SelectCell(tmpCell, true);
			}
		}

		private void StopHighlights()
		{
			this.StopSelectedCellHighlight();
			if(this.path.availableTargets != null)
			{
				BattleGridHelper.StopHighlight(this.path.availableTargets, GridHighlightType.ExamineMoveRange);
				this.path.Clear();
			}
			if(this.useRangeCells != null)
			{
				BattleGridHelper.StopHighlight(this.useRangeCells, GridHighlightType.ExamineUseRange);
				this.useRangeCells.Clear();
			}
		}

		private void StopSelectedCellHighlight()
		{
			if(ORK.BattleSystem.gridSettings.SelectedCell != null)
			{
				ORK.BattleSystem.gridSettings.SelectedCell.StopHighlight(GridHighlightType.ExamineSelection);
				ORK.BattleSystem.gridSettings.SelectedCell.StopHighlight(GridHighlightType.ExamineSelectionBlocked);
				ORK.BattleSystem.gridSettings.SelectedCell.StopHighlight(GridHighlightType.ExamineSelectionPlayer);
				ORK.BattleSystem.gridSettings.SelectedCell.StopHighlight(GridHighlightType.ExamineSelectionAlly);
				ORK.BattleSystem.gridSettings.SelectedCell.StopHighlight(GridHighlightType.ExamineSelectionEnemy);
			}
		}

		private void ToggleMoveRange()
		{
			if(ORK.BattleSystem.gridSettings.SelectedCell != null &&
				ORK.BattleSystem.gridSettings.SelectedCell.Combatant != null &&
				ORK.BattleSystem.gridHighlights.moveRangeHighlight.enable)
			{
				// hide move range
				if(this.path.availableTargets != null &&
					this.path.availableTargets.Count > 0)
				{
					BattleGridHelper.StopHighlight(this.path.availableTargets, GridHighlightType.ExamineMoveRange);
					this.path.Clear();
				}
				// show move range
				else
				{
					this.path.CreateMoveRange(ORK.BattleSystem.gridSettings.SelectedCell.Combatant,
						ORK.BattleSystem.gridSettings.SelectingCombatant == null ? true :
							(ORK.BattleSystem.gridSettings.SelectingCombatant.IsEnemy(
									ORK.BattleSystem.gridSettings.SelectedCell.Combatant) ?
								this.moveRangeMaxEnemy : this.moveRangeMaxAlly));
					this.path.availableTargets.Remove(ORK.BattleSystem.gridSettings.SelectedCell);
					BattleGridHelper.Highlight(this.path.availableTargets, GridHighlightType.ExamineMoveRange);
				}
			}
		}

		private void ToggleAttackRange()
		{
			if(ORK.BattleSystem.gridSettings.SelectedCell != null &&
				ORK.BattleSystem.gridSettings.SelectedCell.Combatant != null &&
				ORK.BattleSystem.gridHighlights.useRangeHighlight.enable)
			{
				// hide use range
				if(this.useRangeCells != null &&
					this.useRangeCells.Count > 0)
				{
					BattleGridHelper.StopHighlight(this.useRangeCells, GridHighlightType.ExamineUseRange);
					this.useRangeCells.Clear();
				}
				// show use range
				else
				{
					ArrayHelper.GetBlank<BattleGridCellComponent>(ref this.useRangeCells);
					AbilityShortcut ability = ORK.BattleSystem.gridSettings.SelectedCell.
						Combatant.Abilities.GetCurrentBaseAttack();
					if(ability != null)
					{
						ActiveAbility activeAbility = ability.GetActiveLevel();
						if(activeAbility != null)
						{
							activeAbility.targetSettings.GetUseRangeCells(
							   ORK.BattleSystem.gridSettings.SelectedCell.Combatant,
							   ref this.useRangeCells, null);
						}
					}
					this.useRangeCells.Remove(ORK.BattleSystem.gridSettings.SelectedCell);
					BattleGridHelper.Highlight(this.useRangeCells, GridHighlightType.ExamineUseRange);
				}
			}
		}

		private void UseSelectedCell()
		{
			if(ORK.BattleSystem.gridSettings.SelectedCell.Combatant ==
				ORK.BattleSystem.gridSettings.SelectingCombatant)
			{
				this.Close();
			}
			else if(ORK.BattleSystem.gridSettings.SelectedCell.Combatant != null &&
				!this.combatantAutoShow)
			{
				this.combatantInfoDisplay.Show(ORK.BattleSystem.gridSettings.SelectedCell.Combatant,
					true, this.ResumeCellSelection, this.CombatantInfoTick);
			}
		}

		private void ResetCameraControlTarget()
		{
			if(this.cameraControlTarget &&
				this.previousCameraControlTarget != null &&
				(ORK.BattleSystem.gridSettings.SelectedCell == null ||
				ORK.Control.CameraControlTarget == ORK.BattleSystem.gridSettings.SelectedCell.gameObject))
			{
				ORK.Control.SetCameraControlTarget(this.previousCameraControlTarget,
					this.ownControlTargetTransition ? this.controlTargetTransition : null);
			}
			this.previousCameraControlTarget = null;
		}


		/*
		============================================================================
		Cell selection functions
		============================================================================
		*/
		public void Tick()
		{
			if(this.canSelect &&
				this.isSelecting &&
				ORK.BattleSystem.gridSettings.SelectingCombatant != null)
			{
				if(!this.CheckCancel())
				{
					if(ORK.BattleSystem.gridSettings.SelectedCell == null)
					{
						this.SelectCell(ORK.BattleSystem.gridSettings.SelectingCombatant.GridCell, true);
					}
					if(this.ownCellSelection)
					{
						this.selection.SelectCell(
							ORK.BattleSystem.gridSettings.SelectingCombatant.GridCell,
							ORK.BattleSystem.gridSettings.SelectedCell,
							this.selectCellFunction, this.acceptCellFunction, this.acceptCheckFunction, null, false);
					}
					else
					{
						ORK.BattleSystem.gridSettings.cellSelection.SelectCell(
							ORK.BattleSystem.gridSettings.SelectingCombatant.GridCell,
							ORK.BattleSystem.gridSettings.SelectedCell,
							this.selectCellFunction, this.acceptCellFunction, this.acceptCheckFunction, null, false);
					}
					if(ORK.BattleSystem.gridSettings.SelectedCell != null &&
						ORK.BattleSystem.gridSettings.SelectedCell.Combatant != null)
					{
						// move range display
						if(this.showMoveRange &&
							!this.moveRangeAuto &&
							ORK.InputKeys.Get(this.moveRangeKeyID).GetButton())
						{
							ORK.InputKeys.ResetInputAxes();
							this.PlayMoveRange();
							this.ToggleMoveRange();
						}
						// use range display
						if(this.showAttackRange &&
							!this.attackRangeAuto &&
							ORK.InputKeys.Get(this.attackRangeKeyID).GetButton())
						{
							ORK.InputKeys.ResetInputAxes();
							this.PlayAttackRange();
							this.ToggleAttackRange();
						}
					}
				}
			}
		}

		private bool CombatantInfoTick()
		{
			if(!this.isExternalCall)
			{
				// cancel
				if(this.combatantAutoShow &&
					this.CheckCancel())
				{
					return true;
				}
				// move range display
				else if(this.showMoveRange &&
					!this.moveRangeAuto &&
					ORK.BattleSystem.gridSettings.SelectedCell != null &&
					ORK.BattleSystem.gridSettings.SelectedCell.Combatant != null &&
					ORK.InputKeys.Get(this.moveRangeKeyID).GetButton())
				{
					ORK.InputKeys.ResetInputAxes();
					this.PlayMoveRange();
					this.ToggleMoveRange();
					return true;
				}
				// use range display
				else if(this.showAttackRange &&
					!this.attackRangeAuto &&
					ORK.BattleSystem.gridSettings.SelectedCell != null &&
					ORK.BattleSystem.gridSettings.SelectedCell.Combatant != null &&
					ORK.InputKeys.Get(this.attackRangeKeyID).GetButton())
				{
					ORK.InputKeys.ResetInputAxes();
					this.PlayAttackRange();
					this.ToggleAttackRange();
				}
			}
			return false;
		}

		private bool CheckCancel()
		{
			if(this.allowCancel &&
				!this.isExternalCall &&
				!this.isAlwaysActive &&
				ORK.InputKeys.Get(ORK.GameControls.menuControls.cancelKeyID).GetButton())
			{
				if(this.ownCellSelection)
				{
					this.selection.PlayCancelAudio();
				}
				else
				{
					ORK.BattleSystem.gridSettings.cellSelection.PlayCancelAudio();
				}
				this.Close();
				return true;
			}
			return false;
		}

		public void Close()
		{
			this.canSelect = false;
			this.isSelecting = false;
			if(!this.isAlwaysActive &&
				this.blockActionUse)
			{
				ORK.BattleSystem.gridSettings.SelectingCombatant.Actions.BlockActionUse = false;
			}
			this.ResetCameraControlTarget();

			this.StopHighlights();
			ORK.InputKeys.ResetInputAxes();
			this.CloseInfoBox();
			this.CloseCellInfoBox();
			this.combatantInfoDisplay.Close();
			if(ORK.BattleSystem.gridSettings.SelectingCombatant.Shortcuts.Active is GridExamineShortcut)
			{
				ORK.BattleSystem.gridSettings.SelectingCombatant.Shortcuts.Active = null;
			}
			ORK.BattleSystem.gridSettings.ClearCellSelection();

			if(this.notify != null)
			{
				this.notify();
			}
			this.Clear();
		}

		public void SelectCell(BattleGridCellComponent cell, bool isHover)
		{
			if(ORK.BattleSystem.gridSettings.SelectedCell != cell)
			{
				// stop move range highlight
				if(ORK.BattleSystem.gridHighlights.moveRangeHighlight.enable &&
					this.path.availableTargets != null)
				{
					BattleGridHelper.StopHighlight(this.path.availableTargets, GridHighlightType.ExamineMoveRange);
					this.path.Clear();
				}
				// stop use range highlight
				if(ORK.BattleSystem.gridHighlights.useRangeHighlight.enable &&
					this.useRangeCells != null)
				{
					BattleGridHelper.StopHighlight(this.useRangeCells, GridHighlightType.ExamineUseRange);
					this.useRangeCells.Clear();
				}
				// stop selection highlight
				this.StopSelectedCellHighlight();

				ORK.BattleSystem.gridSettings.SelectedCell = cell;

				// new highlights
				if(ORK.BattleSystem.gridSettings.SelectedCell != null)
				{
					if(this.cameraControlTarget && !isHover)
					{
						ORK.Control.SetCameraControlTarget(ORK.BattleSystem.gridSettings.SelectedCell.gameObject,
							this.ownControlTargetTransition ? this.controlTargetTransition : null);
					}
					if(ORK.BattleSystem.gridSettings.SelectedCell.Combatant != null)
					{
						if(this.combatantAutoShow)
						{
							this.combatantInfoDisplay.Show(
								ORK.BattleSystem.gridSettings.SelectedCell.Combatant,
								false, null, this.CombatantInfoTick);
						}
						if(this.showMoveRange &&
							this.moveRangeAuto)
						{
							this.ToggleMoveRange();
						}
						if(this.showAttackRange &&
							this.attackRangeAuto)
						{
							this.ToggleAttackRange();
						}
					}
					else
					{
						this.combatantInfoDisplay.Close();
					}
					if(ORK.BattleSystem.gridSettings.SelectedCell.IsBlocked ||
						(ORK.BattleSystem.gridHighlights.examineCombatantIsBlocked &&
							!ORK.BattleSystem.gridSettings.SelectedCell.IsEmpty))
					{
						if(ORK.BattleSystem.gridHighlights.examineBlockedHighlight.enable)
						{
							ORK.BattleSystem.gridSettings.SelectedCell.Highlight(
								ORK.BattleSystem.gridHighlights.GetSelectionHighlight(
									GridHighlightType.ExamineSelectionBlocked, ORK.BattleSystem.gridSettings.SelectedCell));
						}
					}
					else if(ORK.BattleSystem.gridHighlights.examineHighlight.enable)
					{
						ORK.BattleSystem.gridSettings.SelectedCell.Highlight(
							ORK.BattleSystem.gridHighlights.GetSelectionHighlight(
								GridHighlightType.ExamineSelection, ORK.BattleSystem.gridSettings.SelectedCell));
					}
					this.ShowCellInfoBox();
				}
				else
				{
					this.ResetCameraControlTarget();
					this.combatantInfoDisplay.Close();
					this.CloseCellInfoBox();
				}
				this.ShowInfoBox();
			}
		}

		public void ExternalExamine(BattleGridCellComponent cell, bool showCellInfo, bool showCombatantInfo)
		{
			if(this.isAlwaysActive)
			{
				this.isAlwaysActive = false;
				this.Close();
			}
			if(cell != null)
			{
				this.isExternalCall = true;
				if(cell.Combatant != null &&
					showCombatantInfo)
				{
					this.combatantInfoDisplay.Show(
						cell.Combatant,
						false, null, this.CombatantInfoTick);
				}
				else
				{
					this.combatantInfoDisplay.Close();
				}
				if(showCellInfo)
				{
					this.ShowCellInfoBox();
				}
				else
				{
					this.CloseCellInfoBox();
				}
			}
			else
			{
				this.isExternalCall = false;
				this.combatantInfoDisplay.Close();
				this.CloseCellInfoBox();
			}
		}

		public void AcceptCell(BattleGridCellComponent cell)
		{
			if(this.CheckAcceptCell(cell))
			{
				if(!this.combatantAutoShow)
				{
					this.CloseInfoBox();
					this.CloseCellInfoBox();
					this.canSelect = false;
				}

				if(ORK.BattleSystem.gridSettings.SelectedCell != cell)
				{
					this.SelectCell(cell, true);
				}
				this.UseSelectedCell();
			}
			else
			{
				this.SelectCell(cell, true);
			}
		}

		public void ResumeCellSelection()
		{
			this.ShowInfoBox();
			this.canSelect = true;
		}

		public bool CheckAcceptCell(BattleGridCellComponent cell)
		{
			return cell != null && cell.Combatant != null &&
				((!this.isAlwaysActive &&
					cell.Combatant == ORK.BattleSystem.gridSettings.SelectingCombatant) ||
				!this.combatantAutoShow);
		}
	}
}
