
using ORKFramework;
using ORKFramework.Behaviours;
using ORKFramework.Events.Steps;
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Events
{
	public class BattleEvent : BaseEvent
	{
		// move AI blocks
		[ORKEditorHelp("Block Move AI", "The move AI is blocked while this event is performed.\n" +
			"The move AI will be blocked at the start of the event and unblocked at the end.", "")]
		[ORKEditorInfo("Event Settings", "Base settings of this battle event.", "")]
		public bool blockMoveAI = false;

		[ORKEditorHelp("Block Actor Move AI", "The move AI of all event actors is blocked while this event is performed.\n" +
			"The move AI of all actors will be blocked at the start of the event and unblocked at the end.", "")]
		[ORKEditorLayout("blockMoveAI", false, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool blockActorMoveAI = false;

		[ORKEditorHelp("Block Control Maps", "The control maps are blocked while this event is performed.\n" +
			"The control maps will be blocked at the start of the event and unblocked at the end.", "")]
		public bool blockControlMaps = false;

		[ORKEditorHelp("Clear Found Objects", "Remove all found objects when starting this event.", "")]
		public bool clearFoundObjects = false;


		// other settings
		[ORKEditorHelp("Reset Camera", "The camera's position, rotation and field of view will be " +
			"reset to the values they had at the start of the battle event.", "")]
		[ORKEditorInfo(separator=true)]
		public bool resetCam = false;

		[ORKEditorHelp("Reset Look Angles", "All combatant's will look at the center of " +
			"the opposite group at the end of the battle event.", "")]
		public bool resetLook = false;

		[ORKEditorHelp("Calculation Needed", "If no calculation step was performed in the event, " +
			"the calculation of the battle action outcome is forced at the end of the battle event.\n" +
			"Disable this option when using DamageDealer and DamageZone components to calculate the outcome.\n" +
			"Calculation is needed to e.g. determine the damage of an attack.", "")]
		public bool calcNeeded = false;

		[ORKEditorHelp("Clear Block Steps", "All 'block player/camera control' steps will be cleared at the end of the event, " +
			"i.e. each 'block' without an 'unblock' will be unblocked at the end of the event.\n" +
			"E.g.: the player control is blocked 2 times, but only unblocked 1 time - so 1 block is still remaining and will be removed.", "")]
		public bool clearBlocks = false;

		[ORKEditorHelp("Auto Damage Dealers", "Damage dealers on the user's game object " +
			"will be automatically activated at the start of this event and deactivated at the end.\n" +
			"Keep in mind that only those damage dealers can be automatically activated, which " +
			"have 'Auto Activate' enabled for the currently used battle system type (or field) and " +
			"either are set up for the used ability/item, or have at least one tag matching " +
			"the tags defined in the ability's or item's settings.", "")]
		public bool autoDamageDealers = true;


		// camera settings
		[ORKEditorHelp("Use Main Camera", "The event uses the main camera.\n" +
			"If disabled, you can specify another camera to be used.", "")]
		[ORKEditorInfo(separator=true, labelText="Camera Settings")]
		public bool mainCamera = true;

		[ORKEditorHelp("Find With Tag", "The camera is searched using it's tag instead of name.", "")]
		[ORKEditorLayout("mainCamera", false)]
		public bool cameraTag = false;

		[ORKEditorHelp("Camera Name", "The name (or tag) of the camera that will be used by this event.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public string cameraName = "";

		[ORKEditorHelp("Ignore Camera Block", "Ignores the battle camera settings (found in 'Battle Settings') " +
			"and allows camera changes in this event.\n" +
			"If disabled and the battle camera blocks the event cameras, all camera steps are ignored.", "")]
		[ORKEditorInfo(separator=true)]
		public bool ignoreCamBlock = false;

		[ORKEditorHelp("Chance (%)", "The chance the battle event's camera changes wont be blocked.\n" +
			"The battle event will perform camera changes if a random float number between two values " +
			"(default 0 and 100, you can change this in the game settings) " +
			"is less or equal to chance defined here.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ignoreCamBlock", true, endCheckGroup=true)]
		public float noBlockChance = 100;


		// prefabs
		[ORKEditorHelp("Destroy Prefabs", "All spawned prefabs will be destroyed at the end of the event.", "")]
		[ORKEditorInfo("Prefabs", "Events can spawn prefabs in the scene.", "")]
		public bool destroyPrefabs = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Prefab", "Adds a prefab to this event.", "",
			"Remove", "Removes this prefab from the event.", "", isCopy=true,
			foldout=true, foldoutText=new string[] {"Prefab", "Prefabs can be spawned in the scene by the event.", ""})]
		public EventPrefab[] prefab = new EventPrefab[0];


		// audio
		[ORKEditorInfo("Audio Clips", "Events can play audio clips in the scene.", "",
			endFoldout=true)]
		[ORKEditorArray(false, "Add Audio Clip", "Adds an audio clip to this event.", "",
			"Remove", "Removes this audio clip from the event.", "", isCopy=true,
			foldout=true, foldoutText=new string[] {"Audio Clip", "Audio clips can be played by the event.", ""})]
		public EventAudio[] audioClip = new EventAudio[0];


		/*
		============================================================================
		Ingame variables
		============================================================================
		*/
		private BaseAction battleAction;


		// camera
		private bool camBlocked = false;

		private bool resetBlock = false;

		public BattleEvent()
		{

		}

		public BaseAction Action
		{
			get { return this.battleAction; }
		}

		public void SetPrefabs(EventPrefab[] newPrefabs)
		{
			for(int i = 0; i < this.prefab.Length; i++)
			{
				if(i < newPrefabs.Length)
				{
					this.prefab[i].prefab = newPrefabs[i].prefab;
				}
			}
		}

		public void SetAudioClips(EventAudio[] newAudioClip)
		{
			for(int i = 0; i < this.audioClip.Length; i++)
			{
				if(i < newAudioClip.Length)
				{
					this.audioClip[i] = newAudioClip[i];
				}
			}
		}


		/*
		============================================================================
		Start/End functions
		============================================================================
		*/
		public override void StartEvent(IEventStarter s, object startingObject)
		{
			if(this.step.Length > 0 && !this.executing)
			{
				this.starter = s;

				for(int i = 0; i < this.prefab.Length; i++)
				{
					this.prefab[i].Clear();
				}

				if(this.starter is BaseAction)
				{
					this.battleAction = this.starter as BaseAction;
				}
				else if(this.starter is BattleEvent)
				{
					this.battleAction = ((BattleEvent)this.starter).Action;
				}

				// block move AI
				if(this.blockMoveAI)
				{
					ORK.Control.SetBlockMoveAI(1);
				}
				else if(this.blockActorMoveAI)
				{
					for(int i = 0; i < 3; i++)
					{
						List<GameObject> list = this.GetActorObject(i);
						for(int j = 0; j < list.Count; j++)
						{
							if(list[j] != null)
							{
								MoveAIComponent comp = list[j].GetComponentInChildren<MoveAIComponent>();
								if(comp != null)
								{
									comp.blocked = true;
								}
							}
						}
					}
				}

				// block control maps
				if(this.blockControlMaps)
				{
					ORK.Control.SetBlockControlMaps(1);
				}

				// camera blocking
				this.camBlocked = false;
				if(ORK.BattleSettings.camera.IsBlockEvents)
				{
					this.camBlocked = true;
					if(this.ignoreCamBlock && ORK.GameSettings.CheckRandom(this.noBlockChance))
					{
						this.camBlocked = false;
					}
				}
				if(!this.camBlocked)
				{
					ORK.BattleSettings.camera.BlockedByAnimation(true);
					this.resetBlock = true;
				}

				if(this.autoDamageDealers)
				{
					this.battleAction.AutoActivateUserDamageDealers(true);
				}

				if(this.clearFoundObjects)
				{
					this.foundObjects.Clear();
				}

				this.StartEvent();
			}
			else if(ComponentHelper.IsAlive(s))
			{
				s.EventEnded();
			}
		}

		public override void StopEvent()
		{
			if(!(this.battleAction is DeathAction))
			{
				this.calcNeeded = false;
				this.stopFlag = true;
			}
		}

		protected override void EndEvent()
		{
			if(this.continueSteps.Count == 0)
			{
				this.executing = false;
				this.timeRunning = false;

				if(this.autoDamageDealers)
				{
					this.battleAction.AutoActivateUserDamageDealers(false);
				}

				// calculate if it hasn't been done yet
				if(this.calcNeeded && this.battleAction.target != null)
				{
					if(this.battleAction.HasTargets())
					{
						this.battleAction.Calculate(this.battleAction.target, 1, true);
					}
				}

				// block move AI
				if(this.blockMoveAI)
				{
					ORK.Control.SetBlockMoveAI(-1);
				}
				else if(this.blockActorMoveAI)
				{
					for(int i = 0; i < 3; i++)
					{
						List<GameObject> list = this.GetActorObject(i);
						for(int j = 0; j < list.Count; j++)
						{
							if(list[j] != null)
							{
								MoveAIComponent comp = list[j].GetComponentInChildren<MoveAIComponent>();
								if(comp != null)
								{
									comp.blocked = false;
								}
							}
						}
					}
				}

				// block control maps
				if(this.blockControlMaps)
				{
					ORK.Control.SetBlockControlMaps(-1);
				}

				// clear block steps
				if(this.clearBlocks)
				{
					if(this.playerBlocks > 0)
					{
						ORK.Control.SetBlockPlayer(-this.playerBlocks, true);
					}
					if(this.cameraBlocks > 0)
					{
						ORK.Control.SetBlockCamera(-this.cameraBlocks, true);
					}
				}
				// reset camera
				if(this.resetCam && this.camera != null && !this.camBlocked)
				{
					this.ResetCameraPosition();
				}
				// reset camera block
				if(this.resetBlock)
				{
					ORK.BattleSettings.camera.BlockedByAnimation(false);
				}
				// reset looks
				if(this.resetLook)
				{
					ORK.Battle.SetLooks(this.battleAction.User);
				}
				// destroy prefabs
				if(this.destroyPrefabs)
				{
					for(int i = 0; i < this.prefab.Length; i++)
					{
						this.prefab[i].DestroyPrefab(-1, -1);
					}
				}

				if(ComponentHelper.IsAlive(this.starter))
				{
					this.starter.EventEnded();
				}

				if(this.gameOver)
				{
					ORK.Game.GameOver();
				}
				else if(this.exitGame)
				{
					ORK.Game.LoadMainMenuScene();
				}

				this.calledEvent = null;
				this.battleAction = null;
				this.starter = null;
			}
			else
			{
				this.endAfterContinue = true;
			}
		}


		/*
		============================================================================
		Step functions
		============================================================================
		*/
		public override void ExecuteNextStep()
		{
			if(this.executing)
			{
				this.stepFinished = false;
				if(this.currentStep >= 0 && this.currentStep < this.step.Length)
				{
					if(!(this.battleAction is DeathAction) &&
						this.battleAction.User.Dead)
					{
						this.calcNeeded = false;
						this.stopFlag = true;
					}

					if(this.step[this.currentStep].IsEnabled &&
						(this.battleAction is DeathAction || !this.stopFlag ||
						this.step[this.currentStep].ExecuteOnStop))
					{
						this.step[this.currentStep].Execute(this);
					}
					else
					{
						this.ExecuteNextStepStop();
					}
				}
				else
				{
					this.EndEvent();
				}
			}
		}


		/*
		============================================================================
		Actor functions
		============================================================================
		*/
		public override string GetActorName(int index)
		{
			List<Combatant> list = this.GetActorCombatant(index);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					return list[i].GetName();
				}
			}
			return "";
		}

		public override Portrait GetActorPortrait(int index, int typeID)
		{
			List<Combatant> list = this.GetActorCombatant(index);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					Portrait portrait = list[i].GetPortrait(typeID);
					if(portrait != null)
					{
						return portrait;
					}
				}
			}
			return null;
		}

		public override List<GameObject> GetActorObject(int index)
		{
			List<GameObject> list = new List<GameObject>();
			// user
			if(index == 0)
			{
				list.Add(this.battleAction.User.GameObject);
			}
			// target
			else if(index == 1)
			{
				if(this.battleAction.rayTargetSet)
				{
					if(this.battleAction.rayObject == null)
					{
						this.battleAction.rayObjectCreated = true;
						this.battleAction.rayObject = new GameObject("_TargetPosition");
						this.battleAction.rayObject.transform.position = this.battleAction.rayPoint;
					}
					list.Add(this.battleAction.rayObject);
				}
				if(this.battleAction.target != null &&
					this.battleAction.target.Count > 0)
				{
					for(int i = 0; i < this.battleAction.target.Count; i++)
					{
						if(this.battleAction.target[i] != null &&
							this.battleAction.target[i].GameObject != null)
						{
							list.Add(this.battleAction.target[i].GameObject);
						}
					}
				}
			}
			// camera
			else if(index == 2)
			{
				if(this.camera != null)
				{
					list.Add(this.camera.gameObject);
				}
			}
			// user group, target groups, all allies, all enemies, all combatants
			else if(index >= 3 && index <= 7)
			{
				List<Combatant> tmp = this.GetActorCombatant(index);
				for(int i = 0; i < tmp.Count; i++)
				{
					if(tmp[i] != null && tmp[i].GameObject != null)
					{
						list.Add(tmp[i].GameObject);
					}
				}
			}
			return list;
		}

		public override List<Combatant> GetActorCombatant(int index)
		{
			List<Combatant> list = new List<Combatant>();
			// user
			if(index == 0)
			{
				list.Add(this.battleAction.User);
			}
			// target
			else if(index == 1)
			{
				list.AddRange(this.battleAction.target);
			}
			// user group
			else if(index == 3)
			{
				list.AddRange(this.battleAction.User.Group.GetBattle());
			}
			// target groups
			else if(index == 4)
			{
				for(int i = 0; i < this.battleAction.target.Count; i++)
				{
					List<Combatant> tmp = this.battleAction.target[i].Group.GetBattle();
					for(int j = 0; j < tmp.Count; j++)
					{
						if(!list.Contains(tmp[j]))
						{
							list.Add(tmp[j]);
						}
					}
				}
			}
			// all allies
			else if(index == 5)
			{
				list.AddRange(ORK.Game.Combatants.Get(this.battleAction.User, true,
					Range.Battle, Consider.No, Consider.Ignore, Consider.Yes));
			}
			// all enemies
			else if(index == 6)
			{
				list.AddRange(ORK.Game.Combatants.Get(this.battleAction.User, false,
					Range.Battle, Consider.Yes, Consider.Ignore, Consider.Yes));
			}
			// all combatants
			else if(index == 7)
			{
				list.AddRange(ORK.Game.Combatants.Get(this.battleAction.User, true,
					Range.Battle, Consider.Ignore, Consider.Ignore, Consider.Yes));
			}
			return list;
		}


		/*
		============================================================================
		Waypoint functions
		============================================================================
		*/
		public override List<GameObject> GetWaypoint(int index)
		{
			List<GameObject> list = new List<GameObject>();
			if(index == 0)
			{
				list.Add(this.battleAction.User.BattleSpot);
			}
			else if(index == 1)
			{
				list.Add(ORK.Battle.GetGroupCenter(this.battleAction.target));
			}
			else if(index == 2)
			{
				list.Add(ORK.Battle.GetArenaCenter());
			}
			else if(index == 3)
			{
				if(this.battleAction.target != null)
				{
					for(int i = 0; i < this.battleAction.target.Count; i++)
					{
						if(this.battleAction.target[i].BattleSpot != null)
						{
							list.Add(this.battleAction.target[i].BattleSpot);
						}
					}
				}
			}
			else if(index == 4)
			{
				list.Add(ORK.Battle.GetGroupBaseCenter(this.battleAction.target));
			}
			return list;
		}


		/*
		============================================================================
		Prefab functions
		============================================================================
		*/
		public override GameObject SpawnPrefab(int index, Vector3 position, Vector3 rotation)
		{
			if(index >= 0 && index < this.prefab.Length)
			{
				return this.prefab[index].SpawnPrefab(position, rotation);
			}
			return null;
		}

		public override void DestroyPrefab(int index, int spawnID, float time)
		{
			if(index >= 0 && index < this.prefab.Length)
			{
				this.prefab[index].DestroyPrefab(spawnID, time);
			}
		}

		public override List<GameObject> GetSpawnedPrefab(int index, int spawnID)
		{
			if(index >= 0 && index < this.prefab.Length)
			{
				return this.prefab[index].GetSpawnedPrefab(spawnID);
			}
			return new List<GameObject>();
		}

		public GameObject GetPrefab(int index)
		{
			if(index >= 0 && index < this.prefab.Length)
			{
				return this.prefab[index].GetPrefab();
			}
			return null;
		}


		/*
		============================================================================
		Audio functions
		============================================================================
		*/
		public override AudioClip GetAudioClip(int index)
		{
			if(index >= 0 && index < this.audioClip.Length)
			{
				return this.audioClip[index].GetClip();
			}
			return null;
		}


		/*
		============================================================================
		Camera functions
		============================================================================
		*/
		public override Transform GetCamera()
		{
			if(this.camera == null)
			{
				if(this.mainCamera)
				{
					Camera c = Camera.main;
					if(c != null)
					{
						this.camera = c.transform;
					}
				}
				else
				{
					Camera[] cams = Camera.allCameras;
					for(int i = 0; i < cams.Length; i++)
					{
						if((this.cameraTag && cams[i].tag == this.cameraName) ||
							(!this.cameraTag && cams[i].name == this.cameraName))
						{
							this.camera = cams[i].transform;
							break;
						}
					}
				}
			}
			return this.camera;
		}

		public override bool PerformCamera
		{
			get
			{
				return !this.camBlocked &&
					(ORK.Battle.Actions.IsLatestActive(this.battleAction) ||
					!ORK.Battle.IsDynamicCombat());
			}
		}
	}
}

