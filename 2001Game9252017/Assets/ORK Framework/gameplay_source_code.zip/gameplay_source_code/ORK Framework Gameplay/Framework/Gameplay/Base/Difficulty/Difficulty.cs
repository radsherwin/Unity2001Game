
using ORKFramework;
using UnityEngine;

namespace ORKFramework
{
	public class Difficulty : BaseLanguageData, IContentSimple
	{
		[ORKEditorHelp("Time Factor", "Used for changing standard game speed (e.g. game events).", "")]
		[ORKEditorInfo("Time Factor Settings", "The different time factors are used " +
			"to change the time behaviour of different parts of the game. E.g.:\n" +
			"- A factor of 1 represents normal time flow.\n" +
			"- A factor of 2 will double the time speed resulting in things happening twice as fast.\n" +
			"- A factor of 0.5 will halve the time speed resulting in things happening halve as fast.", "")]
		public float timeFactor = 1;
		
		[ORKEditorHelp("Movement Factor", "Used for changing the speed of movements (e.g. player controls, enemy movements, etc.).", "")]
		public float movementFactor = 1;
		
		[ORKEditorHelp("Battle Factor", "Used for changing the speed of battles and battle related things (e.g. status effects).", "")]
		public float battleFactor = 1;
		
		[ORKEditorHelp("Animation Factor", "Used for changing animation speed.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public float animationFactor = 1;
		
		
		// factions
		[ORKEditorInfo("Faction Settings", "The different multiplier settings are used " +
			"to multiply the initial status values, attack and defence attributes of all members of a selected faction.\n" +
			"E.g.:\n" +
			"- A multiplier of 1 represents the default values.\n" +
			"- A multiplier of 2 represents doubled values, e.g. if settings the MaxHP multiplier " +
			"to 2 will result in combatants having twice the HP as normally.\n" +
			"- A multiplier of 0.5 represents half values, e.g. if setting the EXP multiplier " +
			"to 0.5 will result in combatants giving half the EXP as normally.\n", "", endFoldout=true)]
		[ORKEditorArray(false, "Add Faction Multipliers", "Add a faction bonus setting.\n" +
			"All members of the selected faction will have their initial values multiplied by the defined values.", "", 
			"Remove", "Removes this faction bonus.", "", isCopy=true, isMove=true, 
			foldout=true, foldoutText=new string[] {
				"Faction Multipliers", 
				"All members of the selected faction will have their initial values multiplied by the defined values.", ""
		})]
		public DifficultyFaction[] faction = new DifficultyFaction[0];
	
		
		public Difficulty()
		{
			
		}
		
		public Difficulty(string name) : base(name)
		{
			
		}
		
		
		/*
		============================================================================
		Faction functions
		============================================================================
		*/
		public DifficultyFaction GetMultipliers(int factionID)
		{
			for(int i=0; i<this.faction.Length; i++)
			{
				if(this.faction[i].factionID == factionID)
				{
					return this.faction[i];
				}
			}
			return null;
		}
		
		
		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public int ID
		{
			get{ return this.realID;}
		}

		public string GetName()
		{
			return this.languageInfo[ORK.Game.Language].GetName();
		}

		public string GetDescription()
		{
			return this.languageInfo[ORK.Game.Language].GetDescription();
		}
		
		public string GetIconTextCode()
		{
			return TextCode.DifficultyIcon + this.realID + "#";
		}

		public Texture GetIcon()
		{
			return this.languageInfo[ORK.Game.Language].GetIcon();
		}

		public GUIContent GetContent()
		{
			return this.languageInfo[ORK.Game.Language].GetContent();
		}
	}
}
