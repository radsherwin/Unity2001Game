
using UnityEngine;
using ORKFramework.UI;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ActionSelection : BaseData
	{
		[ORKEditorHelp("Action Type", "Select the action type the combatant will perform:\n" +
			"- Attack: Performs a base attack.\n" +
			"- Counter Attack: Performs a counter attack. Counter attacks can't be countered.\n" +
			"- Ability: Uses an ability.\n" +
			"- Item: Uses an item.\n" +
			"- Defend: Uses the defend command.\n" +
			"- Escape: Uses the escape command.\n" +
			"- Death: The combatant dies.\n" +
			"- None: Does nothing.\n" +
			"- Change Member: The combatant is exchanged with a non-battle group member.\n" +
			"- Class Ability: Performs the combatant's class ability.\n" +
			"- Shortcut: Uses a shortcut slot of the combatant.", "")]
		public ActionSelectType type = ActionSelectType.Attack;


		// attack
		[ORKEditorHelp("Reset Index", "The attack index will be reset to 0 after the attack is used.\n" +
			"This only happens if the attack is used.", "")]
		[ORKEditorLayout("type", ActionSelectType.Attack)]
		public bool resetAttackIndex = false;

		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public BaseAttackSelection attack;


		// ability
		[ORKEditorHelp("Ability", "Select the ability the combatant will use.\n" +
			"If the combatant doesn't have the ability, the ability wont be used.", "")]
		[ORKEditorInfo(ORKDataType.Ability)]
		[ORKEditorLayout("type", ActionSelectType.Ability, endCheckGroup=true)]
		public int abilityID = 0;


		// item
		[ORKEditorHelp("Item", "Select the item the combatant will use.\n" +
			"If the combatant doesn't have the item in his inventory, the item wont be used.", "")]
		[ORKEditorInfo(ORKDataType.Item)]
		[ORKEditorLayout("type", ActionSelectType.Item, endCheckGroup=true)]
		public int itemID = 0;


		// member index
		[ORKEditorHelp("Member Index", "The index of the non-battle member the combatant will be exchanged with.", "")]
		[ORKEditorLimit(0, false)]
		[ORKEditorLayout("type", ActionSelectType.ChangeMember, endCheckGroup=true)]
		public int memberIndex = 0;


		// shortcut
		[ORKEditorLayout("type", ActionSelectType.Shortcut, endCheckGroup=true, autoInit=true)]
		public ShortcutSlot slot;

		public ActionSelection()
		{

		}


		/*
		============================================================================
		Action functions
		============================================================================
		*/
		public BaseAction GetAction(Combatant combatant, bool checkTime, bool checkUseCosts)
		{
			BaseAction action = null;
			this.GetAction(out action, combatant, checkTime, checkUseCosts, true, false, false);
			return action;
		}

		public bool GetAction(out BaseAction action, Combatant combatant, bool checkTime, bool checkUseCosts,
			bool useAutoTarget, bool autoTargetOnly, bool needTargets)
		{
			action = null;

			if(ActionSelectType.Attack == this.type)
			{
				if(!combatant.Status.BlockAttack)
				{
					AbilityShortcut ability = this.attack.GetAttack(combatant);

					if(ability != null &&
						ActionSelection.UseAbility(
							combatant, ability, checkTime, checkUseCosts,
							useAutoTarget, autoTargetOnly, needTargets, out action))
					{
						if(this.resetAttackIndex)
						{
							combatant.Abilities.ResetBaseAttack();
						}
						return true;
					}
				}
			}
			// counter
			else if(ActionSelectType.CounterAttack == this.type)
			{
				if(!combatant.Status.BlockAttack)
				{
					AbilityShortcut ability = combatant.Abilities.GetCounterAttack();

					if(ability != null &&
						ActionSelection.UseAbility(
							combatant, ability, checkTime, checkUseCosts,
							useAutoTarget, autoTargetOnly, needTargets, out action))
					{
						return true;
					}
				}
			}
			// ability
			else if(ActionSelectType.Ability == this.type)
			{
				if(!combatant.Status.BlockAbilities)
				{
					AbilityShortcut ability = combatant.Abilities.Get(this.abilityID);

					if(ability != null)
					{
						ability.SetHighestUseLevel(combatant);

						if(ActionSelection.UseAbility(
							combatant, ability, checkTime, checkUseCosts,
							useAutoTarget, autoTargetOnly, needTargets, out action))
						{
							return true;
						}
					}
				}
			}
			// class ability
			else if(ActionSelectType.ClassAbility == this.type)
			{
				if(!combatant.Status.BlockAbilities)
				{
					AbilityShortcut ability = combatant.Abilities.GetClassAbility();

					if(ability != null &&
						ActionSelection.UseAbility(
							combatant, ability, checkTime, checkUseCosts,
							useAutoTarget, autoTargetOnly, needTargets, out action))
					{
						return true;
					}
				}
			}
			// item
			else if(ActionSelectType.Item == this.type)
			{
				if(!combatant.Status.BlockItems)
				{
					ItemShortcut item = combatant.Inventory.GetItem(this.itemID);

					if(item != null &&
						ActionSelection.UseItem(
							combatant, item, checkTime, checkUseCosts,
							useAutoTarget, autoTargetOnly, needTargets, out action))
					{
						return true;
					}
				}
			}
			// defend
			else if(ActionSelectType.Defend == this.type)
			{
				if(!combatant.Status.BlockDefend)
				{
					action = new DefendAction(combatant);
					return true;
				}
			}
			// escape
			else if(ActionSelectType.Escape == this.type)
			{
				if(!combatant.Status.BlockEscape)
				{
					action = new EscapeAction(combatant);
					return true;
				}
			}
			// death
			else if(ActionSelectType.Death == this.type)
			{
				action = new DeathAction(combatant, false);
				return true;
			}
			// none
			else if(ActionSelectType.None == this.type)
			{
				action = new NoneAction(combatant);
				return true;
			}
			// change member
			else if(ActionSelectType.ChangeMember == this.type)
			{
				Combatant target = combatant.Group.NonBattleMemberAt(this.memberIndex);
				if(target != null)
				{
					action = new ChangeMemberAction(combatant, target);
					return true;
				}
			}
			// shortcut
			else if(ActionSelectType.Shortcut == this.type)
			{
				Combatant owner = null;
				IShortcut shortcut = this.slot.GetShortcut(combatant, out owner);
				if(shortcut != null)
				{
					// disable active shortcut on 2nd call
					if(ORK.ShortcutSettings.deactivateOn2ndCall &&
						combatant.Shortcuts.Active == shortcut)
					{
						combatant.Shortcuts.DisableActive();
						return true;
					}

					// equip, special actions
					if(shortcut is EquipShortcut ||
						shortcut is DefendShortcut ||
						shortcut is EscapeShortcut ||
						shortcut is NoneShortcut ||
						shortcut is GridMoveShortcut ||
						shortcut is GridOrientationShortcut ||
						shortcut is GridExamineShortcut)
					{
						List<Combatant> list = new List<Combatant>();
						list.Add(combatant);
						return shortcut.Use(owner, list, true);
					}
					// item
					else if(shortcut is ItemShortcut)
					{
						return ActionSelection.UseItem(combatant, (ItemShortcut)shortcut, true, true,
							useAutoTarget, autoTargetOnly, needTargets, out action);
					}
					// ability
					else if(shortcut is AbilityShortcut)
					{
						return ActionSelection.UseAbility(combatant, (AbilityShortcut)shortcut, true, true,
							useAutoTarget, autoTargetOnly, needTargets, out action);
					}
				}
			}

			return false;
		}


		/*
		============================================================================
		Tooltip functions
		============================================================================
		*/
		public bool ShowTooltip(Combatant combatant, float autoCloseTime, bool closeOn2nd)
		{
			if(ActionSelectType.Attack == this.type)
			{
				if(!combatant.Status.BlockAttack)
				{
					AbilityShortcut ability = this.attack.GetAttack(combatant);

					if(ability != null)
					{
						ORK.GUI.ForceTooltip(
							new PreviewSelection(combatant, ability, true),
							autoCloseTime, closeOn2nd);
						return true;
					}
				}
			}
			// counter
			else if(ActionSelectType.CounterAttack == this.type)
			{
				if(!combatant.Status.BlockAttack)
				{
					AbilityShortcut ability = combatant.Abilities.GetCounterAttack();

					if(ability != null)
					{
						ORK.GUI.ForceTooltip(
							new PreviewSelection(combatant, ability, true),
							autoCloseTime, closeOn2nd);
						return true;
					}
				}
			}
			// ability
			else if(ActionSelectType.Ability == this.type)
			{
				if(!combatant.Status.BlockAbilities)
				{
					AbilityShortcut ability = combatant.Abilities.Get(this.abilityID);

					if(ability != null)
					{
						ability.SetHighestUseLevel(combatant);

						ORK.GUI.ForceTooltip(
							new PreviewSelection(combatant, ability, true),
							autoCloseTime, closeOn2nd);
						return true;
					}
				}
			}
			// class ability
			else if(ActionSelectType.ClassAbility == this.type)
			{
				if(!combatant.Status.BlockAbilities)
				{
					AbilityShortcut ability = combatant.Abilities.GetClassAbility();

					if(ability != null)
					{
						ORK.GUI.ForceTooltip(
							new PreviewSelection(combatant, ability, true),
							autoCloseTime, closeOn2nd);
						return true;
					}
				}
			}
			// item
			else if(ActionSelectType.Item == this.type)
			{
				if(!combatant.Status.BlockItems)
				{
					ItemShortcut item = combatant.Inventory.GetItem(this.itemID);

					if(item != null)
					{
						ORK.GUI.ForceTooltip(
							new PreviewSelection(combatant, item, true),
							autoCloseTime, closeOn2nd);
						return true;
					}
				}
			}
			// shortcut
			else if(ActionSelectType.Shortcut == this.type)
			{
				Combatant owner = null;
				IShortcut shortcut = this.slot.GetShortcut(combatant, out owner);
				if(shortcut != null)
				{
					ORK.GUI.ForceTooltip(
						new PreviewSelection(owner, shortcut, true),
						autoCloseTime, closeOn2nd);
					return true;
				}
			}

			return false;
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public static bool UseAbility(Combatant user, AbilityShortcut ability, bool checkTime, bool checkUseCosts,
			bool useAutoTarget, bool autoTargetOnly, bool needTargets, out BaseAction action)
		{
			action = null;
			if(ability != null &&
				ability.CanUse(user, checkTime &&
					AbilityActionType.CounterAttack != ability.Type,
					checkUseCosts))
			{
				// target self
				if(ability.TargetSelf())
				{
					action = new AbilityAction(user, ability);
					action.SetTarget(user);
				}
				// auto target
				else if(useAutoTarget &&
					(!autoTargetOnly || ability.GetActiveLevel().targetSettings.useAutoTarget))
				{
					action = new AbilityAction(user, ability);
					action.AutoTarget(user.Battle.LastTargets,
						ORK.Game.Combatants.Get(user, true, Range.Battle, Consider.No, Consider.Ignore, Consider.Yes),
						ORK.Game.Combatants.Get(user, false, Range.Battle, Consider.Yes, Consider.Ignore, Consider.Yes));
				}
				else
				{
					// group target
					Combatant target = user.Group.SelectedTargets.GetAbilityTarget(user, ability);
					if(target != null)
					{
						action = new AbilityAction(user, ability);
						action.SetTarget(target);
					}
					else
					{
						// individual target
						target = user.SelectedTargets.GetAbilityTarget(user, ability);
						if(target != null)
						{
							action = new AbilityAction(user, ability);
							action.SetTarget(target);
						}
						// select target
						else if(!needTargets || ability.HasPossibleTargets(user, null))
						{
							return user.BattleMenu.StartTargetSelection(ability);
						}
					}
				}
			}
			return false;
		}

		public static bool UseItem(Combatant user, ItemShortcut item, bool checkTime, bool checkUseCosts,
			bool useAutoTarget, bool autoTargetOnly, bool needTargets, out BaseAction action)
		{
			action = null;
			if(item != null && item.CanUse(user, checkTime, checkUseCosts))
			{
				// target self
				if(item.Setting.targetSettings.TargetSelf())
				{
					action = new ItemAction(user, item);
					action.SetTarget(user);
				}
				// auto target
				else if(useAutoTarget &&
					(!autoTargetOnly || item.Setting.targetSettings.useAutoTarget))
				{
					action = new ItemAction(user, item);
					action.AutoTarget(user.Battle.LastTargets,
						ORK.Game.Combatants.Get(user, true, Range.Battle, Consider.No, Consider.Ignore, Consider.Yes),
						ORK.Game.Combatants.Get(user, false, Range.Battle, Consider.Yes, Consider.Ignore, Consider.Yes));
				}
				else
				{
					// group target
					Combatant target = user.Group.SelectedTargets.GetItemTarget(user, item);
					if(target != null)
					{
						action = new ItemAction(user, item);
						action.SetTarget(target);
					}
					else
					{
						// individual target
						target = user.SelectedTargets.GetItemTarget(user, item);
						if(target != null)
						{
							action = new ItemAction(user, item);
							action.SetTarget(target);
						}
						// select target
						else if(!needTargets || item.HasPossibleTargets(user, null))
						{
							return user.BattleMenu.StartTargetSelection(item);
						}
					}
				}
			}
			return false;
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public string GetInfoText()
		{
			if(ActionSelectType.Ability == this.type)
			{
				return ORK.Abilities.GetName(this.abilityID);
			}
			else if(ActionSelectType.Item == this.type)
			{
				return ORK.Items.GetName(this.itemID);
			}
			else
			{
				return this.type.ToString();
			}
		}
	}
}
