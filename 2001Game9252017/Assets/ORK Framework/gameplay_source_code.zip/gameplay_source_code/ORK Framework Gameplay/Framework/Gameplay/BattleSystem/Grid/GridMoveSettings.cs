﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GridMoveSettings : BaseData
	{
		[ORKEditorHelp("Move Type", "Select how the combatant will move:\n" +
			"- Move Toward Target: The combatant moves near a target on the battle grid.\n" +
			"- Flee From Target: The combatant moves away from the target to the cell with the biggest grid distance.\n" +
			"- Random: The combatant moves to a random cell within move range.", "")]
		public AIGridMove moveType = AIGridMove.MoveTowardTarget;

		[ORKEditorHelp("Target Cell", "Select which cell will be moved to:\n" +
			"- Nearest: The nearest cell (to the moving combatant).\n" +
			"- North: A cell north of the target (global space).\n" +
			"- East: A cell east of the target (global space).\n" +
			"- South: A cell south of the target (global space).\n" +
			"- West: A cell west of the target (global space).\n" +
			"- Front: A cell in front of the target (local space).\n" +
			"- Back: A cell in the back of the target (local space).\n" +
			"- Left: A cell left of the target (local space).\n" +
			"- Right: A cell in right of the target (local space).", "")]
		[ORKEditorLayout("moveType", AIGridMove.MoveTowardTarget)]
		public AIGridMoveTargetType targetType = AIGridMoveTargetType.Nearest;

		[ORKEditorHelp("Stop Distance", "Define how many cells the user will stop before a target (combatant).\n" +
			"The minimum distance is 1 (i.e. at the first cell next to the target).", "")]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout(endCheckGroup=true)]
		public int stopDistance = 1;

		public GridMoveSettings()
		{

		}

		public bool GetMoveAction(Combatant user, List<Combatant> targets,
			out GridMoveAction action, GridMoveShortcut gridMoveShortcut)
		{
			action = null;

			// get action
			if(user.GridCell != null &&
				user.Battle.GridMoveRange > 0 &&
				!user.Status.StopMove &&
				!user.Status.StopMovement &&
				user.Battle.GridMoveState == GridMoveState.Available)
			{
				BattleGridPathFinder path = new BattleGridPathFinder();
				BattleGridCellComponent cell = null;

				if(AIGridMove.Random == this.moveType)
				{
					path.CreateMoveRange(user, false);
					if(path.availableTargets.Count > 0)
					{
						cell = path.availableTargets[Random.Range(0, path.availableTargets.Count)];
						if(cell != null)
						{
							action = path.GetMoveAction(cell, gridMoveShortcut);
							return true;
						}
					}
				}
				else
				{
					bool canReach = false;

					for(int i = 0; i < targets.Count; i++)
					{
						if(targets[i] != null &&
							targets[i].GridCell != null)
						{
							if(AIGridMove.MoveTowardTarget == this.moveType)
							{
								if(AIGridMoveTargetType.Nearest == this.targetType)
								{
									if(user.GridCell.CubeCoord.Distance(targets[i].GridCell.CubeCoord) > this.stopDistance)
									{
										path.CreatePathTo(user, targets[i].GridCell);
										cell = path.GetLastReachablePathCell(
											targets[i].GridCell, this.stopDistance, ref canReach);
									}
								}
								else
								{
									BattleGridCellComponent targetCell = BattleGridHelper.GetRingCell(
										user.GridCell, targets[i].GridCell, this.stopDistance,
										this.targetType, false, false, false, BattleGridHelper.IsFreeCell);
									if(targetCell == targets[i].GridCell)
									{
										if(user.GridCell.CubeCoord.Distance(targets[i].GridCell.CubeCoord) > this.stopDistance)
										{
											path.CreatePathTo(user, targets[i].GridCell);
											cell = path.GetLastReachablePathCell(
												targets[i].GridCell, this.stopDistance, ref canReach);
										}
									}
									else if(user.GridCell != targetCell)
									{
										path.CreatePathTo(user, targetCell);
										cell = path.GetLastReachablePathCell(
											targetCell, 0, ref canReach);
									}
								}
							}
							else if(AIGridMove.FleeFromTarget == this.moveType)
							{
								path.CreateMoveRange(user, false);
								cell = path.GetMostDistantCell(targets[i].GridCell);
								canReach = cell != null;
							}

							if(canReach)
							{
								if(cell != null &&
									user.GridCell != cell)
								{
									action = path.GetMoveAction(cell, gridMoveShortcut);
								}
								return true;
							}
							else
							{
								path.Clear();
							}
						}
					}
				}
			}
			return false;
		}

		public override string ToString()
		{
			if(AIGridMove.MoveTowardTarget == this.moveType)
			{
				return "Move toward target (" + this.targetType + ")";
			}
			else if(AIGridMove.FleeFromTarget == this.moveType)
			{
				return "Flee from target";
			}
			else if(AIGridMove.Random == this.moveType)
			{
				return "Random";
			}
			return "";
		}
	}
}
