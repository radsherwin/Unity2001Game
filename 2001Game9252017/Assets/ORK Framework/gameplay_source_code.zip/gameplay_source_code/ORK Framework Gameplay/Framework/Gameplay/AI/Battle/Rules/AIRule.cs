﻿
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class AIRule : BaseData
	{
		[ORKEditorHelp("Rule Type", "Select the type of this rule:\n" +
			"- Action: Perform an action (used before AI behaviour).\n" +
			"- Battle AI: Use battle AIs to find an action (used before AI behaviour).\n" +
			"- Block Ability: Blocks defined abilities or ability types from being used.\n" +
			"- Block Attack: Blocks the base attack from being used.\n" +
			"- Block Counter Attack: Blocks the counter attack from being used (as an AI action, not countering).\n" +
			"- Block Item: Blocks defined items or item types from being used.\n" + 
			"- Target: Changes the target of used actions.\n" + 
			"- Move AI: Changes the used move AI or use mode.", "")]
		public AIRuleType type = AIRuleType.Action;


		// action
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("type", AIRuleType.Action, endCheckGroup=true, autoInit=true)]
		public AIRuleAction action;

		// battle AI
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("type", AIRuleType.BattleAI, endCheckGroup=true, autoInit=true)]
		public AIRuleBattleAI battleAI;

		// block ability
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("type", AIRuleType.BlockAbility, endCheckGroup=true, autoInit=true)]
		public AIRuleBlockAbility blockAbility;

		// block item
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("type", AIRuleType.BlockItem, endCheckGroup=true, autoInit=true)]
		public AIRuleBlockItem blockItem;

		// target
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("type", AIRuleType.Target, endCheckGroup=true, autoInit=true)]
		public AIRuleTarget target;

		// target
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("type", AIRuleType.MoveAI, endCheckGroup=true, autoInit=true)]
		public AIRuleMoveAI moveAI;

		public AIRule()
		{

		}
	}
}
