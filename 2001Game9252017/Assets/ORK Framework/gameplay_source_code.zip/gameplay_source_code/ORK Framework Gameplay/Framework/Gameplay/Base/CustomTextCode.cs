﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class CustomTextCode : BaseData
	{
		[ORKEditorHelp("Text Code", "Define the custom text code that will be used.\n" +
			"It's recommended to start a text code with a '%'-sign, e.g. %customCode.", "")]
		public string textCode = "";

		[ORKEditorHelp("Text", "The text used to replace the defined text code.", "")]
		[ORKEditorInfo(isTextArea=true)]
		[ORKEditorArray(ORKDataType.Language)]
		public string[] value = new string[0];

		public CustomTextCode()
		{

		}

		public CustomTextCode(int languageCount)
		{
			this.value = new string[languageCount];
			for(int i = 0; i < this.value.Length; i++)
			{
				this.value[i] = "";
			}
		}

		public string Replace(string text)
		{
			return text.Replace(this.textCode,
				ORK.Game.Language < this.value.Length ?
					this.value[ORK.Game.Language] :
					"");
		}
	}
}
