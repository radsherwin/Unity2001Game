﻿
using UnityEngine;
using ORKFramework.AI;
using System.Collections.Generic;

namespace ORKFramework.UI
{
	public class AIBehaviourBMItem : BMItem
	{
		private int slotIndex = -1;

		private AIBehaviourShortcut behaviour;

		public AIBehaviourBMItem(int slotIndex, AIBehaviourShortcut behaviour, ChoiceContent content)
		{
			this.slotIndex = slotIndex;
			this.behaviour = behaviour;
			this.content = content;
		}

		public override void CreateDrag(Combatant owner)
		{
			// portrait
			if(this.behaviour != null &&
				this.content.portrait == null &&
				owner.BattleMenu.Settings.showAIBehaviourPortraits &&
				this.behaviour.HasPortrait())
			{
				this.content.portrait = this.behaviour.GetPortrait();
			}
		}

		public override bool ActiveCheck(Combatant owner)
		{
			bool tmp = this.content.Active;
			if(this.behaviour == null)
			{
				this.content.Active = owner.AI.AIBehaviourSlot[this.slotIndex].Equipped;
			}
			else
			{
				this.content.Active = this.behaviour.CanUse(owner, false, true);
			}
			return tmp != this.content.Active;
		}

		public override bool Accepted(Combatant owner)
		{
			if(owner.BattleMenu != null)
			{
				if(this.behaviour == null)
				{
					owner.AI.UnequipAIBehaviour(this.slotIndex, true, true);
				}
				else
				{
					owner.AI.EquipAIBehaviour(this.behaviour.ID, this.slotIndex, true, true, true);
				}

				if(owner.BattleMenu.CommandedBy != null)
				{
					owner.EndBattleMenu(true);
				}
				else
				{
					owner.BattleMenu.Show(true);
				}
				return true;
			}
			return false;
		}
	}
}
