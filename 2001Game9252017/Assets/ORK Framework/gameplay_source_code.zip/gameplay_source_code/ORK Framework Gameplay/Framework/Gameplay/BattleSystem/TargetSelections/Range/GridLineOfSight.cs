﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GridLineOfSight : BaseData
	{
		[ORKEditorHelp("Visible Cell Area (0-0.5)", "Defines how much of a cell is checked for visibility.\n" + 
			"Set to 0 to only check the center.", "")]
		[ORKEditorLimit(0.0f, 0.5f)]
		public float visibleCellArea = 0;

		[ORKEditorHelp("LOS Blocked Cells", "Blocked cells will block the line of sight.", "")]
		public bool losBlockedCells = true;

		[ORKEditorHelp("LOS Passable Cells", "Blocked cells that are passable will block the line of sight.", "")]
		[ORKEditorLayout("losBlockedCells", true, endCheckGroup=true)]
		public bool losPassableCells = false;

		[ORKEditorHelp("LOS Allied Combatants", "Cells occupied by allied combatants will block the line of sight.", "")]
		public bool losAlliedCombatants = true;

		[ORKEditorHelp("LOS Enemy Combatants", "Cells occupied by enemy combatants will block the line of sight.", "")]
		public bool losEnemyCombatants = true;

		[ORKEditorHelp("LOS Check Cell Types", "Defined grid cell types will block the line of sight.", "")]
		public bool losCheckCellTypes = false;


		// cell types
		[ORKEditorHelp("Grid Cell Type", "Select the grid cell type that will block the line of sight.", "")]
		[ORKEditorInfo(ORKDataType.BattleGridCellType, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Cell Type", "Adds a grid cell type that will block the line of sight.", "",
			"Remove", "Removes the grid cell type.", "", isHorizontal=true)]
		[ORKEditorLayout("losCheckCellTypes", true, endCheckGroup=true, autoInit=true)]
		public int[] losCellType;

		public GridLineOfSight()
		{

		}

		public bool BlocksLineOfSight(BattleGridCellComponent origin, BattleGridCellComponent cell)
		{
			if((this.losBlockedCells && cell.IsBlocked &&
				(this.losPassableCells || !cell.IsPassable)) ||
				(this.losAlliedCombatants &&
					cell.Combatant != null &&
					origin.Combatant != null &&
					!origin.Combatant.IsEnemy(cell.Combatant)) ||
				(this.losEnemyCombatants &&
					cell.Combatant != null &&
					origin.Combatant != null &&
					origin.Combatant.IsEnemy(cell.Combatant)))
			{
				return true;
			}
			else if(this.losCheckCellTypes &&
				this.losCellType != null)
			{
				for(int i = 0; i < this.losCellType.Length; i++)
				{
					if(this.losCellType[i] == cell.cellTypeID)
					{
						return true;
					}
				}
			}
			return false;
		}
	}
}
