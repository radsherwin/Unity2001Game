﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class OverrideLanguageContent : BaseData
	{
		// own name
		[ORKEditorHelp("Own Name", "Override the name.", "")]
		[ORKEditorInfo(labelText="Override Name")]
		public bool ownName = false;

		[ORKEditorHelp("Name", "Define the name that will be used.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("ownName", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] name;


		// own description
		[ORKEditorHelp("Own Description", "Override the description.", "")]
		[ORKEditorInfo(separator=true, labelText="Override Description")]
		public bool ownDescription = false;

		[ORKEditorHelp("Description", "Define the description that will be used.", "")]
		[ORKEditorInfo(isTextArea=true)]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		[ORKEditorLayout("ownDescription", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] description;


		// own icon
		[ORKEditorHelp("Own Icon", "Override the icon.", "")]
		[ORKEditorInfo(separator=true, labelText="Override Icon")]
		public bool ownIcon = false;

		[ORKEditorHelp("Icon", "Select the icon that will be used.", "")]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("ownIcon", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public Texture[] icon;

		public OverrideLanguageContent()
		{

		}
	}
}
