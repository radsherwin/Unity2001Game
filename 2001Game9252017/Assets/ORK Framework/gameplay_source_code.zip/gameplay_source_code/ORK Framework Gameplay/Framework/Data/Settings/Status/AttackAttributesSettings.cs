
using UnityEngine;

namespace ORKFramework
{
	public class AttackAttributesSettings : BaseLanguageSettings
	{
		public AttackAttributeSetting[] data = new AttackAttributeSetting[] {
			new AttackAttributeSetting("Default Attribute")
		};
		
		public AttackAttributesSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}
		
		public override void SetRealIDs()
		{
			this.SetRealIDs(this.data);
		}
		
		
		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get{ return "attackAttributes"; }
		}
		
		
		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			AttackAttributeSetting newData = new AttackAttributeSetting("New");
			ArrayHelper.Add(ref this.data, newData);
			DataHelper.Added(ORKDataType.AttackAttributes);
			return this.data.Length - 1;
		}
		
		public override int Copy(int index)
		{
			AttackAttributeSetting newData = this.GetCopy(index);
			ArrayHelper.Add(ref this.data, newData);
			DataHelper.Added(ORKDataType.AttackAttributes);
			return this.data.Length - 1;
		}
		
		public AttackAttributeSetting GetCopy(int index)
		{
			AttackAttributeSetting tmp = new AttackAttributeSetting();
			if(index >= 0 && index < this.data.Length)
			{
				tmp.SetData(this.data[index].GetData());
				tmp.RealID = index;
			}
			return tmp;
		}
		
		public override void Remove(int index)
		{
			ArrayHelper.RemoveAt(ref this.data, index);
			DataHelper.Removed(ORKDataType.AttackAttributes, index);
		}
		
		public AttackAttributeSetting Get(int index)
		{
			if(index >= 0 && index < this.Count)
			{
				return this.data[index];
			}
			else if(this.data.Length > 0)
			{
				return this.data[0];
			}
			else
			{
				return null;
			}
		}
		
		public AttackSubAttribute Get(int index, int index2)
		{
			AttackAttributeSetting list = this.Get(index);
			if(list != null)
			{
				if(index2 >= 0 && index2 < list.attribute.Length)
				{
					return list.attribute[index2];
				}
				else if(list.attribute.Length > 0)
				{
					return list.attribute[0];
				}
			}
			return null;
		}
		
		public override void Move(int index, bool down)
		{
			if(down)
			{
				ArrayHelper.MoveDown(ref this.data, index);
			}
			else
			{
				ArrayHelper.MoveUp(ref this.data, index);
			}
			DataHelper.Moved(ORKDataType.AttackAttributes, down, index);
		}
		
		
		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			if(index >= 0 && index < this.data.Length)
			{
				return this.data[index].languageInfo[ORK.Game.Language].GetName();
			}
			else
			{
				return "AttackAttributes " + index + " not found";
			}
		}

		public override string[] GetNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i=0; i<names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = i + ": " + this.GetName(i);
				}
				else
				{
					names[i] = this.GetName(i);
				}
			}
			return names;
		}
		
		public override int Count
		{
			get{ return this.data.Length;}
		}
		
		public string GetName(int index, int index2)
		{
			AttackAttributeSetting list = this.Get(index);
			if(list != null)
			{
				if(index2 >= 0 && index2 < list.attribute.Length)
				{
					return list.attribute[index2].languageInfo[ORK.Game.Language].GetName();
				}
				else
				{
					return "AttackAttribute " + index + ", " + index2 + " not found";
				}
			}
			else
			{
				return "AttackAttributes " + index + " not found";
			}
		}

		public string[] GetNames(int index, bool addIndex)
		{
			string[] names = new string[0];
			AttackAttributeSetting list = this.Get(index);
			if(list != null)
			{
				names = new string[list.attribute.Length];
				for(int i=0; i<names.Length; i++)
				{
					if(addIndex)
					{
						names[i] = i + ": " + this.GetName(index, i);
					}
					else
					{
						names[i] = this.GetName(index, i);
					}
				}
			}
			return names;
		}
		
		public int AttributeCount(int index)
		{
			AttackAttributeSetting list = this.Get(index);
			if(list != null)
			{
				return list.attribute.Length;
			}
			else
			{
				return 0;
			}
		}
		
		public override string GetDescription(int index)
		{
			if(index >= 0 && index < this.data.Length)
			{
				return this.data[index].languageInfo[ORK.Game.Language].GetDescription();
			}
			else
			{
				return "AttackAttributes " + index + " not found";
			}
		}
		
		public string GetDescription(int index, int index2)
		{
			AttackAttributeSetting list = this.Get(index);
			if(list != null && index2 >= 0 && index2 < list.attribute.Length)
			{
				return list.attribute[index2].languageInfo[ORK.Game.Language].GetDescription();
			}
			else
			{
				return "AttackAttribute " + index + ", " + index2 + " not found";
			}
		}
		
		public override Texture GetIcon(int index)
		{
			Texture tex = null;
			
			if(index >= 0 && index < this.data.Length)
			{
				int l = ORK.Game.Language;
				tex = this.data[index].languageInfo[l].GetIcon();
				if(tex == null && l != 0)
				{
					tex = this.data[index].languageInfo[0].GetIcon();
				}
			}
			return tex;
		}
		
		public Texture GetIcon(int index, int index2)
		{
			Texture tex = null;
			AttackAttributeSetting list = this.Get(index);
			if(list != null && index2 >= 0 && index2 < list.attribute.Length)
			{
				int l = ORK.Game.Language;
				tex = list.attribute[index2].languageInfo[l].GetIcon();
				if(tex == null && l != 0)
				{
					tex = list.attribute[index2].languageInfo[0].GetIcon();
				}
			}
			return tex;
		}
		
		public GUIContent GetContent(int index, int index2)
		{
			return new GUIContent(this.GetName(index, index2), this.GetIcon(index, index2));
		}
	}
}

