
using UnityEngine;

namespace ORKFramework
{
	public class LanguagesSettings : BaseSettings
	{
		public Language[] data = new Language[] {new Language("English")};
		
		public LanguagesSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}
		
		public override void SetRealIDs()
		{
			this.SetRealIDs(this.data);
		}
		
		
		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get{ return "languagesSettings"; }
		}
		
		
		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			if(index >= 0 && index < this.data.Length)
			{
				return this.data[index].name;
			}
			else
			{
				return "Language(" + index + ") not found";
			}
		}

		public override string[] GetNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i=0; i<names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = i + ": " + this.data[i].name;
				}
				else
				{
					names[i] = this.data[i].name;
				}
			}
			return names;
		}
		
		public override int Count
		{
			get{ return this.data.Length;}
		}
		
		public string GetDescription(int index)
		{
			if(index >= 0 && index < this.data.Length)
			{
				return this.data[index].description;
			}
			else
			{
				return "Language(" + index + ") not found";
			}
		}
		
		public Texture GetIcon(int index)
		{
			if(index >= 0 && index < this.data.Length)
			{
				return this.data[index].icon;
			}
			else
			{
				return null;
			}
		}
		
		
		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			ArrayHelper.Add(ref this.data, new Language("New"));
			DataHelper.Added(ORKDataType.Language);
			return this.data.Length-1;
		}
		
		public override int Copy(int index)
		{
			ArrayHelper.Add(ref this.data, this.GetCopy(index));
			DataHelper.Added(ORKDataType.Language);
			return this.data.Length-1;
		}
		
		public Language GetCopy(int index)
		{
			Language l = new Language("");
			if(index >= 0 && index < this.data.Length)
			{
				l.SetData(this.data[index].GetData());
			}
			return l;
		}
		
		public override void Remove(int index)
		{
			ArrayHelper.RemoveAt(ref this.data, index);
			DataHelper.Removed(ORKDataType.Language, index);
		}
		
		public Language Get(int index)
		{
			if(index >= 0 && index < this.Count)
			{
				return this.data[index];
			}
			else
			{
				return this.data[0];
			}
		}
		
		public ChoiceContent[] GetLanguageChoice(ContentLayout layout)
		{
			ChoiceContent[] choice = new ChoiceContent[this.data.Length+1];
			for(int i=0; i<this.data.Length; i++)
			{
				choice[i] = layout.GetChoiceContent(this.data[i]);
			}
			choice[choice.Length-1] = layout.GetChoiceContent(ORK.MenuSettings.defaultButtons.cancelButton);
			return choice;
		}
		
		public override void Move(int index, bool down)
		{
			if(down)
			{
				ArrayHelper.MoveDown(ref this.data, index);
			}
			else
			{
				ArrayHelper.MoveUp(ref this.data, index);
			}
			DataHelper.Moved(ORKDataType.Language, down, index);
		}
		
		public int GetInitialLanguage()
		{
			for(int i=0; i<this.data.Length; i++)
			{
				if(this.data[i].initialLanguage)
				{
					return i;
				}
			}
			return 0;
		}
	}
}

