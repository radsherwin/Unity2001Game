﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CombatantDistanceSorter : IComparer<Combatant>
	{
		private Vector3 position;

		public CombatantDistanceSorter(Vector3 position)
		{
			this.position = position;
		}

		public int Compare(Combatant x, Combatant y)
		{
			if(x.GameObject == null &&
				y.GameObject == null)
			{
				return 0;
			}
			else if(x.GameObject != null &&
				y.GameObject == null)
			{
				return -1;
			}
			else if(x.GameObject == null &&
				y.GameObject != null)
			{
				return 1;
			}
			else
			{
				return Vector3.Distance(this.position, x.GameObject.transform.position).CompareTo(
					Vector3.Distance(this.position, y.GameObject.transform.position));
			}
		}
	}
}
