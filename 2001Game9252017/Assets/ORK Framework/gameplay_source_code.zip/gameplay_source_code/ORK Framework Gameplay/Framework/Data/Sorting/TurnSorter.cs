
using System.Collections.Generic;

namespace ORKFramework
{
	public class TurnSorter : IComparer<Combatant>
	{
		public int Compare(Combatant x , Combatant y)
		{
	        if(x.Battle.TurnValue < y.Battle.TurnValue)
			{
				return 1;
			}
			else if(x.Battle.TurnValue > y.Battle.TurnValue)
			{
				return -1;
			}
			else
			{
				return 0;
			}
	    }
	}
	
	public class DummyTurnSorter : IComparer<Combatant>
	{
		public int Compare(Combatant x , Combatant y)
		{
	        if(x.Battle.TurnValueDummy < y.Battle.TurnValueDummy)
			{
				return 1;
			}
			else if(x.Battle.TurnValueDummy > y.Battle.TurnValueDummy)
			{
				return -1;
			}
			else
			{
				return 0;
			}
	    }
	}
}
