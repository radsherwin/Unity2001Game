﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GridDistanceSorter : IComparer<BattleGridCellComponent>
	{
		private BattleGridCellComponent origin;

		public GridDistanceSorter(BattleGridCellComponent origin)
		{
			this.origin = origin;
		}

		public int Compare(BattleGridCellComponent x, BattleGridCellComponent y)
		{
			if(x == null &&
				y == null)
			{
				return 0;
			}
			else if(x != null &&
				y == null)
			{
				return -1;
			}
			else if(x == null &&
				y != null)
			{
				return 1;
			}
			else
			{
				return origin.CubeCoord.Distance(x.CubeCoord).CompareTo(
					origin.CubeCoord.Distance(y.CubeCoord));
			}
		}
	}
}
