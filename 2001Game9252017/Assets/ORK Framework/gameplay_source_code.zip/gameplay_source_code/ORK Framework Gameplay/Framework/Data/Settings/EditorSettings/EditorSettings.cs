
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class EditorSettings : BaseSettings
	{
		// editor help text display
		[ORKEditorHelp("Editor Help Display", "Select when the ORK editor help will be displayed:\n" +
			"- None: Help texts wont be displayed.\n" +
			"- Hover: When hovering over a setting.\n" +
			"- Focus: When a setting is focused.\n" +
			"- Button: Display a '?' button next to the setting.", "")]
		[ORKEditorInfo("Editor Settings", "General ORK editor settings.", "", 
			isEnumToolbar=true, toolbarWidth=75)]
		public EditorHelpType editorHelpType = EditorHelpType.Hover;
		
		[ORKEditorHelp("Help Text Color", "Select the color that is used to display help texts.", "")]
		public Color helpTextColor = Color.black;
		
		
		// separator after foldout
		[ORKEditorHelp("Pretty Foldouts", "A foldouts title and margin will depend on it's depth.", "")]
		[ORKEditorInfo(separator=true)]
		public bool prettyFoldouts = true;
		
		[ORKEditorHelp("Space after Foldout", "Add some space after closing a foldout.", "")]
		public bool foldoutSeparator = false;
		
		[ORKEditorHelp("Remember Last Section", "Remember the last section and sub-section you've had opened in the ORK Framework editor.", "")]
		public bool rememberLastSection = true;
		
		
		// last opened event list
		[ORKEditorHelp("Last Opened Events", "The quantity of last opened events that will be remembered.", "")]
		[ORKEditorInfo(separator=true)]
		public int lastOpenedEvents = 20;
		
		
		// custom text area
		[ORKEditorHelp("Use Custom Text Area", "Use the ORK editor text area instead of the default Unity text area.", "")]
		[ORKEditorInfo(separator=true, labelText="Text Area")]
		public bool useCustomTextArea = true;
		
		[ORKEditorHelp("Text Area Height", "The height of the text area when editing text.", "")]
		[ORKEditorLimit(100.0f, false)]
		public float textAreaHeight = 200.0f;
		
		[ORKEditorHelp("Preview Height", "The height of the text preview displayed in settings.\n" +
			"The text preview is displayed if a text isn't edited.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout("useCustomTextArea", true, endCheckGroup=true)]
		public float textAreaPreviewHeight = 50.0f;
		
		
		// node editor
		[ORKEditorHelp("Flexible Lines", "The lines will connect to either the top, bottom, " +
			"left or right side of a node, depending on the position of the two connected nodes.\n" +
			"If disabled, the lines will always connect to the top.", "")]
		[ORKEditorInfo("Node Editor Settings", "Settings for the node editor.", "")]
		public bool nodesFlexibleLines = true;
		
		[ORKEditorHelp("Snap to Grid", "The nodes will automatically be " +
			"placed on the grid when releasing them after dragging.\n" +
			"This setting can also be toggled in the node editor.", "")]
		[ORKEditorInfo(separator=true)]
		public bool nodesDragGrid = true;
		
		[ORKEditorHelp("Show Grid", "Display a grid below the nodes.\n" +
			"This setting can also be toggled in the node editor.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool showNodesGrid = true;
		
		
		// popup settings
		// layer mask fields
		[ORKEditorHelp("Show All Layers", "All layers will be visible in layer mask fields, not only named ones.\n" +
			"Please note that the last layer (31) will not be displayed!", "")]
		[ORKEditorInfo("Popup Field Settings", "Settings for popup fields in the ORK Framework editor.", "")]
		public bool showAllLayers = false;
		
		[ORKEditorHelp("Extended Popups", "A popup field's width will be extended (i.e. popup fields will be longer).", "")]
		public bool popupLonger = false;
		
		[ORKEditorHelp("Abilities", "Ability selection popup fields will be separated by ability types.", "")]
		[ORKEditorInfo(separator=true, labelText="Type Separation")]
		public bool popupTypedAbility = false;
		
		[ORKEditorHelp("Areas", "Area selection popup fields will be separated by area types.", "")]
		public bool popupTypedArea = false;
		
		[ORKEditorHelp("Crafting Recipes", "Crafting recipe selection popup fields will be separated by crafting types.", "")]
		public bool popupTypedCraftingRecipe = false;
		
		[ORKEditorHelp("Formulas", "Formula selection popup fields will be separated by formula types.", "")]
		public bool popupTypedFormula = false;
		
		[ORKEditorHelp("Currencies", "Currency selection popup fields will be separated by item types.", "")]
		public bool popupTypedCurrency = false;
		
		[ORKEditorHelp("Items", "Item selection popup fields will be separated by item types.", "")]
		public bool popupTypedItem = false;
		
		[ORKEditorHelp("Weapons", "Weapon selection popup fields will be separated by item types.", "")]
		public bool popupTypedWeapon = false;
		
		[ORKEditorHelp("Armors", "Armor selection popup fields will be separated by item types.", "")]
		public bool popupTypedArmor = false;
		
		[ORKEditorHelp("Logs", "Log selection popup fields will be separated by log types.", "")]
		public bool popupTypedLog = false;
		
		[ORKEditorHelp("Log Texts", "Log text selection popup fields will be separated by log types and logs.", "")]
		public bool popupTypedLogText = false;
		
		[ORKEditorHelp("Scene Objects", "Scene object selection popup fields will be separated by scene object types.", "")]
		public bool popupTypedSceneObject = false;
		
		[ORKEditorHelp("Quests", "Quest selection popup fields will be separated by quest types.", "")]
		public bool popupTypedQuest = false;
		
		[ORKEditorHelp("Quest Tasks", "Quest task selection popup fields will be separated by quest types and quests.", "")]
		public bool popupTypedQuestTask = false;
		
		[ORKEditorHelp("GUI Boxes", "GUI box selection popup fields will be separated by GUI layer.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool popupTypedGUIBox = false;
		
		
		
		// editor drag bars
		[ORKEditorHelp("Enable drag bars", "Enable the use of drag bars in the ORK editor.\n" +
					"Drag bars are used to change the size of the help text display, sub-sections and data lists.", "")]
		[ORKEditorInfo("Drag Settings", "ORK editor drag bar settings.", "")]
		public bool enableDrag = true;

		[ORKEditorHelp("Save drag positions", "Save the drag bar positions when saving in the editor.", "")]
		[ORKEditorInfo(endFoldout=true, callbackAfter="button:resetDrag")]
		public bool saveDragPositions = true;

		[ORKEditorInfo(hide=true)]
		public float helpDisplayHeight = 220;

		[ORKEditorInfo(hide=true)]
		public float subSectionWidth = 200;

		[ORKEditorInfo(hide=true)]
		public float tabListWidth = 300;

		[ORKEditorInfo(hide=true)]
		public float formulaHeight = 400;

		[ORKEditorInfo(hide=true)]
		public float aiHeight = 400;

		[ORKEditorInfo(hide=true)]
		public float eventHeight = 400;

		[ORKEditorInfo(hide=true)]
		public float guiEditorWidth = 500;
		
		
		// hotkeys
		[ORKEditorHelp("Section", "Use 'F1' - 'F10' to change between ORK editor sections.", "")]
		[ORKEditorInfo("Hotkey Settings", "Enable ORK editor hotkeys.", "")]
		public bool sectionHK = true;
		
		[ORKEditorHelp("Sub-Section", "Use 'ALT + Page Up' and 'ALT + Page Down' to browse through sub-sections.", "")]
		public bool subHK = true;
		
		[ORKEditorHelp("Data List Index", "Use 'Page Up' and 'Page Down' to browse through data lists (e.g. Items).", "")]
		public bool tabHK = true;
		
		[ORKEditorHelp("Save", "Use 'ALT + S' to save.", "")]
		public bool saveHK = true;
		
		[ORKEditorHelp("Load", "Use 'ALT + L' to load.", "")]
		public bool loadHK = true;
		
		[ORKEditorHelp("Navigation History", "Use 'ALT + Home' to go back and 'ALT + End' to go forward in the navigation history.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool navigationHistoryHK = true;
		
		public EditorSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
		}
		
		public override void SetRealIDs()
		{
			
		}
		
		
		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get{ return "editorSettings"; }
		}
		
		
		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			return "";
		}

		public override string[] GetNames(bool addIndex)
		{
			return new string[0];
		}

		public override int Count
		{
			get
			{
				return 0;
			}
		}
		
		
		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			return -1;
		}
		
		public override int Copy(int index)
		{
			return -1;
		}
		
		public override void Remove(int index)
		{
			
		}
		
		public override void Move(int index, bool down)
		{
			
		}
	}
}

